#!/usr/bin/env python3
"""
Model Architecture Diagram for R² = 0.513 Baseline Ensemble
Stacking Regressor: XGBoost + LightGBM + CatBoost → Huber Meta-learner
High-quality 300 DPI, English, Readable, No main title
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np

# Set high-quality parameters
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.size'] = 11
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['axes.titlesize'] = 13

# Create figure
fig, ax = plt.subplots(figsize=(12, 8))
ax.set_xlim(0, 10)
ax.set_ylim(0, 10)
ax.axis('off')

# Define colors
color_input = '#D6EAF8'      # Light blue
color_base = '#FADBD8'        # Light red/pink
color_meta = '#FDEDEC'        # Very light red
color_output = '#D5F5E3'      # Light green
color_arrow = '#34495E'       # Dark gray

# Helper function to draw boxes
def draw_box(ax, x, y, width, height, text, color, fontsize=11, fontweight='normal'):
    box = FancyBboxPatch((x, y), width, height, 
                         boxstyle="round,pad=0.1", 
                         edgecolor='black', 
                         facecolor=color, 
                         linewidth=2,
                         zorder=2)
    ax.add_patch(box)
    ax.text(x + width/2, y + height/2, text, 
            ha='center', va='center', 
            fontsize=fontsize, fontweight=fontweight,
            zorder=3)

# Helper function to draw arrows
def draw_arrow(ax, x1, y1, x2, y2, color=color_arrow, style='->'):
    arrow = FancyArrowPatch((x1, y1), (x2, y2),
                           arrowstyle=style,
                           color=color,
                           linewidth=2,
                           mutation_scale=20,
                           zorder=1)
    ax.add_patch(arrow)

# ===== INPUT LAYER =====
input_x = 3.5
input_y = 8.5
input_width = 3
input_height = 0.8

draw_box(ax, input_x, input_y, input_width, input_height, 
         'Input Features\n(n=390, 116 features)', 
         color_input, fontsize=12, fontweight='bold')

# Add label
ax.text(-0.5, input_y + input_height/2, 'INPUT\nLAYER', 
        fontsize=10, fontweight='bold', ha='center', va='center',
        color='#2C3E50')

# ===== LEVEL 0: BASE MODELS =====
base_y = 6.0
base_width = 2.2
base_height = 0.7
base_spacing = 0.4

# XGBoost
xgb_x = 0.8
draw_box(ax, xgb_x, base_y, base_width, base_height, 
         'XGBoost\nRegressor', color_base, fontsize=11, fontweight='bold')

# LightGBM
lgbm_x = xgb_x + base_width + base_spacing
draw_box(ax, lgbm_x, base_y, base_width, base_height, 
         'LightGBM\nRegressor', color_base, fontsize=11, fontweight='bold')

# CatBoost
catboost_x = lgbm_x + base_width + base_spacing
draw_box(ax, catboost_x, base_y, base_width, base_height, 
         'CatBoost\nRegressor', color_base, fontsize=11, fontweight='bold')

# Add label (moved to far left)
ax.text(-0.5, base_y + base_height/2, 'LEVEL 0\nBase Models', 
        fontsize=10, fontweight='bold', ha='center', va='center',
        color='#2C3E50')

# Arrows from input to base models
input_center_x = input_x + input_width/2
input_bottom_y = input_y

draw_arrow(ax, input_center_x, input_bottom_y, xgb_x + base_width/2, base_y + base_height)
draw_arrow(ax, input_center_x, input_bottom_y, lgbm_x + base_width/2, base_y + base_height)
draw_arrow(ax, input_center_x, input_bottom_y, catboost_x + base_width/2, base_y + base_height)

# ===== PREDICTIONS (Meta-features) =====
pred_y = 4.2
pred_width = 1.8
pred_height = 0.6

# Predictions boxes (dashed)
pred1_x = xgb_x + (base_width - pred_width)/2
pred2_x = lgbm_x + (base_width - pred_width)/2
pred3_x = catboost_x + (base_width - pred_width)/2

for i, (px, label) in enumerate([(pred1_x, 'Prediction 1'), 
                                   (pred2_x, 'Prediction 2'), 
                                   (pred3_x, 'Prediction 3')]):
    box = FancyBboxPatch((px, pred_y), pred_width, pred_height, 
                         boxstyle="round,pad=0.08", 
                         edgecolor='black', 
                         facecolor='#E8DAEF', 
                         linewidth=1.5,
                         linestyle='--',
                         zorder=2)
    ax.add_patch(box)
    ax.text(px + pred_width/2, pred_y + pred_height/2, label, 
            ha='center', va='center', 
            fontsize=10, style='italic',
            zorder=3)

# Arrows from base models to predictions
draw_arrow(ax, xgb_x + base_width/2, base_y, pred1_x + pred_width/2, pred_y + pred_height)
draw_arrow(ax, lgbm_x + base_width/2, base_y, pred2_x + pred_width/2, pred_y + pred_height)
draw_arrow(ax, catboost_x + base_width/2, base_y, pred3_x + pred_width/2, pred_y + pred_height)

# ===== LEVEL 1: META-MODEL =====
meta_y = 2.2
meta_width = 3
meta_height = 0.8
meta_x = (10 - meta_width)/2

draw_box(ax, meta_x, meta_y, meta_width, meta_height, 
         'Huber Regressor\n(Meta-Model)', 
         color_meta, fontsize=12, fontweight='bold')

# Add label
ax.text(-0.5, meta_y + meta_height/2, 'LEVEL 1\nMeta-Model', 
        fontsize=10, fontweight='bold', ha='center', va='center',
        color='#2C3E50')

# Arrows from predictions to meta-model
meta_center_x = meta_x + meta_width/2
meta_top_y = meta_y + meta_height

draw_arrow(ax, pred1_x + pred_width/2, pred_y, meta_center_x - 0.8, meta_top_y)
draw_arrow(ax, pred2_x + pred_width/2, pred_y, meta_center_x, meta_top_y)
draw_arrow(ax, pred3_x + pred_width/2, pred_y, meta_center_x + 0.8, meta_top_y)

# ===== OUTPUT LAYER =====
output_y = 0.5
output_width = 3
output_height = 0.8
output_x = (10 - output_width)/2

draw_box(ax, output_x, output_y, output_width, output_height, 
         'Predicted UPDRS_V04', 
         color_output, fontsize=12, fontweight='bold')

# Add label
ax.text(-0.5, output_y + output_height/2, 'OUTPUT', 
        fontsize=10, fontweight='bold', ha='center', va='center',
        color='#2C3E50')

# Arrow from meta-model to output
draw_arrow(ax, meta_center_x, meta_y, meta_center_x, output_y + output_height)

# NO MAIN TITLE (as requested)

# Save figure
plt.tight_layout()
output_file = '/home/ubuntu/push_060/model_architecture_0513.png'
plt.savefig(output_file, dpi=300, bbox_inches='tight', facecolor='white')
print(f"✓ Model architecture diagram saved: {output_file}")
print(f"  Resolution: 300 DPI")
print(f"  Size: 12x8 inches")
print(f"  Format: PNG")
print(f"  Model: XGBoost + LightGBM + CatBoost → Huber Meta-learner")
print(f"  Features: 116 (100 genes + 16 clinical/pathway)")
print(f"  Patients: 390")
print(f"  Performance: R² = 0.513")

plt.close()
