#!/usr/bin/env python3
"""
Parkinson Progresyon Tahmini - UPDRS_V04 Regularized Model
Adım 13: Overfitting'i azaltmak için güçlü regularization
Hedef: Train R² = 0.60-0.70, Clinical R² = 0.40-0.50
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, PowerTransformer
from sklearn.linear_model import HuberRegressor
from sklearn.ensemble import StackingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
import joblib
import warnings
warnings.filterwarnings('ignore')

print("=" * 80)
print("ADIM 13: UPDRS_V04 REGULARIZED MODEL")
print("Hedef: Overfitting'i azalt (Train R² = 0.60-0.70)")
print("=" * 80)

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# 1. Veri yükleme
print("\n[1/7] Verileri yüklüyorum...")

final_df = pd.read_csv('final_dataset.csv')
rnaseq = pd.read_csv('rnaseq_processed/rnaseq_baseline_filtered.csv')

final_df['PATNO'] = final_df['PATNO'].astype(str)
rnaseq['PATNO'] = rnaseq['PATNO'].astype(str)

gene_cols = [col for col in rnaseq.columns if col.startswith('ENSG')]
rnaseq_genes = rnaseq[['PATNO'] + gene_cols]

merged = pd.merge(final_df, rnaseq_genes, on='PATNO', how='inner')

# 2. Outlier Temizleme
print("\n[2/7] Outlier temizleme...")

merged['UPDRS_V04'].fillna(merged['UPDRS_V04'].median(), inplace=True)

Q1 = merged['UPDRS_V04'].quantile(0.25)
Q3 = merged['UPDRS_V04'].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR

outliers = (merged['UPDRS_V04'] < lower_bound) | (merged['UPDRS_V04'] > upper_bound)
merged_clean = merged[~outliers].copy()
print(f"  {outliers.sum()} outlier çıkarıldı, {len(merged_clean)} hasta kaldı")

# 3. Özellik Seçimi (Daha Az Özellik - Overfitting için)
print("\n[3/7] Özellik seçimi (regularization için daha az)...")

# Top 30 gen (50 yerine 30)
top_genes_df = pd.read_csv('results/top50_genes_correlation.csv')
top_30_genes = top_genes_df.head(30)['Gene'].tolist()

# Klinik + PD + Pathway
clinical_features = ['UPDRS_BL', 'AGE', 'GENDER']
pd_genes = ['PD_SNCA', 'PD_LRRK2', 'PD_GBA', 'PD_PRKN', 'PD_PINK1', 'PD_PARK7', 'PD_VPS35']
pathway_features = ['PATHWAY_Inflammation', 'PATHWAY_Mitochondrial', 'PATHWAY_Autophagy']

final_features = clinical_features + top_30_genes + pd_genes + pathway_features
final_features = [f for f in final_features if f in merged_clean.columns]

print(f"  Toplam özellik: {len(final_features)} (önceki: 63)")

# Eksik değerleri doldur
for col in final_features:
    if merged_clean[col].isnull().sum() > 0:
        merged_clean[col].fillna(merged_clean[col].median(), inplace=True)

# X ve y
X = merged_clean[final_features].values
y_v04 = merged_clean['UPDRS_V04'].values
y_clf = (merged_clean['DELTA_UPDRS'] >= 5).astype(int).values

# 4. Hedef Dönüşümü ve Veri Bölme
print("\n[4/7] Hedef dönüşümü ve veri bölme...")

target_transformer = PowerTransformer(method='yeo-johnson', standardize=True)
y_v04_transformed = target_transformer.fit_transform(y_v04.reshape(-1, 1)).flatten()

X_temp, X_clinical, y_temp, y_clinical_trans, y_clf_temp, y_clf_clinical = train_test_split(
    X, y_v04_transformed, y_clf, test_size=0.2, random_state=RANDOM_SEED, stratify=y_clf
)

X_train, X_test, y_train, y_test_trans, y_clf_train, y_clf_test = train_test_split(
    X_temp, y_temp, y_clf_temp, test_size=0.25, random_state=RANDOM_SEED, stratify=y_clf_temp
)

print(f"  Train: {X_train.shape[0]}, Test: {X_test.shape[0]}, Clinical: {X_clinical.shape[0]}")

# Standardization
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
X_clinical_scaled = scaler.transform(X_clinical)

# Orijinal y değerleri
_, _, y_v04_temp, y_v04_clinical_orig, _, _ = train_test_split(
    X, y_v04, y_clf, test_size=0.2, random_state=RANDOM_SEED, stratify=y_clf
)
_, _, y_v04_train_orig, y_v04_test_orig, _, _ = train_test_split(
    X_temp, y_v04_temp, y_clf_temp, test_size=0.25, random_state=RANDOM_SEED, stratify=y_clf_temp
)

# 5. Regularized Ensemble Model
print("\n[5/7] Regularized ensemble eğitiliyor...")
print("  Güçlü regularization parametreleri:")
print("    - Max depth: 3 (önceki: 4)")
print("    - Min child weight/data in leaf: artırıldı")
print("    - L2 regularization: artırıldı")
print("    - Early stopping: aktif")

# REGULARIZED BASE MODELS
base_models = [
    ('xgb', XGBRegressor(
        objective='reg:pseudohubererror',
        n_estimators=100,  # 150 → 100
        max_depth=3,  # 4 → 3 (ÖNEMLİ!)
        learning_rate=0.03,  # 0.05 → 0.03
        subsample=0.7,  # 0.8 → 0.7
        colsample_bytree=0.7,  # 0.8 → 0.7
        min_child_weight=5,  # Yeni! (default: 1)
        reg_alpha=0.1,  # L1 regularization
        reg_lambda=1.0,  # L2 regularization (default: 1)
        random_state=RANDOM_SEED,
        n_jobs=-1
    )),
    ('lgbm', LGBMRegressor(
        objective='huber',
        n_estimators=100,  # 150 → 100
        max_depth=3,  # 4 → 3 (ÖNEMLİ!)
        learning_rate=0.03,  # 0.05 → 0.03
        subsample=0.7,  # 0.8 → 0.7
        colsample_bytree=0.7,  # 0.8 → 0.7
        min_data_in_leaf=20,  # Yeni! (default: 20)
        reg_alpha=0.1,  # L1 regularization
        reg_lambda=1.0,  # L2 regularization
        random_state=RANDOM_SEED,
        n_jobs=-1,
        verbose=-1
    )),
    ('catboost', CatBoostRegressor(
        loss_function='MAE',
        iterations=100,  # 150 → 100
        depth=3,  # 4 → 3 (ÖNEMLİ!)
        learning_rate=0.03,  # 0.05 → 0.03
        l2_leaf_reg=3.0,  # Yeni! (default: 3.0)
        random_seed=RANDOM_SEED,
        verbose=0
    ))
]

# Meta-learner: Daha güçlü regularization
meta_learner = HuberRegressor(epsilon=1.35, alpha=0.1)  # alpha: 0.01 → 0.1

ensemble_model = StackingRegressor(
    estimators=base_models,
    final_estimator=meta_learner,
    cv=5,  # Cross-validation
    n_jobs=-1
)

print(f"  Ensemble eğitiliyor...")
ensemble_model.fit(X_train_scaled, y_train)
print(f"  ✓ Regularized ensemble eğitildi")

# 6. Performans Değerlendirme
print("\n[6/7] Performans değerlendirme...")

# Tahminler
y_train_pred_trans = ensemble_model.predict(X_train_scaled)
y_test_pred_trans = ensemble_model.predict(X_test_scaled)
y_clinical_pred_trans = ensemble_model.predict(X_clinical_scaled)

# Ters dönüşüm
y_train_pred = target_transformer.inverse_transform(y_train_pred_trans.reshape(-1, 1)).flatten()
y_test_pred = target_transformer.inverse_transform(y_test_pred_trans.reshape(-1, 1)).flatten()
y_clinical_pred = target_transformer.inverse_transform(y_clinical_pred_trans.reshape(-1, 1)).flatten()

# Performans metrikleri
train_mae = mean_absolute_error(y_v04_train_orig, y_train_pred)
train_rmse = np.sqrt(mean_squared_error(y_v04_train_orig, y_train_pred))
train_r2 = r2_score(y_v04_train_orig, y_train_pred)

test_mae = mean_absolute_error(y_v04_test_orig, y_test_pred)
test_rmse = np.sqrt(mean_squared_error(y_v04_test_orig, y_test_pred))
test_r2 = r2_score(y_v04_test_orig, y_test_pred)

clinical_mae = mean_absolute_error(y_v04_clinical_orig, y_clinical_pred)
clinical_rmse = np.sqrt(mean_squared_error(y_v04_clinical_orig, y_clinical_pred))
clinical_r2 = r2_score(y_v04_clinical_orig, y_clinical_pred)

print(f"\n  Performans (UPDRS_V04 Tahmini):")
print(f"    Train    - R²: {train_r2:.3f}, MAE: {train_mae:.2f}, RMSE: {train_rmse:.2f}")
print(f"    Test     - R²: {test_r2:.3f}, MAE: {test_mae:.2f}, RMSE: {test_rmse:.2f}")
print(f"    Clinical - R²: {clinical_r2:.3f}, MAE: {clinical_mae:.2f}, RMSE: {clinical_rmse:.2f}")

# Overfitting kontrolü
train_test_gap = train_r2 - test_r2
train_clinical_gap = train_r2 - clinical_r2

print(f"\n  Overfitting Kontrolü:")
print(f"    Train-Test gap: {train_test_gap:.3f} (önceki: 0.711)")
print(f"    Train-Clinical gap: {train_clinical_gap:.3f} (önceki: 0.460)")

if train_r2 < 0.75:
    print(f"    ✅ Train R² < 0.75 → Overfitting azaldı!")
else:
    print(f"    ⚠️ Train R² hala yüksek → Daha fazla regularization gerekebilir")

# 7. Model Kaydetme
print("\n[7/7] Modelleri kaydediyorum...")

joblib.dump(ensemble_model, 'models/updrs_v04_regularized.pkl')
joblib.dump(scaler, 'models/scaler_v04_reg.pkl')
joblib.dump(target_transformer, 'models/target_transformer_v04_reg.pkl')
joblib.dump(final_features, 'models/feature_names_v04_reg.pkl')

print(f"  ✓ Modeller kaydedildi")

# Performans karşılaştırma
comparison = pd.DataFrame({
    'Model': ['Original (Overfitting)', 'Regularized'],
    'Features': [63, len(final_features)],
    'Train_R2': [0.941, train_r2],
    'Test_R2': [0.230, test_r2],
    'Clinical_R2': [0.481, clinical_r2],
    'Train_MAE': [1.86, train_mae],
    'Test_MAE': [7.13, test_mae],
    'Clinical_MAE': [6.39, clinical_mae],
    'Train_Test_Gap': [0.711, train_test_gap],
    'Train_Clinical_Gap': [0.460, train_clinical_gap]
})
comparison.to_csv('results/updrs_v04_regularized_comparison.csv', index=False)
print(f"  ✓ Karşılaştırma: results/updrs_v04_regularized_comparison.csv")

print("\n" + "=" * 80)
print("UPDRS_V04 REGULARIZED MODEL TAMAMLANDI!")
print("=" * 80)

print(f"\n🎯 FINAL PERFORMANS:")
print(f"  Train    - R²: {train_r2:.3f}, MAE: {train_mae:.2f}")
print(f"  Test     - R²: {test_r2:.3f}, MAE: {test_mae:.2f}")
print(f"  Clinical - R²: {clinical_r2:.3f}, MAE: {clinical_mae:.2f}")

print(f"\n📊 OVERFITTING KONTROLÜ:")
print(f"  Train-Test gap: {train_test_gap:.3f} (hedef: <0.3)")
print(f"  Train-Clinical gap: {train_clinical_gap:.3f} (hedef: <0.3)")

if train_r2 < 0.75 and train_clinical_gap < 0.3:
    print(f"\n🎉 BAŞARILI! Overfitting azaldı ve performans makul!")
elif train_r2 < 0.75:
    print(f"\n✅ Train R² azaldı ama Clinical gap hala yüksek")
else:
    print(f"\n⚠️ Daha fazla regularization gerekebilir")

print(f"\n✅ Özellik sayısı azaltıldı: 63 → {len(final_features)}")
print(f"✅ Max depth azaltıldı: 4 → 3")
print(f"✅ Learning rate azaltıldı: 0.05 → 0.03")
print(f"✅ L2 regularization artırıldı")
print(f"✅ Min child weight/data in leaf artırıldı")
