#!/usr/bin/env python3
"""
Grafik 5: SHAP Feature Importance - 3 Panel
(a) Top 20 Features, (b) PD Risk Genes, (c) Pathway Scores
300 DPI, İngilizce, Ana başlık yok, Oldukça okunaklı
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, PowerTransformer
import joblib
import shap
import warnings
warnings.filterwarnings('ignore')

# Matplotlib ayarları - Yüksek kalite
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['xtick.labelsize'] = 9
plt.rcParams['ytick.labelsize'] = 9
plt.rcParams['legend.fontsize'] = 9

print("=" * 80)
print("GRAFİK 5: SHAP Feature Importance - 3 Panel")
print("=" * 80)

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# 1. Veri yükleme
print("\n[1/5] Verileri yüklüyorum...")

final_df = pd.read_csv('final_dataset.csv')
rnaseq = pd.read_csv('rnaseq_processed/rnaseq_baseline_filtered.csv')

final_df['PATNO'] = final_df['PATNO'].astype(str)
rnaseq['PATNO'] = rnaseq['PATNO'].astype(str)

gene_cols = [col for col in rnaseq.columns if col.startswith('ENSG')]
rnaseq_genes = rnaseq[['PATNO'] + gene_cols]

merged = pd.merge(final_df, rnaseq_genes, on='PATNO', how='inner')

# Outlier temizleme
merged['UPDRS_V04'].fillna(merged['UPDRS_V04'].median(), inplace=True)
Q1 = merged['UPDRS_V04'].quantile(0.25)
Q3 = merged['UPDRS_V04'].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
outliers = (merged['UPDRS_V04'] < lower_bound) | (merged['UPDRS_V04'] > upper_bound)
merged_clean = merged[~outliers].copy()

print(f"  {len(merged_clean)} hasta yüklendi")

# 2. Özellik seçimi
print("\n[2/5] Özellikleri hazırlıyorum...")

top_genes_df = pd.read_csv('results/top50_genes_correlation.csv')
top_30_genes = top_genes_df.head(30)['Gene'].tolist()

clinical_features = ['UPDRS_BL', 'AGE', 'GENDER']
pd_genes = ['PD_SNCA', 'PD_LRRK2', 'PD_GBA', 'PD_PRKN', 'PD_PINK1', 'PD_PARK7', 'PD_VPS35']
pathway_features = ['PATHWAY_Inflammation', 'PATHWAY_Mitochondrial', 'PATHWAY_Autophagy']

final_features = clinical_features + top_30_genes + pd_genes + pathway_features
final_features = [f for f in final_features if f in merged_clean.columns]

for col in final_features:
    if merged_clean[col].isnull().sum() > 0:
        merged_clean[col].fillna(merged_clean[col].median(), inplace=True)

X = merged_clean[final_features].values
y_v04 = merged_clean['UPDRS_V04'].values
y_clf = (merged_clean['DELTA_UPDRS'] >= 5).astype(int).values

print(f"  {len(final_features)} özellik hazır")

# 3. Veri bölme
print("\n[3/5] Veri bölme...")

target_transformer = PowerTransformer(method='yeo-johnson', standardize=True)
y_v04_transformed = target_transformer.fit_transform(y_v04.reshape(-1, 1)).flatten()

X_temp, X_clinical, y_temp, y_clinical_trans, y_clf_temp, y_clf_clinical = train_test_split(
    X, y_v04_transformed, y_clf, test_size=0.2, random_state=RANDOM_SEED, stratify=y_clf
)

scaler = StandardScaler()
X_temp_scaled = scaler.fit_transform(X_temp)
X_clinical_scaled = scaler.transform(X_clinical)

print(f"  Clinical set: {len(X_clinical)} hasta")

# 4. SHAP hesaplama
print("\n[4/5] SHAP değerlerini hesaplıyorum...")

model = joblib.load('models/updrs_v04_regularized.pkl')

# SHAP explainer (KernelExplainer for StackingRegressor)
# Use a subset of training data as background (100 samples for speed)
background = shap.sample(X_temp_scaled, 100, random_state=RANDOM_SEED)
explainer = shap.KernelExplainer(model.predict, background)
shap_values = explainer.shap_values(X_clinical_scaled[:50])  # First 50 clinical samples for speed

print(f"  SHAP hesaplandı (50 hasta örneği kullanıldı)")

# Mean absolute SHAP values
mean_abs_shap = np.abs(shap_values).mean(axis=0)

# Feature importance DataFrame
feature_importance = pd.DataFrame({
    'Feature': final_features,
    'SHAP': mean_abs_shap
}).sort_values('SHAP', ascending=False)

print(f"  SHAP hesaplandı: {len(feature_importance)} özellik")

# Top 20, PD genes, Pathways
top20 = feature_importance.head(20)
pd_genes_importance = feature_importance[feature_importance['Feature'].str.startswith('PD_')]
pathway_importance = feature_importance[feature_importance['Feature'].str.startswith('PATHWAY_')]

print(f"\n  Top 20 özellik:")
for idx, row in top20.iterrows():
    print(f"    {row['Feature']}: {row['SHAP']:.4f}")

# 5. Grafik oluşturma (3 Panel)
print("\n[5/5] Grafik oluşturuluyor...")

fig, axes = plt.subplots(1, 3, figsize=(16, 5))

# Panel (a): Top 20 Features
ax = axes[0]
colors_a = ['#2E86AB' if not f.startswith(('PD_', 'PATHWAY_')) else '#E63946' if f.startswith('PD_') else '#F77F00' 
            for f in top20['Feature']]
ax.barh(range(len(top20)), top20['SHAP'], color=colors_a, alpha=0.8, edgecolor='black', linewidth=0.5)
ax.set_yticks(range(len(top20)))
ax.set_yticklabels(top20['Feature'], fontsize=9)
ax.set_xlabel('Mean |SHAP Value|', fontsize=11, fontweight='bold')
ax.set_title('(a) Top 20 Features', fontsize=12, fontweight='bold', pad=10)
ax.grid(axis='x', alpha=0.3, linestyle='--', linewidth=0.5)
ax.invert_yaxis()

# Panel (b): PD Risk Genes
ax = axes[1]
ax.barh(range(len(pd_genes_importance)), pd_genes_importance['SHAP'], 
        color='#E63946', alpha=0.8, edgecolor='black', linewidth=0.5)
ax.set_yticks(range(len(pd_genes_importance)))
ax.set_yticklabels([f.replace('PD_', '') for f in pd_genes_importance['Feature']], fontsize=9)
ax.set_xlabel('Mean |SHAP Value|', fontsize=11, fontweight='bold')
ax.set_title('(b) PD Risk Genes', fontsize=12, fontweight='bold', pad=10)
ax.grid(axis='x', alpha=0.3, linestyle='--', linewidth=0.5)
ax.invert_yaxis()

# Panel (c): Pathway Scores
ax = axes[2]
ax.barh(range(len(pathway_importance)), pathway_importance['SHAP'], 
        color='#F77F00', alpha=0.8, edgecolor='black', linewidth=0.5)
ax.set_yticks(range(len(pathway_importance)))
ax.set_yticklabels([f.replace('PATHWAY_', '') for f in pathway_importance['Feature']], fontsize=9)
ax.set_xlabel('Mean |SHAP Value|', fontsize=11, fontweight='bold')
ax.set_title('(c) Pathway Scores', fontsize=12, fontweight='bold', pad=10)
ax.grid(axis='x', alpha=0.3, linestyle='--', linewidth=0.5)
ax.invert_yaxis()

# Tight layout
plt.tight_layout()

# Kaydet
output_file = 'figures/Figure_05_SHAP_Three_Panel.png'
plt.savefig(output_file, dpi=300, bbox_inches='tight', facecolor='white')
print(f"\n✓ Grafik kaydedildi: {output_file}")

plt.close()

print("\n" + "=" * 80)
print("GRAFİK 5 TAMAMLANDI!")
print("=" * 80)
print(f"\nDosya: {output_file}")
print(f"Çözünürlük: 300 DPI")
print(f"Boyut: 16x5 inch (3 panel)")
print(f"Format: PNG")
print(f"Dil: İngilizce")
print(f"Panel başlıkları: (a), (b), (c)")
print(f"\n✅ SHAP değerleri gerçek verilerden hesaplandı!")
