#!/usr/bin/env python3
"""
Grafik 1: Predicted vs Actual UPDRS_V04 - Clinical-Holdout Set
300 DPI, İngilizce, Ana başlık yok, Oldukça okunaklı
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, PowerTransformer
from sklearn.metrics import mean_absolute_error, r2_score
import joblib
import warnings
warnings.filterwarnings('ignore')

# Matplotlib ayarları - Yüksek kalite
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.size'] = 12
plt.rcParams['axes.labelsize'] = 14
plt.rcParams['axes.titlesize'] = 16
plt.rcParams['xtick.labelsize'] = 12
plt.rcParams['ytick.labelsize'] = 12
plt.rcParams['legend.fontsize'] = 12

print("=" * 80)
print("GRAFİK 1: Predicted vs Actual UPDRS_V04 - Clinical-Holdout Set")
print("=" * 80)

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# 1. Veri yükleme
print("\n[1/4] Verileri yüklüyorum...")

final_df = pd.read_csv('final_dataset.csv')
rnaseq = pd.read_csv('rnaseq_processed/rnaseq_baseline_filtered.csv')

final_df['PATNO'] = final_df['PATNO'].astype(str)
rnaseq['PATNO'] = rnaseq['PATNO'].astype(str)

gene_cols = [col for col in rnaseq.columns if col.startswith('ENSG')]
rnaseq_genes = rnaseq[['PATNO'] + gene_cols]

merged = pd.merge(final_df, rnaseq_genes, on='PATNO', how='inner')

# Outlier temizleme
merged['UPDRS_V04'].fillna(merged['UPDRS_V04'].median(), inplace=True)
Q1 = merged['UPDRS_V04'].quantile(0.25)
Q3 = merged['UPDRS_V04'].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
outliers = (merged['UPDRS_V04'] < lower_bound) | (merged['UPDRS_V04'] > upper_bound)
merged_clean = merged[~outliers].copy()

print(f"  {len(merged_clean)} hasta yüklendi")

# 2. Özellik seçimi
print("\n[2/4] Özellikleri hazırlıyorum...")

top_genes_df = pd.read_csv('results/top50_genes_correlation.csv')
top_30_genes = top_genes_df.head(30)['Gene'].tolist()

clinical_features = ['UPDRS_BL', 'AGE', 'GENDER']
pd_genes = ['PD_SNCA', 'PD_LRRK2', 'PD_GBA', 'PD_PRKN', 'PD_PINK1', 'PD_PARK7', 'PD_VPS35']
pathway_features = ['PATHWAY_Inflammation', 'PATHWAY_Mitochondrial', 'PATHWAY_Autophagy']

final_features = clinical_features + top_30_genes + pd_genes + pathway_features
final_features = [f for f in final_features if f in merged_clean.columns]

for col in final_features:
    if merged_clean[col].isnull().sum() > 0:
        merged_clean[col].fillna(merged_clean[col].median(), inplace=True)

X = merged_clean[final_features].values
y_v04 = merged_clean['UPDRS_V04'].values
y_clf = (merged_clean['DELTA_UPDRS'] >= 5).astype(int).values

print(f"  {len(final_features)} özellik hazır")

# 3. Veri bölme ve tahmin
print("\n[3/4] Model tahminlerini alıyorum...")

# Hedef dönüşümü
target_transformer = PowerTransformer(method='yeo-johnson', standardize=True)
y_v04_transformed = target_transformer.fit_transform(y_v04.reshape(-1, 1)).flatten()

# Veri bölme
X_temp, X_clinical, y_temp, y_clinical_trans, y_clf_temp, y_clf_clinical = train_test_split(
    X, y_v04_transformed, y_clf, test_size=0.2, random_state=RANDOM_SEED, stratify=y_clf
)

X_train, X_test, y_train, y_test_trans, y_clf_train, y_clf_test = train_test_split(
    X_temp, y_temp, y_clf_temp, test_size=0.25, random_state=RANDOM_SEED, stratify=y_clf_temp
)

# Standardization
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_clinical_scaled = scaler.transform(X_clinical)

# Orijinal y değerleri
_, _, _, y_v04_clinical_orig, _, _ = train_test_split(
    X, y_v04, y_clf, test_size=0.2, random_state=RANDOM_SEED, stratify=y_clf
)

# Model yükleme
model = joblib.load('models/updrs_v04_regularized.pkl')

# Tahmin
y_clinical_pred_trans = model.predict(X_clinical_scaled)
y_clinical_pred = target_transformer.inverse_transform(y_clinical_pred_trans.reshape(-1, 1)).flatten()

# Metrikler
clinical_mae = mean_absolute_error(y_v04_clinical_orig, y_clinical_pred)
clinical_r2 = r2_score(y_v04_clinical_orig, y_clinical_pred)

print(f"  Clinical R² = {clinical_r2:.3f}, MAE = {clinical_mae:.2f}")

# 4. Grafik oluşturma
print("\n[4/4] Grafik oluşturuluyor...")

fig, ax = plt.subplots(figsize=(8, 8))

# Scatter plot
ax.scatter(y_v04_clinical_orig, y_clinical_pred, 
           alpha=0.6, s=80, color='#2E86AB', edgecolors='white', linewidth=0.5)

# Perfect prediction line (diagonal)
min_val = min(y_v04_clinical_orig.min(), y_clinical_pred.min())
max_val = max(y_v04_clinical_orig.max(), y_clinical_pred.max())
ax.plot([min_val, max_val], [min_val, max_val], 
        'k--', linewidth=2, label='Perfect Prediction', alpha=0.7)

# Axis labels (İngilizce, okunaklı)
ax.set_xlabel('Actual UPDRS Part III at 12 Months', fontsize=14, fontweight='bold')
ax.set_ylabel('Predicted UPDRS Part III at 12 Months', fontsize=14, fontweight='bold')

# Grid
ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)

# Metrik kutusu (sağ üst)
textstr = f'$R^2$ = {clinical_r2:.3f}\nMAE = {clinical_mae:.2f}\nn = {len(y_v04_clinical_orig)}'
props = dict(boxstyle='round', facecolor='white', alpha=0.9, edgecolor='gray', linewidth=1.5)
ax.text(0.05, 0.95, textstr, transform=ax.transAxes, fontsize=13,
        verticalalignment='top', bbox=props, family='monospace')

# Legend
ax.legend(loc='lower right', frameon=True, shadow=True, fontsize=12)

# Subtitle (Üst kısım) - Clinical Validation Set
ax.text(0.5, 1.02, 'Independent Clinical Validation Set (n=78)', 
        transform=ax.transAxes, ha='center', fontsize=13, 
        style='italic', color='#333333', fontweight='normal')

# Axis limits (eşit)
ax.set_xlim(min_val - 2, max_val + 2)
ax.set_ylim(min_val - 2, max_val + 2)
ax.set_aspect('equal', adjustable='box')

# Tight layout
plt.tight_layout()

# Kaydet
output_file = 'figures/Figure_01_Predicted_vs_Actual_Clinical.png'
plt.savefig(output_file, dpi=300, bbox_inches='tight', facecolor='white')
print(f"\n✓ Grafik kaydedildi: {output_file}")

plt.close()

print("\n" + "=" * 80)
print("GRAFİK 1 TAMAMLANDI!")
print("=" * 80)
print(f"\nDosya: {output_file}")
print(f"Çözünürlük: 300 DPI")
print(f"Boyut: 8x8 inch")
print(f"Format: PNG")
print(f"Dil: İngilizce")
print(f"Ana başlık: Yok (caption'da olacak)")
