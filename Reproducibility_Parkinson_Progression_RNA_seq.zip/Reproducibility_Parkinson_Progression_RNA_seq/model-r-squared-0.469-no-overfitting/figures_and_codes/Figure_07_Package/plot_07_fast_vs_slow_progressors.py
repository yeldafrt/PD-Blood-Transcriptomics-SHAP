"""
Figure 7: Fast vs Slow Progressor Analysis
Parkinson's Disease Progression Prediction Project

This script creates a 4-panel visualization comparing Fast and Slow progressors:
- Panel (a): DELTA_UPDRS distribution with threshold
- Panel (b): Baseline vs Progression rate scatter plot
- Panel (c): Clinical measures comparison (box plots)
- Panel (d): Mean progression trajectories over 12 months

Author: Yelda Fırat
Date: November 2, 2025
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

# Set style
plt.style.use('default')
sns.set_palette("husl")

# Load data
df = pd.read_csv('final_dataset.csv')

# Create Fast/Slow classification (threshold: DELTA_UPDRS >= 5)
df['Progressor_Type'] = df['DELTA_UPDRS'].apply(lambda x: 'Fast' if x >= 5 else 'Slow')

# Split into Fast and Slow groups
fast = df[df['Progressor_Type'] == 'Fast']
slow = df[df['Progressor_Type'] == 'Slow']

# Print statistics
print("=== FAST VS SLOW STATISTICS ===")
print(f"\nTotal Patients: {len(df)}")
print(f"Fast Progressors: {len(fast)} ({len(fast)/len(df)*100:.1f}%)")
print(f"Slow Progressors: {len(slow)} ({len(slow)/len(df)*100:.1f}%)")

print(f"\nFast - UPDRS_BL: {fast['UPDRS_BL'].mean():.2f} ± {fast['UPDRS_BL'].std():.2f}")
print(f"Slow - UPDRS_BL: {slow['UPDRS_BL'].mean():.2f} ± {slow['UPDRS_BL'].std():.2f}")

print(f"\nFast - DELTA_UPDRS: {fast['DELTA_UPDRS'].mean():.2f} ± {fast['DELTA_UPDRS'].std():.2f}")
print(f"Slow - DELTA_UPDRS: {slow['DELTA_UPDRS'].mean():.2f} ± {slow['DELTA_UPDRS'].std():.2f}")

# Statistical tests
t_stat_bl, p_val_bl = stats.ttest_ind(fast['UPDRS_BL'], slow['UPDRS_BL'])
t_stat_delta, p_val_delta = stats.ttest_ind(fast['DELTA_UPDRS'], slow['DELTA_UPDRS'])

print(f"\nt-test UPDRS_BL: t={t_stat_bl:.3f}, p={p_val_bl:.4f}")
print(f"t-test DELTA_UPDRS: t={t_stat_delta:.3f}, p={p_val_delta:.4f}")

# Create 4-panel figure
fig = plt.figure(figsize=(16, 12))
gs = fig.add_gridspec(2, 2, hspace=0.3, wspace=0.3)

# ============================================================
# Panel (a): DELTA_UPDRS Distribution with threshold
# ============================================================
ax1 = fig.add_subplot(gs[0, 0])
bins = np.arange(-10, 30, 2)
ax1.hist(slow['DELTA_UPDRS'], bins=bins, alpha=0.6, color='#3498db', 
         label=f'Slow (n={len(slow)})', edgecolor='white', linewidth=1.5)
ax1.hist(fast['DELTA_UPDRS'], bins=bins, alpha=0.6, color='#e74c3c', 
         label=f'Fast (n={len(fast)})', edgecolor='white', linewidth=1.5)
ax1.axvline(x=5, color='black', linestyle='--', linewidth=2, label='Threshold (ΔUPDRS=5)')
ax1.set_xlabel('ΔUPDRS (12-month progression)', fontsize=13, fontweight='bold')
ax1.set_ylabel('Number of Patients', fontsize=13, fontweight='bold')
ax1.set_title('(a) Progression Rate Distribution', fontsize=14, fontweight='bold', pad=15)
ax1.legend(fontsize=11, frameon=True, shadow=True)
ax1.grid(True, alpha=0.3, linestyle='--')
ax1.tick_params(labelsize=11)

# Add statistics box
stats_text = f'Fast: {fast["DELTA_UPDRS"].mean():.1f}±{fast["DELTA_UPDRS"].std():.1f}\n'
stats_text += f'Slow: {slow["DELTA_UPDRS"].mean():.1f}±{slow["DELTA_UPDRS"].std():.1f}\n'
stats_text += f'p < 0.001'
ax1.text(0.98, 0.97, stats_text, transform=ax1.transAxes, fontsize=10,
         verticalalignment='top', horizontalalignment='right',
         bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

# ============================================================
# Panel (b): Baseline vs Progression Scatter
# ============================================================
ax2 = fig.add_subplot(gs[0, 1])
ax2.scatter(slow['UPDRS_BL'], slow['DELTA_UPDRS'], alpha=0.5, s=80, 
           color='#3498db', edgecolors='white', linewidth=1, label='Slow')
ax2.scatter(fast['UPDRS_BL'], fast['DELTA_UPDRS'], alpha=0.5, s=80,
           color='#e74c3c', edgecolors='white', linewidth=1, label='Fast')
ax2.axhline(y=5, color='black', linestyle='--', linewidth=2, alpha=0.7)
ax2.set_xlabel('Baseline UPDRS Part III', fontsize=13, fontweight='bold')
ax2.set_ylabel('ΔUPDRS (12-month progression)', fontsize=13, fontweight='bold')
ax2.set_title('(b) Baseline vs Progression Rate', fontsize=14, fontweight='bold', pad=15)
ax2.legend(fontsize=11, frameon=True, shadow=True)
ax2.grid(True, alpha=0.3, linestyle='--')
ax2.tick_params(labelsize=11)

# Correlation
corr_fast = fast[['UPDRS_BL', 'DELTA_UPDRS']].corr().iloc[0, 1]
corr_slow = slow[['UPDRS_BL', 'DELTA_UPDRS']].corr().iloc[0, 1]
corr_text = f'r(Fast) = {corr_fast:.3f}\nr(Slow) = {corr_slow:.3f}'
ax2.text(0.02, 0.98, corr_text, transform=ax2.transAxes, fontsize=10,
         verticalalignment='top', horizontalalignment='left',
         bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.8))

# ============================================================
# Panel (c): Box Plot Comparison
# ============================================================
ax3 = fig.add_subplot(gs[1, 0])
data_to_plot = [slow['UPDRS_BL'], fast['UPDRS_BL'], 
                slow['UPDRS_V04'], fast['UPDRS_V04'],
                slow['DELTA_UPDRS'], fast['DELTA_UPDRS']]
positions = [1, 2, 4, 5, 7, 8]
colors = ['#3498db', '#e74c3c', '#3498db', '#e74c3c', '#3498db', '#e74c3c']

bp = ax3.boxplot(data_to_plot, positions=positions, widths=0.6, patch_artist=True,
                 showmeans=True, meanline=True,
                 boxprops=dict(linewidth=1.5),
                 whiskerprops=dict(linewidth=1.5),
                 capprops=dict(linewidth=1.5),
                 medianprops=dict(color='darkred', linewidth=2),
                 meanprops=dict(color='darkgreen', linewidth=2, linestyle='--'))

for patch, color in zip(bp['boxes'], colors):
    patch.set_facecolor(color)
    patch.set_alpha(0.6)

ax3.set_xticks([1.5, 4.5, 7.5])
ax3.set_xticklabels(['UPDRS_BL', 'UPDRS_V04', 'ΔUPDRS'], fontsize=12, fontweight='bold')
ax3.set_ylabel('UPDRS Score', fontsize=13, fontweight='bold')
ax3.set_title('(c) Clinical Measures Comparison', fontsize=14, fontweight='bold', pad=15)
ax3.grid(True, alpha=0.3, linestyle='--', axis='y')
ax3.tick_params(labelsize=11)

# Legend
from matplotlib.patches import Patch
legend_elements = [Patch(facecolor='#3498db', alpha=0.6, label='Slow'),
                   Patch(facecolor='#e74c3c', alpha=0.6, label='Fast')]
ax3.legend(handles=legend_elements, fontsize=11, frameon=True, shadow=True)

# ============================================================
# Panel (d): Progression Trajectories
# ============================================================
ax4 = fig.add_subplot(gs[1, 1])

# Calculate mean trajectories
timepoints = [0, 12]  # Baseline and 12 months
slow_means = [slow['UPDRS_BL'].mean(), slow['UPDRS_V04'].mean()]
fast_means = [fast['UPDRS_BL'].mean(), fast['UPDRS_V04'].mean()]
slow_sems = [slow['UPDRS_BL'].sem(), slow['UPDRS_V04'].sem()]
fast_sems = [fast['UPDRS_BL'].sem(), fast['UPDRS_V04'].sem()]

# Plot trajectories
ax4.plot(timepoints, slow_means, 'o-', color='#3498db', linewidth=3, 
         markersize=12, label=f'Slow (n={len(slow)})', markeredgecolor='white', markeredgewidth=2)
ax4.plot(timepoints, fast_means, 'o-', color='#e74c3c', linewidth=3,
         markersize=12, label=f'Fast (n={len(fast)})', markeredgecolor='white', markeredgewidth=2)

# Add error bars (95% CI)
ax4.fill_between(timepoints, 
                 [slow_means[i] - 1.96*slow_sems[i] for i in range(2)],
                 [slow_means[i] + 1.96*slow_sems[i] for i in range(2)],
                 alpha=0.2, color='#3498db')
ax4.fill_between(timepoints,
                 [fast_means[i] - 1.96*fast_sems[i] for i in range(2)],
                 [fast_means[i] + 1.96*fast_sems[i] for i in range(2)],
                 alpha=0.2, color='#e74c3c')

ax4.set_xlabel('Time (months)', fontsize=13, fontweight='bold')
ax4.set_ylabel('UPDRS Part III Score', fontsize=13, fontweight='bold')
ax4.set_title('(d) Mean Progression Trajectories', fontsize=14, fontweight='bold', pad=15)
ax4.set_xticks([0, 12])
ax4.set_xticklabels(['Baseline', '12 Months'], fontsize=11)
ax4.legend(fontsize=11, frameon=True, shadow=True, loc='upper left')
ax4.grid(True, alpha=0.3, linestyle='--')
ax4.tick_params(labelsize=11)

# Add slope annotations
slope_slow = (slow_means[1] - slow_means[0]) / 12
slope_fast = (fast_means[1] - fast_means[0]) / 12
slope_text = f'Slow: {slope_slow:+.2f} pts/month\nFast: {slope_fast:+.2f} pts/month'
ax4.text(0.98, 0.02, slope_text, transform=ax4.transAxes, fontsize=10,
         verticalalignment='bottom', horizontalalignment='right',
         bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.8))

# Main title
fig.suptitle('Fast vs Slow Progressor Analysis\nIndependent Clinical Validation Set (n=392)',
             fontsize=16, fontweight='bold', y=0.995)

# Save figure
plt.savefig('figures/Figure_07_Fast_vs_Slow_Progressors.png', dpi=300, bbox_inches='tight', 
            facecolor='white', edgecolor='none')
print("\n✅ Figure saved: figures/Figure_07_Fast_vs_Slow_Progressors.png")
print(f"   Size: 16×12 inches, 300 DPI")

plt.close()
print("\n✅ Analysis complete!")
