#!/usr/bin/env python3
"""
Parkinson Progresyon Tahmini - Veri Birleştirme ve Özellik Mühendisliği
Adım 3: Klinik + RNA-seq birleştirme, PD risk genleri, Pathway skorları
"""

import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')

print("=" * 80)
print("ADIM 3: VERİ BİRLEŞTİRME VE ÖZELLİK MÜHENDİSLİĞİ")
print("=" * 80)

# Dosya yolları
CLINICAL_FILE = 'clinical_data_processed.csv'
RNASEQ_FILE = 'rnaseq_processed/rnaseq_baseline_filtered.csv'
OUTPUT_FILE = 'final_dataset.csv'

# PD Risk Genleri (ENSG ID'leri)
PD_RISK_GENES = {
    'SNCA': 'ENSG00000145335',    # Alpha-synuclein (Lewy body)
    'LRRK2': 'ENSG00000188906',   # Kinaz (en yaygın mutasyon)
    'GBA': 'ENSG00000177628',     # Glucocerebrosidase (lizozomal)
    'PRKN': 'ENSG00000185345',    # Parkin (mitofaji)
    'PINK1': 'ENSG00000158828',   # Mitokondriyal kinaz
    'PARK7': 'ENSG00000116288',   # DJ-1 (oksidatif stres)
    'VPS35': 'ENSG00000069329'    # Vezikül trafiği
}

# Pathway Genleri
INFLAMMATION_GENES = {
    'IL1A': 'ENSG00000115008',
    'IL1B': 'ENSG00000125538',
    'IL6': 'ENSG00000136244',
    'TNF': 'ENSG00000232810',
    'CXCL5': 'ENSG00000163735',
    'CXCL8': 'ENSG00000169429',
    'NLRP3': 'ENSG00000162711',
    'IL1R1': 'ENSG00000115594',
    'IL1R2': 'ENSG00000115590',
    'IL1RN': 'ENSG00000136689'
}

MITOCHONDRIAL_GENES = {
    'MT-ATP6': 'ENSG00000198899',
    'MT-CO1': 'ENSG00000198804',
    'MT-CO2': 'ENSG00000198712',
    'MT-CO3': 'ENSG00000198938',
    'MT-ND1': 'ENSG00000198888',
    'MT-ND2': 'ENSG00000198763',
    'MT-ND3': 'ENSG00000198840',
    'MT-ND4': 'ENSG00000198886',
    'MT-ND5': 'ENSG00000198786',
    'MT-ND6': 'ENSG00000198695',
    'MT-CYB': 'ENSG00000198727'
}

AUTOPHAGY_GENES = {
    'ATG5': 'ENSG00000057663',
    'ATG7': 'ENSG00000197548',
    'ATG12': 'ENSG00000145782',
    'ATG16L1': 'ENSG00000085563',
    'BECN1': 'ENSG00000126581',
    'SQSTM1': 'ENSG00000161011',
    'LAMP1': 'ENSG00000185896',
    'LAMP2': 'ENSG00000005893',
    'TP53': 'ENSG00000141510',
    'RRAGC': 'ENSG00000116954'
}

# 1. Veri yükleme
print("\n[1/7] Verileri yüklüyorum...")
clinical = pd.read_csv(CLINICAL_FILE)
rnaseq = pd.read_csv(RNASEQ_FILE)

print(f"  Klinik veri: {clinical.shape} ({len(clinical)} hasta)")
print(f"  RNA-seq veri: {rnaseq.shape} ({len(rnaseq)} hasta, {rnaseq.shape[1]-2} gen)")

# 2. PATNO üzerinden birleştirme
print("\n[2/7] Klinik ve RNA-seq verilerini birleştiriyorum...")
# PATNO'ları string'e çevir
clinical['PATNO'] = clinical['PATNO'].astype(str)
rnaseq['PATNO'] = rnaseq['PATNO'].astype(str)

# Inner join - sadece her ikisinde de olan hastalar
merged = pd.merge(clinical, rnaseq, on='PATNO', how='inner')
print(f"  Birleştirilmiş veri: {merged.shape} ({len(merged)} hasta)")

# SampleID sütununu kaldır (artık gerekli değil)
if 'SampleID' in merged.columns:
    merged = merged.drop('SampleID', axis=1)

# 3. PD Risk Genlerini çıkarma
print("\n[3/7] PD risk genlerini çıkarıyorum...")
gene_cols = [col for col in rnaseq.columns if col.startswith('ENSG')]

# Her gen için versiyon numarasıyla eşleştirme
def find_gene_column(gene_id, gene_cols):
    """ENSG ID'sine göre gen sütununu bul (versiyon numarasıyla)"""
    for col in gene_cols:
        if col.startswith(gene_id):
            return col
    return None

pd_risk_features = {}
for gene_name, gene_id in PD_RISK_GENES.items():
    col = find_gene_column(gene_id, gene_cols)
    if col and col in merged.columns:
        pd_risk_features[f'PD_{gene_name}'] = col
        print(f"  ✓ {gene_name} ({gene_id}) → {col}")
    else:
        print(f"  ✗ {gene_name} ({gene_id}) bulunamadı")

# PD risk gen sütunlarını yeniden adlandır
for new_name, old_name in pd_risk_features.items():
    merged[new_name] = merged[old_name]

# 4. Pathway skorlarını hesaplama
print("\n[4/7] Pathway skorlarını hesaplıyorum...")

def calculate_pathway_score(df, pathway_genes, gene_cols):
    """Pathway skoru = pathway genlerinin ortalama ekspresyonu"""
    found_genes = []
    for gene_name, gene_id in pathway_genes.items():
        col = find_gene_column(gene_id, gene_cols)
        if col and col in df.columns:
            found_genes.append(col)
    
    if len(found_genes) > 0:
        score = df[found_genes].mean(axis=1)
        return score, len(found_genes)
    else:
        return pd.Series(0, index=df.index), 0

# İnflamasyon pathway
merged['PATHWAY_Inflammation'], n_inflam = calculate_pathway_score(
    merged, INFLAMMATION_GENES, gene_cols
)
print(f"  ✓ İnflamasyon pathway: {n_inflam}/{len(INFLAMMATION_GENES)} gen bulundu")

# Mitokondriyal pathway
merged['PATHWAY_Mitochondrial'], n_mito = calculate_pathway_score(
    merged, MITOCHONDRIAL_GENES, gene_cols
)
print(f"  ✓ Mitokondriyal pathway: {n_mito}/{len(MITOCHONDRIAL_GENES)} gen bulundu")

# Otofaji pathway
merged['PATHWAY_Autophagy'], n_auto = calculate_pathway_score(
    merged, AUTOPHAGY_GENES, gene_cols
)
print(f"  ✓ Otofaji pathway: {n_auto}/{len(AUTOPHAGY_GENES)} gen bulundu")

# 5. İstatistiksel özellikler
print("\n[5/7] İstatistiksel özellikleri hesaplıyorum...")

# Tüm gen ekspresyon değerlerini al
all_gene_cols = [col for col in merged.columns if col.startswith('ENSG')]

# Toplam ekspresyon
merged['TOTAL_EXPRESSION'] = merged[all_gene_cols].sum(axis=1)

# Ortalama ekspresyon
merged['MEAN_EXPRESSION'] = merged[all_gene_cols].mean(axis=1)

# Standart sapma
merged['STD_EXPRESSION'] = merged[all_gene_cols].std(axis=1)

# Varyasyon katsayısı (CV = STD/MEAN)
merged['CV_EXPRESSION'] = merged['STD_EXPRESSION'] / (merged['MEAN_EXPRESSION'] + 1e-6)

print(f"  ✓ 4 istatistiksel özellik eklendi")

# 6. Final dataset oluşturma
print("\n[6/7] Final dataset'i oluşturuyorum...")

# Özellik sütunlarını seç
feature_cols = ['PATNO']

# Klinik özellikler
clinical_features = ['UPDRS_BL', 'UPDRS_V04', 'DELTA_UPDRS', 'Progressor_Type']
if 'AGE' in merged.columns:
    clinical_features.append('AGE')
if 'GENDER' in merged.columns:
    clinical_features.append('GENDER')
if 'EDUCYRS' in merged.columns:
    clinical_features.append('EDUCYRS')

feature_cols.extend(clinical_features)

# PD risk genleri
pd_risk_cols = [col for col in merged.columns if col.startswith('PD_')]
feature_cols.extend(pd_risk_cols)

# Pathway skorları
pathway_cols = [col for col in merged.columns if col.startswith('PATHWAY_')]
feature_cols.extend(pathway_cols)

# İstatistiksel özellikler
stat_cols = ['TOTAL_EXPRESSION', 'MEAN_EXPRESSION', 'STD_EXPRESSION', 'CV_EXPRESSION']
feature_cols.extend(stat_cols)

# Tüm gen ekspresyon değerleri (opsiyonel - model eğitimi için)
# feature_cols.extend(all_gene_cols)

# Final dataset
final_dataset = merged[feature_cols].copy()

print(f"  Final dataset boyutu: {final_dataset.shape}")
print(f"  Özellik sayısı: {len(feature_cols) - 1} (PATNO hariç)")

# 7. Kaydet
print("\n[7/7] Final dataset'i kaydediyorum...")
final_dataset.to_csv(OUTPUT_FILE, index=False)
print(f"  ✓ Dosya kaydedildi: {OUTPUT_FILE}")
print(f"  Dosya boyutu: {pd.read_csv(OUTPUT_FILE).memory_usage(deep=True).sum() / 1024**2:.2f} MB")

# Özet istatistikler
print("\n" + "=" * 80)
print("ÖZET İSTATİSTİKLER")
print("=" * 80)

print(f"\nToplam hasta sayısı: {len(final_dataset):,}")
print(f"Toplam özellik sayısı: {len(feature_cols) - 1}")

print(f"\nProgressor Dağılımı:")
print(final_dataset['Progressor_Type'].value_counts())

print(f"\nKlinik Özellikler:")
print(final_dataset[['UPDRS_BL', 'UPDRS_V04', 'DELTA_UPDRS']].describe())

if len(pd_risk_cols) > 0:
    print(f"\nPD Risk Genleri (Top 5):")
    print(final_dataset[pd_risk_cols[:5]].describe())

print(f"\nPathway Skorları:")
print(final_dataset[pathway_cols].describe())

print(f"\nİstatistiksel Özellikler:")
print(final_dataset[stat_cols].describe())

# Özellik listesini kaydet
feature_list_file = 'feature_list.txt'
with open(feature_list_file, 'w') as f:
    f.write("# Final Dataset Özellik Listesi\n")
    f.write(f"# Toplam: {len(feature_cols)-1} özellik\n\n")
    
    f.write("## Klinik Özellikler\n")
    for feat in clinical_features:
        f.write(f"{feat}\n")
    
    f.write("\n## PD Risk Genleri\n")
    for feat in pd_risk_cols:
        f.write(f"{feat}\n")
    
    f.write("\n## Pathway Skorları\n")
    for feat in pathway_cols:
        f.write(f"{feat}\n")
    
    f.write("\n## İstatistiksel Özellikler\n")
    for feat in stat_cols:
        f.write(f"{feat}\n")

print(f"\n✓ Özellik listesi kaydedildi: {feature_list_file}")

print("\n" + "=" * 80)
print("VERİ BİRLEŞTİRME VE ÖZELLİK MÜHENDİSLİĞİ TAMAMLANDI!")
print("=" * 80)
