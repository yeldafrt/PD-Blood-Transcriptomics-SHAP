#!/usr/bin/env python3
"""
Parkinson Progresyon Tahmini - RNA-seq Veri İşleme
Adım 2: Quant.zip'ten baseline RNA-seq verilerini çıkarma ve işleme
BELLEK OPTİMİZASYONU: Chunk-based okuma, pool filtreleme, düşük ekspresyon filtreleme
"""

import pandas as pd
import numpy as np
import zipfile
import os
import re
from pathlib import Path
import gc
import warnings
warnings.filterwarnings('ignore')

print("=" * 80)
print("ADIM 2: RNA-SEQ VERİ İŞLEME (BELLEK OPTİMİZE)")
print("=" * 80)

# Konfigürasyon
ZIP_FILE = 'quant.zip'
OUTPUT_DIR = 'rnaseq_processed'
CLINICAL_FILE = 'clinical_data_processed.csv'

# Filtreleme kriterleri
MIN_TPM = 1.0  # Minimum TPM değeri
MIN_SAMPLE_FRACTION = 0.10  # En az %10 örnekte eksprese olmalı

print(f"\n[Konfigürasyon]")
print(f"  ZIP dosyası: {ZIP_FILE}")
print(f"  Minimum TPM: {MIN_TPM}")
print(f"  Minimum örnek oranı: {MIN_SAMPLE_FRACTION}")

# 1. Klinik verileri yükle
print(f"\n[1/8] Klinik verileri yüklüyorum...")
clinical_data = pd.read_csv(CLINICAL_FILE)
clinical_patnos = set(clinical_data['PATNO'].astype(str))
print(f"  Klinik veri hasta sayısı: {len(clinical_patnos):,}")

# 2. ZIP içeriğini tara
print(f"\n[2/8] ZIP içeriğini tarıyorum...")
with zipfile.ZipFile(ZIP_FILE, 'r') as zf:
    all_files = zf.namelist()
    
# Baseline genes.sf dosyalarını filtrele (POOL hariç)
bl_files = [f for f in all_files if '.BL.' in f and '.genes.sf' in f and 'POOL' not in f]
print(f"  Toplam dosya: {len(all_files):,}")
print(f"  Baseline genes.sf (POOL hariç): {len(bl_files):,}")

# 3. PATNO çıkarma ve eşleştirme
print(f"\n[3/8] PATNO'ları çıkarıyorum ve klinik verilerle eşleştiriyorum...")
def extract_patno(filename):
    """Dosya adından PATNO çıkar"""
    match = re.search(r'PPMI-Phase1-IR2\.(\d+)\.BL\.', filename)
    if match:
        return match.group(1)
    return None

# PATNO eşleştirmesi
matched_files = []
for f in bl_files:
    patno = extract_patno(f)
    if patno and patno in clinical_patnos:
        matched_files.append((f, patno))

print(f"  Klinik verilerle eşleşen hasta sayısı: {len(matched_files):,}")

if len(matched_files) == 0:
    print("\n❌ HATA: Hiçbir RNA-seq dosyası klinik verilerle eşleşmedi!")
    print("  İlk birkaç dosya adı:")
    for f in bl_files[:5]:
        patno = extract_patno(f)
        print(f"    {f} → PATNO: {patno}")
    print(f"\n  İlk birkaç klinik PATNO:")
    for p in list(clinical_patnos)[:10]:
        print(f"    {p}")
    exit(1)

# 4. İlk dosyayı oku - gen listesi için
print(f"\n[4/8] Gen listesini alıyorum (ilk dosyadan)...")
first_file, first_patno = matched_files[0]
with zipfile.ZipFile(ZIP_FILE, 'r') as zf:
    with zf.open(first_file) as f:
        first_df = pd.read_csv(f, sep='\t')
        gene_list = first_df['Name'].tolist()
        print(f"  Toplam gen sayısı: {len(gene_list):,}")
        print(f"  İlk 5 gen: {gene_list[:5]}")

# 5. Tüm örnekleri oku ve TPM matrisini oluştur
print(f"\n[5/8] RNA-seq verilerini yüklüyorum (bellek optimizasyonlu)...")
print(f"  Bu işlem birkaç dakika sürebilir...")

tpm_matrix = []
sample_ids = []
patnos = []

with zipfile.ZipFile(ZIP_FILE, 'r') as zf:
    for idx, (filename, patno) in enumerate(matched_files):
        if (idx + 1) % 50 == 0:
            print(f"    İşlenen: {idx + 1}/{len(matched_files)}")
        
        try:
            with zf.open(filename) as f:
                df = pd.read_csv(f, sep='\t', usecols=['Name', 'TPM'])
                df = df.set_index('Name')
                tpm_matrix.append(df['TPM'].values)
                sample_ids.append(filename)
                patnos.append(patno)
        except Exception as e:
            print(f"    ⚠️ Hata (atlıyorum): {filename} - {e}")
            continue

print(f"  ✓ Başarıyla yüklenen örnek sayısı: {len(tpm_matrix):,}")

# TPM matrisini DataFrame'e çevir
tpm_df = pd.DataFrame(tpm_matrix, columns=gene_list)
tpm_df.insert(0, 'PATNO', patnos)
tpm_df.insert(1, 'SampleID', sample_ids)

print(f"  TPM matrisi boyutu: {tpm_df.shape}")
print(f"  Bellek kullanımı: {tpm_df.memory_usage(deep=True).sum() / 1024**3:.2f} GB")

# 6. Düşük ekspresyonlu genleri filtrele
print(f"\n[6/8] Düşük ekspresyonlu genleri filtreliyorum...")
print(f"  Kriter: TPM ≥ {MIN_TPM} en az %{MIN_SAMPLE_FRACTION*100:.0f} örnekte")

n_samples = len(tpm_df)
min_samples = int(n_samples * MIN_SAMPLE_FRACTION)

# Her gen için kaç örnekte eksprese olduğunu say
gene_cols = [col for col in tpm_df.columns if col not in ['PATNO', 'SampleID']]
expressed_counts = (tpm_df[gene_cols] >= MIN_TPM).sum(axis=0)
genes_to_keep = expressed_counts[expressed_counts >= min_samples].index.tolist()

print(f"  Orijinal gen sayısı: {len(gene_cols):,}")
print(f"  Filtrelenen gen sayısı: {len(genes_to_keep):,}")
print(f"  Kalan gen oranı: {len(genes_to_keep)/len(gene_cols)*100:.1f}%")

# Filtrelenmiş matrisi oluştur
tpm_filtered = tpm_df[['PATNO', 'SampleID'] + genes_to_keep].copy()
del tpm_df
gc.collect()

print(f"  Yeni matris boyutu: {tpm_filtered.shape}")
print(f"  Bellek kullanımı: {tpm_filtered.memory_usage(deep=True).sum() / 1024**3:.2f} GB")

# 7. Log2 transformasyon
print(f"\n[7/8] Log2 transformasyon uyguluyorum...")
gene_cols_filtered = [col for col in tpm_filtered.columns if col not in ['PATNO', 'SampleID']]
tpm_filtered[gene_cols_filtered] = np.log2(tpm_filtered[gene_cols_filtered] + 1)
print(f"  ✓ Log2(TPM + 1) transformasyonu tamamlandı")

# 8. Kaydet
print(f"\n[8/8] Sonuçları kaydediyorum...")
os.makedirs(OUTPUT_DIR, exist_ok=True)

output_file = os.path.join(OUTPUT_DIR, 'rnaseq_baseline_filtered.csv')
tpm_filtered.to_csv(output_file, index=False)
print(f"  ✓ Dosya kaydedildi: {output_file}")
print(f"  Dosya boyutu: {os.path.getsize(output_file) / 1024**2:.1f} MB")

# Gen listesini kaydet
gene_list_file = os.path.join(OUTPUT_DIR, 'gene_list_filtered.txt')
with open(gene_list_file, 'w') as f:
    for gene in gene_cols_filtered:
        f.write(f"{gene}\n")
print(f"  ✓ Gen listesi kaydedildi: {gene_list_file}")

# Özet istatistikler
print("\n" + "=" * 80)
print("ÖZET İSTATİSTİKLER")
print("=" * 80)
print(f"\nToplam örnek sayısı: {len(tpm_filtered):,}")
print(f"Toplam gen sayısı: {len(gene_cols_filtered):,}")
print(f"\nEkspresyon İstatistikleri (Log2(TPM+1)):")
print(tpm_filtered[gene_cols_filtered].describe().iloc[:, :5])

print("\n" + "=" * 80)
print("RNA-SEQ VERİ İŞLEME TAMAMLANDI!")
print("=" * 80)
