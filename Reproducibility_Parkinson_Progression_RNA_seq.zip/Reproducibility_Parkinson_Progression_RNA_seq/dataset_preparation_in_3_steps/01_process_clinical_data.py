#!/usr/bin/env python3
"""
Parkinson Progresyon Tahmini - Klinik Veri İşleme
Adım 1: UPDRS, Demographics ve diğer klinik verileri işleme
"""

import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')

print("=" * 80)
print("ADIM 1: KLİNİK VERİLERİ İŞLEME")
print("=" * 80)

# 1. UPDRS Part III (Motor Examination) - Baseline ve V04
print("\n[1/6] UPDRS Part III verilerini yüklüyorum...")
updrs3 = pd.read_csv('MDS-UPDRS_Part_III_31Oct2025.csv', low_memory=False)
print(f"   Toplam satır: {len(updrs3):,}")
print(f"   Sütunlar: {updrs3.columns.tolist()[:10]}...")

# EVENT_ID sütununu kontrol et
print(f"\n   EVENT_ID değerleri: {updrs3['EVENT_ID'].unique()[:20]}")

# Baseline (BL) ve V04 (12 ay) verilerini ayır
updrs_bl = updrs3[updrs3['EVENT_ID'] == 'BL'].copy()
updrs_v04 = updrs3[updrs3['EVENT_ID'] == 'V04'].copy()

print(f"   Baseline (BL) hasta sayısı: {updrs_bl['PATNO'].nunique():,}")
print(f"   V04 (12 ay) hasta sayısı: {updrs_v04['PATNO'].nunique():,}")

# UPDRS Part III toplam skorunu hesapla (33 maddelik motor değerlendirme)
# NP3TOT sütunu varsa kullan, yoksa hesapla
if 'NP3TOT' in updrs_bl.columns:
    updrs_bl_scores = updrs_bl.groupby('PATNO')['NP3TOT'].first().reset_index()
    updrs_bl_scores.columns = ['PATNO', 'UPDRS_BL']
    print(f"   BL skorları NP3TOT sütunundan alındı")
else:
    # NP3 ile başlayan sütunları topla
    np3_cols = [col for col in updrs_bl.columns if col.startswith('NP3') and col != 'NP3TOT']
    updrs_bl_scores = updrs_bl.groupby('PATNO')[np3_cols].sum().sum(axis=1).reset_index()
    updrs_bl_scores.columns = ['PATNO', 'UPDRS_BL']
    print(f"   BL skorları {len(np3_cols)} maddeden hesaplandı")

if 'NP3TOT' in updrs_v04.columns:
    updrs_v04_scores = updrs_v04.groupby('PATNO')['NP3TOT'].first().reset_index()
    updrs_v04_scores.columns = ['PATNO', 'UPDRS_V04']
else:
    np3_cols = [col for col in updrs_v04.columns if col.startswith('NP3') and col != 'NP3TOT']
    updrs_v04_scores = updrs_v04.groupby('PATNO')[np3_cols].sum().sum(axis=1).reset_index()
    updrs_v04_scores.columns = ['PATNO', 'UPDRS_V04']

print(f"   UPDRS_BL ortalama: {updrs_bl_scores['UPDRS_BL'].mean():.2f} ± {updrs_bl_scores['UPDRS_BL'].std():.2f}")
print(f"   UPDRS_V04 ortalama: {updrs_v04_scores['UPDRS_V04'].mean():.2f} ± {updrs_v04_scores['UPDRS_V04'].std():.2f}")

# 2. Demographics (Yaş, Cinsiyet, Eğitim)
print("\n[2/6] Demographics verilerini yüklüyorum...")
demographics = pd.read_csv('Demographics_31Oct2025.csv', low_memory=False)
print(f"   Toplam satır: {len(demographics):,}")

# Demographics al (EVENT_ID filtresi yok, TRANS kullanılıyor)
demo_bl = demographics.copy()
# SEX sütunu varsa GENDER olarak kullan
if 'SEX' in demo_bl.columns and 'GENDER' not in demo_bl.columns:
    demo_bl['GENDER'] = demo_bl['SEX']
demo_cols = ['PATNO', 'BIRTHDT', 'GENDER', 'EDUCYRS']
demo_cols = [col for col in demo_cols if col in demo_bl.columns]
demo_bl = demo_bl[demo_cols].drop_duplicates(subset=['PATNO'])

# Yaş hesapla (eğer doğum tarihi varsa)
if 'BIRTHDT' in demo_bl.columns:
    demo_bl['AGE'] = 2025 - pd.to_datetime(demo_bl['BIRTHDT'], errors='coerce').dt.year
    demo_bl = demo_bl.drop('BIRTHDT', axis=1)

print(f"   Demographics hasta sayısı: {len(demo_bl):,}")
if 'AGE' in demo_bl.columns:
    print(f"   Yaş ortalama: {demo_bl['AGE'].mean():.1f} ± {demo_bl['AGE'].std():.1f}")
if 'GENDER' in demo_bl.columns:
    print(f"   Cinsiyet dağılımı:\n{demo_bl['GENDER'].value_counts()}")

# 3. Primary Clinical Diagnosis
print("\n[3/6] Primary Clinical Diagnosis verilerini yüklüyorum...")
diagnosis = pd.read_csv('Primary_Clinical_Diagnosis_01Nov2025.csv', low_memory=False)
print(f"   Toplam satır: {len(diagnosis):,}")

# Parkinson hastalığı teşhisi olanları filtrele
if 'PRIMDIAG' in diagnosis.columns:
    pd_patients = diagnosis[diagnosis['PRIMDIAG'] == 1]['PATNO'].unique()
    print(f"   Parkinson hastalığı teşhisi olan hasta sayısı: {len(pd_patients):,}")
else:
    pd_patients = diagnosis['PATNO'].unique()
    print(f"   Tüm hastalar dahil edildi: {len(pd_patients):,}")

# 4. Whole Blood Substudy (RNA-seq çalışmasına katılanlar)
print("\n[4/6] Whole Blood Substudy verilerini yüklüyorum...")
blood_substudy = pd.read_csv('Whole_Blood_Substudy_31Oct2025.csv', low_memory=False)
print(f"   Toplam satır: {len(blood_substudy):,}")

# Baseline kan örneği olanları filtrele
blood_bl = blood_substudy[blood_substudy['EVENT_ID'] == 'BL']['PATNO'].unique()
print(f"   Baseline kan örneği olan hasta sayısı: {len(blood_bl):,}")

# 5. Verileri birleştir
print("\n[5/6] Verileri birleştiriyorum...")

# UPDRS skorlarını birleştir
clinical_data = pd.merge(updrs_bl_scores, updrs_v04_scores, on='PATNO', how='inner')
print(f"   Hem BL hem V04 UPDRS'si olan hasta sayısı: {len(clinical_data):,}")

# DELTA_UPDRS hesapla
clinical_data['DELTA_UPDRS'] = clinical_data['UPDRS_V04'] - clinical_data['UPDRS_BL']
print(f"   DELTA_UPDRS ortalama: {clinical_data['DELTA_UPDRS'].mean():.2f} ± {clinical_data['DELTA_UPDRS'].std():.2f}")

# Fast/Slow progressor sınıflandırması
clinical_data['Progressor_Type'] = clinical_data['DELTA_UPDRS'].apply(
    lambda x: 'Fast' if x >= 5 else 'Slow'
)
print(f"\n   Progressor dağılımı:")
print(f"   Fast (ΔUPDRS ≥ 5): {(clinical_data['Progressor_Type'] == 'Fast').sum():,}")
print(f"   Slow (ΔUPDRS < 5): {(clinical_data['Progressor_Type'] == 'Slow').sum():,}")

# Demographics ekle
clinical_data = pd.merge(clinical_data, demo_bl, on='PATNO', how='left')

# Parkinson teşhisi olanları filtrele
clinical_data = clinical_data[clinical_data['PATNO'].isin(pd_patients)]
print(f"   PD teşhisi filtrelemesi sonrası: {len(clinical_data):,}")

# Kan örneği olanları işaretle
clinical_data['Has_Blood_Sample'] = clinical_data['PATNO'].isin(blood_bl)
print(f"   Kan örneği olan hasta sayısı: {clinical_data['Has_Blood_Sample'].sum():,}")

# 6. Kaydet
print("\n[6/6] Sonuçları kaydediyorum...")
output_file = 'clinical_data_processed.csv'
clinical_data.to_csv(output_file, index=False)
print(f"   ✓ Dosya kaydedildi: {output_file}")

# Özet istatistikler
print("\n" + "=" * 80)
print("ÖZET İSTATİSTİKLER")
print("=" * 80)
print(f"\nToplam hasta sayısı: {len(clinical_data):,}")
print(f"Kan örneği olan hasta sayısı: {clinical_data['Has_Blood_Sample'].sum():,}")
print(f"\nProgressor Dağılımı:")
print(clinical_data['Progressor_Type'].value_counts())
print(f"\nUPDRS İstatistikleri:")
print(clinical_data[['UPDRS_BL', 'UPDRS_V04', 'DELTA_UPDRS']].describe())

if 'AGE' in clinical_data.columns:
    print(f"\nYaş İstatistikleri:")
    print(clinical_data['AGE'].describe())

if 'GENDER' in clinical_data.columns:
    print(f"\nCinsiyet Dağılımı:")
    print(clinical_data['GENDER'].value_counts())

print("\n" + "=" * 80)
print("KLİNİK VERİ İŞLEME TAMAMLANDI!")
print("=" * 80)
