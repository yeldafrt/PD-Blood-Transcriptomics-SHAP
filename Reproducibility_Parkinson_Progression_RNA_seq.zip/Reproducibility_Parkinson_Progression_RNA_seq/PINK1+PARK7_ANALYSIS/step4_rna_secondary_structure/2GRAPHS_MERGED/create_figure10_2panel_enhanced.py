#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Figure 10: Enhanced 2-Panel RNA Secondary Structure Figure
High-quality publication figure (300 DPI, optimized for readability)
Created from scratch using stem-loop data
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

# Set high-quality parameters for publication
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 13
plt.rcParams['axes.linewidth'] = 2
plt.rcParams['xtick.major.width'] = 2
plt.rcParams['ytick.major.width'] = 2

# Parse stem-loop data from results files
def parse_stem_loops(filename):
    """Parse stem-loop data from results file"""
    stem_loops = []
    with open(filename, 'r') as f:
        lines = f.readlines()
        
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith('Position:'):
            # Extract position
            pos_str = line.split(':')[1].strip().replace(' bp', '').replace(',', '')
            start, end = map(int, pos_str.split('-'))
            
            # Get structure info
            i += 1
            structure = lines[i].strip().split(':')[1].strip()
            
            # Get energy
            i += 1
            energy = float(lines[i].strip().split(':')[1].strip().replace(' kcal/mol', ''))
            
            # Extract stem length and loop size from structure
            # Format: Stem(Xbp)-Loop(Ynt)-Stem(Xbp)
            parts = structure.split('-')
            stem_len = int(parts[0].split('(')[1].replace('bp)', ''))
            loop_size = int(parts[1].split('(')[1].replace('nt)', ''))
            
            stem_loops.append({
                'start': start,
                'end': end,
                'stem_length': stem_len,
                'loop_size': loop_size,
                'energy': energy,
                'structure': structure
            })
        i += 1
    
    return stem_loops

# Load data
print("Loading PINK1 stem-loop data...")
pink1_stem_loops = parse_stem_loops('/home/ubuntu/upload/ADIM4_RNA Secondary Structure/PINK1_rna_structure_results.txt')
pink1_length = 2657

print("Loading PARK7 stem-loop data...")
park7_stem_loops = parse_stem_loops('/home/ubuntu/upload/ADIM4_RNA Secondary Structure/PARK7_rna_structure_results.txt')
park7_length = 1127

print(f"PINK1: {len(pink1_stem_loops)} stem-loops")
print(f"PARK7: {len(park7_stem_loops)} stem-loops")

# Create 2-panel figure
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(26, 10))

# Color function
def get_color(energy):
    if energy < -10:
        return 'red'  # Very stable
    elif energy < -5:
        return 'orange'  # Stable
    else:
        return 'blue'  # Weak

# ============================================================================
# PANEL (a): PINK1
# ============================================================================

ax1.plot([0, pink1_length], [0, 0], 'k-', linewidth=4, label='mRNA')

for i, sl in enumerate(pink1_stem_loops):
    stem1_start = sl['start']
    stem1_end = sl['start'] + sl['stem_length']
    loop_start = stem1_end
    loop_end = loop_start + sl['loop_size']
    stem2_start = loop_end
    stem2_end = sl['end']
    
    color = get_color(sl['energy'])
    height = 1 + i * 0.35
    
    # Stem1
    ax1.plot([stem1_start, stem1_end], [0, height], color=color, linewidth=2.5, alpha=0.8)
    
    # Loop (arc)
    loop_center = (loop_start + loop_end) / 2
    loop_width = loop_end - loop_start
    arc = mpatches.Arc((loop_center, height), loop_width, height/2, 
                      angle=0, theta1=0, theta2=180, 
                      color=color, linewidth=2.5, alpha=0.8)
    ax1.add_patch(arc)
    
    # Stem2
    ax1.plot([loop_end, stem2_end], [height, 0], color=color, linewidth=2.5, alpha=0.8)
    
    # Label (only for selected structures)
    if i % 10 == 0 or sl['energy'] < -10:
        label_x = (stem1_start + stem2_end) / 2
        ax1.text(label_x, height + 0.5, 
               f"SL{i+1}\n{sl['stem_length']}:{sl['loop_size']}",
               ha='center', va='bottom', fontsize=9, color=color, fontweight='bold')

ax1.set_xlim(-100, pink1_length + 100)
ax1.set_ylim(-2, len(pink1_stem_loops) * 0.35 + 5)
ax1.set_xlabel('Position (bp)', fontsize=16, fontweight='bold')
ax1.set_ylabel('Structure Height', fontsize=16, fontweight='bold')
ax1.set_title('(a) PINK1 - RNA Secondary Structure (Stem-Loop Prediction)\n'
             f'Total: {len(pink1_stem_loops)} stem-loops', 
             fontsize=18, fontweight='bold', pad=20)
ax1.grid(True, alpha=0.3, axis='x', linewidth=1.5)
ax1.tick_params(labelsize=13)

# Legend
legend_elements = [
    mpatches.Patch(facecolor='red', edgecolor='black', linewidth=1.5, label='Very stable (ΔG < -10)'),
    mpatches.Patch(facecolor='orange', edgecolor='black', linewidth=1.5, label='Stable (-10 < ΔG < -5)'),
    mpatches.Patch(facecolor='blue', edgecolor='black', linewidth=1.5, label='Weak (ΔG > -5)')
]
ax1.legend(handles=legend_elements, loc='upper right', fontsize=13, framealpha=0.95, 
          edgecolor='black', fancybox=True)

# ============================================================================
# PANEL (b): PARK7
# ============================================================================

ax2.plot([0, park7_length], [0, 0], 'k-', linewidth=4, label='mRNA')

for i, sl in enumerate(park7_stem_loops):
    stem1_start = sl['start']
    stem1_end = sl['start'] + sl['stem_length']
    loop_start = stem1_end
    loop_end = loop_start + sl['loop_size']
    stem2_start = loop_end
    stem2_end = sl['end']
    
    color = get_color(sl['energy'])
    height = 1 + i * 0.35
    
    # Stem1
    ax2.plot([stem1_start, stem1_end], [0, height], color=color, linewidth=2.5, alpha=0.8)
    
    # Loop (arc)
    loop_center = (loop_start + loop_end) / 2
    loop_width = loop_end - loop_start
    arc = mpatches.Arc((loop_center, height), loop_width, height/2, 
                      angle=0, theta1=0, theta2=180, 
                      color=color, linewidth=2.5, alpha=0.8)
    ax2.add_patch(arc)
    
    # Stem2
    ax2.plot([loop_end, stem2_end], [height, 0], color=color, linewidth=2.5, alpha=0.8)
    
    # Label (only for selected structures)
    if i % 5 == 0 or sl['energy'] < -10:
        label_x = (stem1_start + stem2_end) / 2
        ax2.text(label_x, height + 0.5, 
               f"SL{i+1}\n{sl['stem_length']}:{sl['loop_size']}",
               ha='center', va='bottom', fontsize=9, color=color, fontweight='bold')

ax2.set_xlim(-50, park7_length + 50)
ax2.set_ylim(-2, len(park7_stem_loops) * 0.35 + 5)
ax2.set_xlabel('Position (bp)', fontsize=16, fontweight='bold')
ax2.set_ylabel('Structure Height', fontsize=16, fontweight='bold')
ax2.set_title('(b) PARK7 - RNA Secondary Structure (Stem-Loop Prediction)\n'
             f'Total: {len(park7_stem_loops)} stem-loops', 
             fontsize=18, fontweight='bold', pad=20)
ax2.grid(True, alpha=0.3, axis='x', linewidth=1.5)
ax2.tick_params(labelsize=13)

ax2.legend(handles=legend_elements, loc='upper right', fontsize=13, framealpha=0.95,
          edgecolor='black', fancybox=True)

# Save figure
plt.tight_layout()
output_path = '/home/ubuntu/parkinson_progression/manuscript/Figure_10_RNA_Structure_2Panel_Enhanced.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white', pad_inches=0.3)

print(f"\n✅ Figure 10 (Enhanced 2-Panel) saved successfully!")
print(f"   Path: {output_path}")
print(f"   Resolution: 300 DPI")
print(f"   Size: 26 x 10 inches")
print(f"   Panels: (a) PINK1, (b) PARK7")
print(f"   Quality: Publication-ready, highly readable")

plt.close()
