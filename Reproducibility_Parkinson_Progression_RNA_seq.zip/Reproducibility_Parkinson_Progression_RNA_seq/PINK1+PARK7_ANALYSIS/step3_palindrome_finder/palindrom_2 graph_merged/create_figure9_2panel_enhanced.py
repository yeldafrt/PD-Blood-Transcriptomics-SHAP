#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Figure 9: Enhanced 2-Panel Palindrome Analysis for PINK1 and PARK7
High-quality publication figure (300 DPI, optimized for readability)
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Rectangle
import numpy as np

# Set high-quality parameters for publication
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 11
plt.rcParams['axes.linewidth'] = 1.5
plt.rcParams['xtick.major.width'] = 1.5
plt.rcParams['ytick.major.width'] = 1.5

# PINK1 Data
pink1_palindromes = [
    (27, 4, 'CCGG'), (40, 4, 'CCGG'), (73, 4, 'CCGG'), (77, 8, 'GCCGCGGC'),
    (89, 6, 'CCATGG'), (106, 4, 'GCGC'), (112, 10, 'GGCCGCGGCC'), (122, 4, 'TGCA'),
    (124, 6, 'CAGCTG'), (132, 4, 'TCGA'), (135, 6, 'AGCGCT'), (147, 4, 'GCGC'),
    (162, 12, 'GCCCGGCCGGGC'), (187, 6, 'CGGCCG'), (189, 12, 'GCCGGGCCCGGC'),
    (213, 6, 'CCGCGG'), (234, 4, 'GGCC'), (244, 4, 'CCGG'), (248, 4, 'GCGC'),
    (312, 4, 'GGCC'), (325, 4, 'GCGC'), (332, 4, 'TGCA'), (354, 4, 'GGCC'),
    (365, 4, 'GCGC'), (369, 6, 'GGGCCC'), (378, 6, 'CGGCCG'), (396, 4, 'GGCC'),
    (406, 4, 'CTAG'), (415, 4, 'GGCC'), (422, 4, 'TCGA'), (443, 6, 'GCCGGC'),
    (459, 4, 'GGCC'), (471, 4, 'GATC'), (480, 4, 'AATT'), (502, 4, 'CCGG'),
    (506, 4, 'GGCC'), (533, 4, 'TGCA'), (585, 6, 'CTGCAG'), (612, 4, 'CATG'),
    (653, 4, 'CCGG'), (673, 4, 'GGCC'), (679, 6, 'GGTACC'), (686, 6, 'GTGCAC'),
    (710, 6, 'GAGCTC'), (718, 8, 'GGGGCCCC'), (737, 6, 'TGGCCA'), (809, 4, 'AGCT'),
    (831, 4, 'GGCC'), (892, 4, 'CTAG'), (915, 4, 'CCGG'), (925, 4, 'CGCG'),
    (959, 6, 'GGGCCC'), (967, 6, 'GTCGAC'), (1008, 6, 'AGGCCT'), (1015, 10, 'GGCCATGGCC'),
    (1058, 4, 'GTAC'), (1065, 4, 'GCGC'), (1071, 4, 'GTAC'), (1110, 4, 'CATG'),
    (1119, 8, 'GCTGCAGC'), (1164, 4, 'CGCG'), (1202, 4, 'AGCT'), (1233, 4, 'GATC'),
    (1273, 4, 'GGCC'), (1276, 6, 'CTGCAG'), (1293, 6, 'CAGCTG'), (1299, 4, 'GTAC'),
    (1306, 4, 'GATC'), (1332, 4, 'GGCC'), (1350, 4, 'GGCC'), (1360, 4, 'GGCC'),
    (1453, 4, 'GGCC'), (1464, 4, 'GGCC'), (1483, 4, 'AGCT'), (1499, 4, 'AGCT'),
    (1506, 4, 'TGCA'), (1532, 4, 'ACGT'), (1569, 4, 'GGCC'), (1634, 4, 'ATAT'),
    (1639, 4, 'CTAG'), (1694, 6, 'CGGCCG'), (1706, 12, 'TGTTGGCCAACA'), (1817, 4, 'CATG'),
    (1843, 4, 'TGCA'), (1850, 4, 'AGCT'), (1858, 4, 'AATT'), (1872, 4, 'CATG'),
    (1935, 4, 'GCGC'), (1955, 4, 'CCGG'), (1962, 6, 'AGGCCT'), (2007, 6, 'CTGCAG'),
    (2043, 6, 'TGGCCA'), (2049, 4, 'AGCT'), (2056, 4, 'CTAG'), (2086, 6, 'AGGCCT'),
    (2105, 6, 'GGATCC'), (2112, 4, 'GGCC'), (2197, 4, 'CATG'), (2235, 4, 'CATG'),
    (2246, 4, 'ACGT'), (2268, 4, 'AATT'), (2273, 4, 'CATG'), (2277, 6, 'AGGCCT'),
    (2284, 4, 'GGCC'), (2300, 4, 'AGCT'), (2318, 4, 'AGCT'), (2326, 4, 'AATT'),
    (2330, 6, 'ATTAAT'), (2385, 6, 'TTTAAA'), (2411, 4, 'CTAG'), (2428, 4, 'AATT'),
    (2436, 6, 'AATATT'), (2445, 4, 'TGCA'), (2448, 6, 'AAATTT'), (2458, 6, 'CTGCAG'),
    (2467, 4, 'ACGT'), (2486, 6, 'AATATT'), (2497, 4, 'TTAA'), (2511, 4, 'TATA'),
    (2528, 6, 'AATATT'), (2568, 4, 'CATG'), (2588, 4, 'TATA'), (2592, 4, 'CATG'),
    (2606, 4, 'AGCT'), (2630, 4, 'CATG')
]

pink1_restriction = [
    (121, 'PstI'), (585, 'PstI'), (679, 'KpnI'), (710, 'SacI'), 
    (967, 'SalI'), (1120, 'PstI'), (1276, 'PstI'), (2007, 'PstI'), 
    (2105, 'BamHI'), (2458, 'PstI')
]

# PARK7 Data
park7_palindromes = [
    (31, 6, 'GGTACC'), (42, 4, 'GGCC'), (48, 6, 'GGCGCC'), (70, 4, 'GCGC'),
    (78, 4, 'TGCA'), (93, 4, 'ATAT'), (118, 8, 'AGAGCTCT'), (179, 6, 'TCATGA'),
    (189, 4, 'AGCT'), (197, 4, 'TTAA'), (210, 4, 'TGCA'), (212, 8, 'CAGGCCTG'),
    (235, 4, 'GTAC'), (285, 4, 'TGCA'), (302, 6, 'CATATG'), (338, 4, 'GCGC'),
    (346, 4, 'AATT'), (396, 4, 'CCGG'), (403, 4, 'GGCC'), (423, 4, 'TGCA'),
    (447, 6, 'TCATGA'), (553, 4, 'GGCC'), (570, 4, 'CCGG'), (575, 4, 'GGCC'),
    (586, 4, 'AGCT'), (590, 4, 'TCGA'), (598, 4, 'GCGC'), (602, 6, 'TTGCAA'),
    (665, 4, 'TTAA'), (672, 4, 'CTAG'), (692, 4, 'GATC'), (709, 4, 'GGCC'),
    (762, 4, 'TTAA'), (844, 4, 'AATT'), (853, 4, 'TATA'), (874, 4, 'TGCA'),
    (942, 4, 'AATT'), (947, 4, 'AATT'), (967, 4, 'TGCA'), (975, 4, 'TTAA'),
    (983, 8, 'CCATATGG'), (1052, 4, 'AATT'), (1085, 4, 'AGCT'), 
    (1097, 4, 'TTAA'), (1108, 4, 'TTAA')
]

park7_restriction = [
    (31, 'KpnI'), (119, 'SacI')
]

# Color mapping
def get_color(length):
    if length <= 5:
        return '#4472C4'  # Blue
    elif length <= 7:
        return '#70AD47'  # Green
    elif length <= 9:
        return '#FFC000'  # Orange
    else:
        return '#C00000'  # Red

# Create figure with 2x2 grid (palindromes + restriction sites for each gene)
fig = plt.figure(figsize=(24, 10))
gs = fig.add_gridspec(2, 2, height_ratios=[1.2, 1], hspace=0.35, wspace=0.25)

# ============================================================================
# PANEL (a): PINK1 - Top: Palindromes, Bottom: Restriction Sites
# ============================================================================

# PINK1 Palindromes
ax1 = fig.add_subplot(gs[0, 0])
ax1.set_xlim(0, 2657)
ax1.set_ylim(-0.5, 1.5)
ax1.axhline(y=0, color='black', linewidth=2)
ax1.set_xlabel('Position (bp)', fontsize=14, fontweight='bold')
ax1.set_title('(a) PINK1 - Palindrome Map (CFG Analysis)\nTotal: 125 palindromes', 
              fontsize=16, fontweight='bold', pad=15)
ax1.grid(True, alpha=0.25, linestyle='--')

for pos, length, seq in pink1_palindromes:
    color = get_color(length)
    ax1.add_patch(Rectangle((pos, -0.15), length, 0.3, 
                            facecolor=color, edgecolor='black', linewidth=0.8))
    if length >= 10:
        ax1.text(pos + length/2, 0.5, f'{length}bp', 
                ha='center', va='bottom', fontsize=9, fontweight='bold')

legend_elements = [
    mpatches.Patch(facecolor='#C00000', edgecolor='black', label='≥10 bp'),
    mpatches.Patch(facecolor='#FFC000', edgecolor='black', label='8-9 bp'),
    mpatches.Patch(facecolor='#70AD47', edgecolor='black', label='6-7 bp'),
    mpatches.Patch(facecolor='#4472C4', edgecolor='black', label='4-5 bp')
]
ax1.legend(handles=legend_elements, loc='upper right', fontsize=11, framealpha=0.9)
ax1.set_yticks([])
ax1.spines['top'].set_visible(False)
ax1.spines['left'].set_visible(False)
ax1.spines['right'].set_visible(False)

# PINK1 Restriction Sites
ax2 = fig.add_subplot(gs[1, 0])
ax2.set_xlim(0, 2657)
ax2.set_ylim(-1.5, 1.5)
ax2.axhline(y=0, color='black', linewidth=2.5)
ax2.set_xlabel('Position (bp)', fontsize=14, fontweight='bold')
ax2.set_title('PINK1 - Restriction Enzyme Sites (Total: 20 sites)', 
              fontsize=14, fontweight='bold', pad=10)
ax2.grid(True, alpha=0.25, linestyle='--')

for pos, enzyme in pink1_restriction:
    ax2.plot([pos, pos], [0, 0.7], 'k-', linewidth=2.5)
    ax2.text(pos, 0.75, enzyme, ha='center', va='bottom', fontsize=10, 
            rotation=45, fontweight='bold')
    ax2.plot([pos, pos], [0, -0.7], 'k-', linewidth=2.5)
    ax2.text(pos, -0.75, enzyme, ha='center', va='top', fontsize=10, 
            rotation=45, fontweight='bold')

ax2.text(2550, 0.7, '+ strand', ha='right', va='bottom', fontsize=12, 
        fontweight='bold', style='italic')
ax2.text(2550, -0.7, '- strand', ha='right', va='top', fontsize=12, 
        fontweight='bold', style='italic')
ax2.set_yticks([])
ax2.spines['top'].set_visible(False)
ax2.spines['left'].set_visible(False)
ax2.spines['right'].set_visible(False)

# ============================================================================
# PANEL (b): PARK7 - Top: Palindromes, Bottom: Restriction Sites
# ============================================================================

# PARK7 Palindromes
ax3 = fig.add_subplot(gs[0, 1])
ax3.set_xlim(0, 1127)
ax3.set_ylim(-0.5, 1.5)
ax3.axhline(y=0, color='black', linewidth=2)
ax3.set_xlabel('Position (bp)', fontsize=14, fontweight='bold')
ax3.set_title('(b) PARK7 - Palindrome Map (CFG Analysis)\nTotal: 45 palindromes', 
              fontsize=16, fontweight='bold', pad=15)
ax3.grid(True, alpha=0.25, linestyle='--')

for pos, length, seq in park7_palindromes:
    color = get_color(length)
    ax3.add_patch(Rectangle((pos, -0.15), length, 0.3, 
                            facecolor=color, edgecolor='black', linewidth=0.8))
    if length >= 8:
        ax3.text(pos + length/2, 0.5, f'{length}bp', 
                ha='center', va='bottom', fontsize=9, fontweight='bold')

ax3.legend(handles=legend_elements, loc='upper right', fontsize=11, framealpha=0.9)
ax3.set_yticks([])
ax3.spines['top'].set_visible(False)
ax3.spines['left'].set_visible(False)
ax3.spines['right'].set_visible(False)

# PARK7 Restriction Sites
ax4 = fig.add_subplot(gs[1, 1])
ax4.set_xlim(0, 1127)
ax4.set_ylim(-1.5, 1.5)
ax4.axhline(y=0, color='black', linewidth=2.5)
ax4.set_xlabel('Position (bp)', fontsize=14, fontweight='bold')
ax4.set_title('PARK7 - Restriction Enzyme Sites (Total: 4 sites)', 
              fontsize=14, fontweight='bold', pad=10)
ax4.grid(True, alpha=0.25, linestyle='--')

for pos, enzyme in park7_restriction:
    ax4.plot([pos, pos], [0, 0.7], 'k-', linewidth=2.5)
    ax4.text(pos, 0.75, enzyme, ha='center', va='bottom', fontsize=10, 
            rotation=45, fontweight='bold')
    ax4.plot([pos, pos], [0, -0.7], 'k-', linewidth=2.5)
    ax4.text(pos, -0.75, enzyme, ha='center', va='top', fontsize=10, 
            rotation=45, fontweight='bold')

ax4.text(1050, 0.7, '+ strand', ha='right', va='bottom', fontsize=12, 
        fontweight='bold', style='italic')
ax4.text(1050, -0.7, '- strand', ha='right', va='top', fontsize=12, 
        fontweight='bold', style='italic')
ax4.set_yticks([])
ax4.spines['top'].set_visible(False)
ax4.spines['left'].set_visible(False)
ax4.spines['right'].set_visible(False)

# Save figure at 300 DPI
output_path = '/home/ubuntu/parkinson_progression/manuscript/Figure_9_Palindrome_2Panel_Enhanced.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white', pad_inches=0.2)
print(f"✅ Figure 9 (Enhanced 2-Panel) saved successfully!")
print(f"   Path: {output_path}")
print(f"   Resolution: 300 DPI")
print(f"   Size: 24 x 10 inches")
print(f"   Panels: (a) PINK1, (b) PARK7")
print(f"   Quality: Publication-ready, highly readable")

plt.close()
