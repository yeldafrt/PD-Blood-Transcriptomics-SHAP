#!/usr/bin/env python3
"""
Gerçek Hasta PINK1 Analizi

Bir Parkinson hastasının PINK1 RNA-seq verisini analiz et
Referans PINK1 ile karşılaştır
Formal language analysis bulgularını kullanarak yorumla

Yazar: Yelda Fırat
Tarih: 2 Kasım 2025
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

# Dizinler
OUTPUT_DIR = "patient_pink1_analysis"
os.makedirs(OUTPUT_DIR, exist_ok=True)

print("=" * 80)
print("GERÇEK HASTA PINK1 ANALİZİ")
print("=" * 80)

# 1. Veri Yükleme
print("\n[1/5] Veri yükleniyor...")

# Clinical data
clinical = pd.read_csv('../final_dataset.csv', index_col=0)
print(f"  ✓ Klinik veri: {clinical.shape[0]} hasta")

# RNA-seq data
rnaseq = pd.read_csv('../rnaseq_processed/rnaseq_baseline_filtered.csv', index_col=0)
print(f"  ✓ RNA-seq veri: {rnaseq.shape[0]} hasta, {rnaseq.shape[1]-1} gen")

# PINK1 kolonu
PINK1_COL = 'ENSG00000158828.5'
print(f"  ✓ PINK1 gen ID: {PINK1_COL}")

# 2. Fast Progressor Seç
print("\n[2/5] Fast progressor hasta seçiliyor...")

# DELTA_UPDRS hesapla
clinical['DELTA_UPDRS'] = clinical['UPDRS_V04'] - clinical['UPDRS_BL']

# Fast progressors (DELTA_UPDRS >= 5)
fast_progressors = clinical[clinical['DELTA_UPDRS'] >= 5].copy()
print(f"  ✓ Fast progressor sayısı: {len(fast_progressors)}")

# PINK1 ekspresyonu en düşük olanı seç (problem olma ihtimali yüksek)
fast_progressors['PINK1_expr'] = rnaseq.loc[fast_progressors.index, PINK1_COL]
fast_progressors = fast_progressors.sort_values('PINK1_expr')

# İlk hastayı seç
patient_id = fast_progressors.index[0]
patient_data = clinical.loc[patient_id]
patient_pink1 = rnaseq.loc[patient_id, PINK1_COL]

print(f"\n{'='*80}")
print("SEÇİLEN HASTA BİLGİLERİ")
print(f"{'='*80}")
print(f"Hasta ID: {patient_id}")
print(f"Yaş: {patient_data.get('AGE', 'N/A')}")
print(f"Cinsiyet: {patient_data.get('SEX', 'N/A')}")
print(f"Baseline UPDRS Part III: {patient_data['UPDRS_BL']:.1f}")
print(f"12-month UPDRS Part III: {patient_data['UPDRS_V04']:.1f}")
print(f"ΔUPDRS (Progresyon): +{patient_data['DELTA_UPDRS']:.1f} puan")
print(f"Progresyon Hızı: +{patient_data['DELTA_UPDRS']/12:.2f} puan/ay")
print(f"\nPINK1 Ekspresyonu: {patient_pink1:.2f} (log2 TPM)")

# 3. Popülasyon ile Karşılaştırma
print(f"\n[3/5] Popülasyon ile karşılaştırma...")

# Tüm hastaların PINK1 ekspresyonu
all_pink1 = rnaseq[PINK1_COL]
pink1_mean = all_pink1.mean()
pink1_std = all_pink1.std()
pink1_percentile = (all_pink1 < patient_pink1).sum() / len(all_pink1) * 100

print(f"\nPopülasyon İstatistikleri:")
print(f"  Ortalama PINK1: {pink1_mean:.2f}")
print(f"  Std Dev: {pink1_std:.2f}")
print(f"  Min: {all_pink1.min():.2f}")
print(f"  Max: {all_pink1.max():.2f}")

print(f"\nHastanın Durumu:")
print(f"  PINK1 Ekspresyonu: {patient_pink1:.2f}")
print(f"  Z-score: {(patient_pink1 - pink1_mean) / pink1_std:.2f}")
print(f"  Percentile: {pink1_percentile:.1f}%")

if patient_pink1 < pink1_mean - pink1_std:
    status = "⚠️ DÜŞÜK (Ortalamadan 1 SD altında)"
elif patient_pink1 < pink1_mean:
    status = "⚠️ Ortalamanın altında"
elif patient_pink1 > pink1_mean + pink1_std:
    status = "✅ YÜKSEK (Ortalamadan 1 SD üstünde)"
else:
    status = "✅ Normal aralıkta"

print(f"  Durum: {status}")

# 4. Progresyon ile İlişki
print(f"\n[4/5] Progresyon ile ilişki analizi...")

# Fast vs Slow karşılaştırma
slow_progressors = clinical[clinical['DELTA_UPDRS'] < 5].copy()
slow_progressors['PINK1_expr'] = rnaseq.loc[slow_progressors.index, PINK1_COL]

fast_pink1_mean = fast_progressors['PINK1_expr'].mean()
slow_pink1_mean = slow_progressors['PINK1_expr'].mean()

print(f"\nGrup Karşılaştırması:")
print(f"  Fast Progressors (n={len(fast_progressors)}):")
print(f"    Ortalama PINK1: {fast_pink1_mean:.2f}")
print(f"    Ortalama ΔUPDRS: {fast_progressors['DELTA_UPDRS'].mean():.1f}")
print(f"\n  Slow Progressors (n={len(slow_progressors)}):")
print(f"    Ortalama PINK1: {slow_pink1_mean:.2f}")
print(f"    Ortalama ΔUPDRS: {slow_progressors['DELTA_UPDRS'].mean():.1f}")
print(f"\n  Fark: {fast_pink1_mean - slow_pink1_mean:.2f}")

# 5. Formal Language Analysis ile Yorumlama
print(f"\n[5/5] Formal language analysis ile yorumlama...")

print(f"\n{'='*80}")
print("FORMAL LANGUAGE ANALYSIS BULGULARI")
print(f"{'='*80}")

print("\nReferans PINK1 Özellikleri (Bizim Analizden):")
print("  • mRNA uzunluğu: 2,657 bp")
print("  • GC içeriği: 58.52% (yüksek!)")
print("  • Promoter motifler:")
print("    - GC box: 4 adet (Sp1 binding)")
print("    - CAAT box: 5 adet")
print("    - Inr element: 23 adet")
print("  • Palindromlar: 125 adet")
print("  • Restriction sites: 20 adet (PstI: 12)")
print("  • Stem-loop yapıları: 135 adet")
print("  • 5' UTR: 265 bp, GC: 60.00%")
print("  • En kararlı stem-loop: 17-37 bp (ΔG=1.50 kcal/mol)")

print(f"\n{'='*80}")
print("KLİNİK YORUM")
print(f"{'='*80}")

# Düşük ekspresyon yorumu
if patient_pink1 < pink1_mean:
    print("\n⚠️ DÜŞÜK PINK1 EKSPRESYONU TESPİT EDİLDİ")
    print("\nOlası Nedenler:")
    print("  1. Promoter Bölgesi Mutasyonu:")
    print("     • GC box mutasyonu → Sp1 bağlanamaz")
    print("     • CAAT box mutasyonu → NF-Y bağlanamaz")
    print("     • Sonuç: Transkripsiyon azalır")
    
    print("\n  2. Epigenetik Düzenleme:")
    print("     • GC-zengin promoter → CpG metilasyonu")
    print("     • Histone modifikasyonu")
    print("     • Sonuç: Gen susturulur")
    
    print("\n  3. 5' UTR Stem-Loop Problemi:")
    print("     • Kararlı stem-loop → Ribosome engellenebilir")
    print("     • Translasyon verimliliği azalır")
    print("     • Sonuç: Protein üretimi azalır")
    
    print("\n  4. mRNA Stabilitesi:")
    print("     • Palindrom/stem-loop mutasyonu")
    print("     • mRNA hızla yıkılır")
    print("     • Sonuç: Ekspresyon azalır")

print("\nProgresyon Mekanizması:")
print("  PINK1 ↓")
print("    ↓")
print("  Mitokondriyal kalite kontrolü ↓")
print("    ↓")
print("  Hasarlı mitokondri birikimi ↑")
print("    ↓")
print("  ROS (Reaktif oksijen türleri) ↑")
print("    ↓")
print("  Dopaminerjik nöron hasarı ↑")
print("    ↓")
print("  Motor semptomlar kötüleşir (HIZLI PROGRESYON)")

print("\nÖnerilen Klinik Yaklaşım:")
print("  1. ✅ Genetik Test:")
print("     • PINK1 genini dizile (Sanger/NGS)")
print("     • Promoter bölgesini kontrol et (GC box, CAAT box)")
print("     • 5' UTR bölgesini kontrol et (stem-loop)")
print("     • Coding region'ı kontrol et (missense/nonsense)")
print("\n  2. ✅ Epigenetik Analiz:")
print("     • Promoter metilasyon durumu")
print("     • Histone modifikasyonu")
print("\n  3. ✅ Fonksiyonel Testler:")
print("     • Mitokondriyal fonksiyon testleri")
print("     • ROS seviyeleri")
print("     • PINK1 protein seviyesi (Western blot)")
print("\n  4. ✅ Tedavi Seçenekleri:")
print("     • Mitokondriyal koruyucular (Koenzim Q10, Kreatin)")
print("     • Antioksidanlar (Vitamin E, NAC)")
print("     • Gen terapisi (gelecekte)")
print("     • Epigenetik ilaçlar (HDAC inhibitörleri)")

# 6. Görselleştirme
print(f"\n{'='*80}")
print("GÖRSELLEŞTİRME")
print(f"{'='*80}")

fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# (a) PINK1 Ekspresyon Dağılımı
ax = axes[0, 0]
ax.hist(all_pink1, bins=30, alpha=0.7, color='skyblue', edgecolor='black')
ax.axvline(patient_pink1, color='red', linestyle='--', linewidth=2, label=f'Patient {patient_id}')
ax.axvline(pink1_mean, color='green', linestyle='--', linewidth=2, label='Mean')
ax.set_xlabel('PINK1 Expression (log2 TPM)', fontsize=11)
ax.set_ylabel('Number of Patients', fontsize=11)
ax.set_title('(a) PINK1 Expression Distribution', fontsize=12, fontweight='bold')
ax.legend()
ax.grid(True, alpha=0.3)

# (b) Fast vs Slow PINK1
ax = axes[0, 1]
data_to_plot = [fast_progressors['PINK1_expr'].dropna(), slow_progressors['PINK1_expr'].dropna()]
bp = ax.boxplot(data_to_plot, labels=['Fast\nProgressors', 'Slow\nProgressors'],
                patch_artist=True)
bp['boxes'][0].set_facecolor('salmon')
bp['boxes'][1].set_facecolor('lightgreen')
ax.plot(1, patient_pink1, 'r*', markersize=20, label=f'Patient {patient_id}')
ax.set_ylabel('PINK1 Expression (log2 TPM)', fontsize=11)
ax.set_title('(b) Fast vs Slow Progressor PINK1', fontsize=12, fontweight='bold')
ax.legend()
ax.grid(True, alpha=0.3, axis='y')

# (c) PINK1 vs ΔUPDRS
ax = axes[1, 0]
ax.scatter(clinical['DELTA_UPDRS'], rnaseq.loc[clinical.index, PINK1_COL],
          alpha=0.5, s=30, color='gray')
ax.scatter(patient_data['DELTA_UPDRS'], patient_pink1,
          color='red', s=200, marker='*', edgecolor='black', linewidth=1.5,
          label=f'Patient {patient_id}', zorder=10)
ax.set_xlabel('ΔUPDRS (12-month progression)', fontsize=11)
ax.set_ylabel('PINK1 Expression (log2 TPM)', fontsize=11)
ax.set_title('(c) PINK1 vs Progression Relationship', fontsize=12, fontweight='bold')
ax.axhline(pink1_mean, color='green', linestyle='--', alpha=0.5, label='PINK1 Mean')
ax.axvline(5, color='orange', linestyle='--', alpha=0.5, label='Fast/Slow Threshold')
ax.legend()
ax.grid(True, alpha=0.3)

# (d) Hasta Profili
ax = axes[1, 1]
ax.axis('off')

profile_text = f"""
PATIENT PROFILE

Patient ID: {patient_id}
Age: {patient_data.get('AGE', 'N/A')}
Sex: {patient_data.get('SEX', 'N/A')}

CLINICAL STATUS:
• Baseline UPDRS: {patient_data['UPDRS_BL']:.1f}
• 12-month UPDRS: {patient_data['UPDRS_V04']:.1f}
• Progression: +{patient_data['DELTA_UPDRS']:.1f} points
• Rate: +{patient_data['DELTA_UPDRS']/12:.2f} points/month
• Category: FAST PROGRESSOR

PINK1 STATUS:
• Expression: {patient_pink1:.2f}
• Z-score: {(patient_pink1 - pink1_mean) / pink1_std:.2f}
• Percentile: {pink1_percentile:.1f}%
• Status: ⚠️ LOW (1 SD below mean)

FORMAL LANGUAGE ANALYSIS:
• Promoter: GC-rich (4 GC box)
• Palindrome: 125 count
• Stem-loop: 135 count
• 5' UTR: Stable structure (ΔG=1.50)

RECOMMENDATIONS:
✓ Genetic test (PINK1 sequencing)
✓ Promoter/5' UTR mutation screening
✓ Mitochondrial function test
✓ Therapy: Mitochondrial protectors
"""

ax.text(0.05, 0.95, profile_text, transform=ax.transAxes,
       fontsize=9, verticalalignment='top', family='monospace',
       bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.3))

plt.tight_layout()
output_file = 'Figure_12_Patient_41767_Analysis_EN.png'
plt.savefig(output_file, dpi=300, bbox_inches='tight')
print(f"\n✓ Figure saved: {output_file}")

print(f"\n{'='*80}")
print("ANALYSIS COMPLETED!")
print(f"{'='*80}")
print(f"\nOutput: {output_file}")
