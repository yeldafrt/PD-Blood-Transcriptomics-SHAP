#!/usr/bin/env python3
"""
ADIM 1: PINK1 ve PARK7 Genlerinin DNA Dizilerini İndirme

Searls (1992) Formal Dil Teorisi Uygulaması
Parkinson Progresyon Çalışması - Gen Analizi

Yazar: Manus AI
Tarih: 2025-11-02
"""

from Bio import Entrez, SeqIO
import os

# NCBI Entrez ayarları
Entrez.email = "parkinson.research@example.com"  # NCBI gereksinimi
Entrez.api_key = None  # Opsiyonel: Daha hızlı erişim için API key

# Çıktı dizini
OUTPUT_DIR = "sequences"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Analiz edilecek genler
GENES = {
    "PINK1": {
        "gene_id": "65018",  # NCBI Gene ID
        "refseq_mrna": "NM_032409",  # RefSeq mRNA
        "refseq_genomic": "NC_000001",  # Chromosome 1
        "description": "PTEN-induced kinase 1 (mitochondrial quality control)"
    },
    "PARK7": {
        "gene_id": "11315",  # NCBI Gene ID
        "refseq_mrna": "NM_007262",  # RefSeq mRNA
        "refseq_genomic": "NC_000001",  # Chromosome 1
        "description": "Parkinsonism associated deglycase (DJ-1, oxidative stress protection)"
    }
}

def download_sequence(accession, output_file, db="nucleotide", rettype="fasta"):
    """
    NCBI'dan dizi indir
    
    Args:
        accession: RefSeq accession number (örn: NM_032409)
        output_file: Çıktı dosya yolu
        db: Veritabanı (nucleotide, protein)
        rettype: Dönüş tipi (fasta, gb)
    """
    print(f"  İndiriliyor: {accession}...")
    
    try:
        # NCBI'dan dizi çek
        handle = Entrez.efetch(db=db, id=accession, rettype=rettype, retmode="text")
        record = handle.read()
        handle.close()
        
        # Dosyaya yaz
        with open(output_file, 'w') as f:
            f.write(record)
        
        print(f"    ✓ Kaydedildi: {output_file}")
        
        # Dizi bilgilerini göster
        seq_record = SeqIO.read(output_file, "fasta")
        print(f"    Uzunluk: {len(seq_record.seq):,} bp")
        print(f"    ID: {seq_record.id}")
        print(f"    Açıklama: {seq_record.description[:80]}...")
        
        return True
        
    except Exception as e:
        print(f"    ✗ HATA: {e}")
        return False

def download_gene_info(gene_id, gene_name):
    """
    Gen hakkında detaylı bilgi al
    """
    print(f"\n  Gen Bilgisi: {gene_name} (ID: {gene_id})")
    
    try:
        # Gen bilgisini çek
        handle = Entrez.esummary(db="gene", id=gene_id)
        record = Entrez.read(handle)
        handle.close()
        
        doc_sum = record['DocumentSummarySet']['DocumentSummary'][0]
        
        print(f"    Organizma: {doc_sum.get('Organism', 'N/A')}")
        print(f"    Kromozom: {doc_sum.get('Chromosome', 'N/A')}")
        print(f"    Lokasyon: {doc_sum.get('MapLocation', 'N/A')}")
        print(f"    Özet: {doc_sum.get('Summary', 'N/A')[:150]}...")
        
        return doc_sum
        
    except Exception as e:
        print(f"    ✗ HATA: {e}")
        return None

def main():
    """
    Ana fonksiyon: PINK1 ve PARK7 dizilerini indir
    """
    print("=" * 80)
    print("ADIM 1: PINK1 ve PARK7 Genlerinin DNA Dizilerini İndirme")
    print("=" * 80)
    print()
    
    results = {}
    
    for gene_name, gene_info in GENES.items():
        print(f"\n{'='*80}")
        print(f"GEN: {gene_name}")
        print(f"Açıklama: {gene_info['description']}")
        print(f"{'='*80}")
        
        # Gen bilgisini al
        gene_summary = download_gene_info(gene_info['gene_id'], gene_name)
        
        # mRNA dizisini indir
        print(f"\n  [1/2] mRNA Dizisi:")
        mrna_file = os.path.join(OUTPUT_DIR, f"{gene_name}_mRNA.fasta")
        mrna_success = download_sequence(
            gene_info['refseq_mrna'], 
            mrna_file, 
            db="nucleotide", 
            rettype="fasta"
        )
        
        # GenBank formatında detaylı bilgi indir
        print(f"\n  [2/2] GenBank Detaylı Bilgi:")
        gb_file = os.path.join(OUTPUT_DIR, f"{gene_name}_genbank.gb")
        gb_success = download_sequence(
            gene_info['refseq_mrna'], 
            gb_file, 
            db="nucleotide", 
            rettype="gb"
        )
        
        # Sonuçları kaydet
        results[gene_name] = {
            "mrna_file": mrna_file if mrna_success else None,
            "gb_file": gb_file if gb_success else None,
            "gene_summary": gene_summary
        }
    
    # Özet rapor
    print(f"\n\n{'='*80}")
    print("ÖZET RAPOR")
    print(f"{'='*80}\n")
    
    for gene_name, result in results.items():
        print(f"{gene_name}:")
        if result['mrna_file']:
            print(f"  ✓ mRNA: {result['mrna_file']}")
        if result['gb_file']:
            print(f"  ✓ GenBank: {result['gb_file']}")
        print()
    
    # Basit istatistikler
    print(f"\n{'='*80}")
    print("DİZİ İSTATİSTİKLERİ")
    print(f"{'='*80}\n")
    
    for gene_name, result in results.items():
        if result['mrna_file']:
            seq_record = SeqIO.read(result['mrna_file'], "fasta")
            seq = seq_record.seq
            
            # Temel istatistikler
            length = len(seq)
            gc_count = seq.count('G') + seq.count('C')
            gc_percent = (gc_count / length) * 100
            
            print(f"{gene_name}:")
            print(f"  Uzunluk: {length:,} bp")
            print(f"  GC İçeriği: {gc_percent:.2f}%")
            print(f"  A: {seq.count('A'):,} ({seq.count('A')/length*100:.1f}%)")
            print(f"  T: {seq.count('T'):,} ({seq.count('T')/length*100:.1f}%)")
            print(f"  G: {seq.count('G'):,} ({seq.count('G')/length*100:.1f}%)")
            print(f"  C: {seq.count('C'):,} ({seq.count('C')/length*100:.1f}%)")
            print()
    
    print(f"{'='*80}")
    print("ADIM 1 TAMAMLANDI!")
    print(f"{'='*80}")
    print(f"\nDiziler kaydedildi: {OUTPUT_DIR}/")
    print("\nSonraki adım: 02_promoter_analysis.py")

if __name__ == "__main__":
    main()
