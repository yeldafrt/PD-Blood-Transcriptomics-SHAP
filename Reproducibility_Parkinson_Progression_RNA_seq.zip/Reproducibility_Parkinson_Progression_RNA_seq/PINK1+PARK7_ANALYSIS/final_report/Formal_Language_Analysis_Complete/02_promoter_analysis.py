#!/usr/bin/env python3
"""
ADIM 2: Promoter Motif Analizi (Regular Expression)

Searls (1992) Formal Dil Teorisi - Regular Languages Uygulaması
PINK1 ve PARK7 genlerinde promoter ve regulatory motif arama

Yazar: Manus AI
Tarih: 2025-11-02
"""

from Bio import SeqIO
from Bio.Seq import Seq
import re
import os
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# Dizin ayarları
SEQUENCE_DIR = "sequences"
OUTPUT_DIR = "results"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Aranacak motifler (Searls'ün Regular Expression yaklaşımı)
MOTIFS = {
    "TATA_box": {
        "pattern": r"TATA[AT]A[AT]",
        "description": "TATA box (core promoter element)",
        "color": "red",
        "expected_position": "~25-30 bp upstream of TSS"
    },
    "CAAT_box": {
        "pattern": r"[GC]CAAT",
        "description": "CAAT box (enhancer element)",
        "color": "blue",
        "expected_position": "~75-80 bp upstream of TSS"
    },
    "GC_box": {
        "pattern": r"GGGCGG",
        "description": "GC box (Sp1 binding site)",
        "color": "green",
        "expected_position": "Variable"
    },
    "CCAAT_box": {
        "pattern": r"CCAAT",
        "description": "CCAAT box (NF-Y binding)",
        "color": "orange",
        "expected_position": "~60-100 bp upstream"
    },
    "Inr_element": {
        "pattern": r"[CT][CT]A[ACGT][AT][CT][CT]",
        "description": "Initiator element (transcription start)",
        "color": "purple",
        "expected_position": "Around TSS"
    },
    "CpG_island": {
        "pattern": r"(CG){5,}",  # 5 veya daha fazla CG tekrarı
        "description": "CpG island (methylation site)",
        "color": "cyan",
        "expected_position": "Promoter region"
    }
}

def find_motifs(sequence, motif_dict):
    """
    Regular expression ile motif arama
    
    Args:
        sequence: DNA dizisi (string)
        motif_dict: Motif tanımları
    
    Returns:
        dict: Bulunan motifler ve lokasyonları
    """
    results = {}
    
    for motif_name, motif_info in motif_dict.items():
        pattern = motif_info["pattern"]
        matches = []
        
        # Forward strand (+ strand)
        for match in re.finditer(pattern, str(sequence)):
            matches.append({
                "start": match.start(),
                "end": match.end(),
                "sequence": match.group(),
                "strand": "+",
                "position": match.start()
            })
        
        # Reverse complement strand (- strand)
        rev_comp = str(sequence.reverse_complement())
        for match in re.finditer(pattern, rev_comp):
            # Reverse complement pozisyonunu orijinal diziye çevir
            original_start = len(sequence) - match.end()
            original_end = len(sequence) - match.start()
            matches.append({
                "start": original_start,
                "end": original_end,
                "sequence": match.group(),
                "strand": "-",
                "position": original_start
            })
        
        results[motif_name] = {
            "count": len(matches),
            "matches": sorted(matches, key=lambda x: x["position"]),
            "description": motif_info["description"],
            "color": motif_info["color"]
        }
    
    return results

def visualize_motifs(gene_name, sequence_length, motif_results, output_file):
    """
    Motif haritasını görselleştir
    """
    fig, ax = plt.subplots(figsize=(14, 8))
    
    # Dizi çizgisi
    ax.plot([0, sequence_length], [0, 0], 'k-', linewidth=2, label='DNA sequence')
    
    # Her motif için
    y_offset = 0
    legend_elements = []
    
    for motif_name, result in motif_results.items():
        if result["count"] > 0:
            y_offset += 0.5
            color = result["color"]
            
            # Her match için
            for match in result["matches"]:
                # Motif çizgisi
                x_start = match["start"]
                x_end = match["end"]
                
                if match["strand"] == "+":
                    y_pos = y_offset
                    marker = '^'
                else:
                    y_pos = -y_offset
                    marker = 'v'
                
                # Motif kutusu
                rect = mpatches.Rectangle(
                    (x_start, y_pos - 0.1), 
                    x_end - x_start, 
                    0.2, 
                    facecolor=color, 
                    edgecolor='black', 
                    alpha=0.7
                )
                ax.add_patch(rect)
                
                # Strand marker
                ax.plot(x_start, y_pos, marker, color=color, markersize=8)
            
            # Legend
            legend_elements.append(
                mpatches.Patch(
                    facecolor=color, 
                    edgecolor='black', 
                    label=f"{motif_name} (n={result['count']})"
                )
            )
    
    # Grafik ayarları
    ax.set_xlim(-100, sequence_length + 100)
    ax.set_ylim(-y_offset - 1, y_offset + 1)
    ax.set_xlabel('Position (bp)', fontsize=12)
    ax.set_ylabel('Motif Type', fontsize=12)
    ax.set_title(f'{gene_name} - Promoter Motif Map\n(Searls 1992 - Regular Expression Analysis)', 
                 fontsize=14, fontweight='bold')
    ax.legend(handles=legend_elements, loc='upper right', fontsize=10)
    ax.grid(True, alpha=0.3)
    
    # Strand labels
    ax.text(sequence_length + 50, 0.5, '+ strand', fontsize=10, va='center')
    ax.text(sequence_length + 50, -0.5, '- strand', fontsize=10, va='center')
    
    plt.tight_layout()
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"  ✓ Grafik kaydedildi: {output_file}")

def analyze_gene(gene_name, fasta_file):
    """
    Bir genin promoter motif analizini yap
    """
    print(f"\n{'='*80}")
    print(f"GEN: {gene_name}")
    print(f"{'='*80}")
    
    # Diziyi oku
    record = SeqIO.read(fasta_file, "fasta")
    sequence = record.seq
    
    print(f"Dizi uzunluğu: {len(sequence):,} bp")
    print(f"GC içeriği: {(sequence.count('G') + sequence.count('C')) / len(sequence) * 100:.2f}%")
    
    # Motif arama
    print(f"\nMotif aranıyor (Regular Expression)...")
    motif_results = find_motifs(sequence, MOTIFS)
    
    # Sonuçları göster
    print(f"\n{'Motif':<20} {'Count':<10} {'Description'}")
    print(f"{'-'*80}")
    
    total_motifs = 0
    for motif_name, result in motif_results.items():
        count = result["count"]
        desc = result["description"]
        print(f"{motif_name:<20} {count:<10} {desc}")
        total_motifs += count
    
    print(f"{'-'*80}")
    print(f"{'TOPLAM':<20} {total_motifs:<10}")
    
    # Detaylı sonuçlar
    print(f"\n{'='*80}")
    print("DETAYLI SONUÇLAR")
    print(f"{'='*80}")
    
    for motif_name, result in motif_results.items():
        if result["count"] > 0:
            print(f"\n{motif_name} ({result['description']}):")
            print(f"  Toplam: {result['count']} adet")
            print(f"  Lokasyonlar:")
            
            for i, match in enumerate(result["matches"][:5], 1):  # İlk 5 match
                print(f"    [{i}] Pozisyon: {match['start']:,}-{match['end']:,} bp "
                      f"(Strand: {match['strand']}) → {match['sequence']}")
            
            if result["count"] > 5:
                print(f"    ... ve {result['count'] - 5} adet daha")
    
    # Görselleştirme
    print(f"\nGörselleştirme...")
    output_file = os.path.join(OUTPUT_DIR, f"{gene_name}_motif_map.png")
    visualize_motifs(gene_name, len(sequence), motif_results, output_file)
    
    # Sonuçları dosyaya kaydet
    result_file = os.path.join(OUTPUT_DIR, f"{gene_name}_motif_results.txt")
    with open(result_file, 'w') as f:
        f.write(f"{'='*80}\n")
        f.write(f"{gene_name} - Promoter Motif Analysis Results\n")
        f.write(f"Searls (1992) - Regular Expression Approach\n")
        f.write(f"{'='*80}\n\n")
        
        f.write(f"Sequence length: {len(sequence):,} bp\n")
        f.write(f"GC content: {(sequence.count('G') + sequence.count('C')) / len(sequence) * 100:.2f}%\n\n")
        
        f.write(f"{'Motif':<20} {'Count':<10} {'Description'}\n")
        f.write(f"{'-'*80}\n")
        
        for motif_name, result in motif_results.items():
            f.write(f"{motif_name:<20} {result['count']:<10} {result['description']}\n")
        
        f.write(f"\n{'='*80}\n")
        f.write("DETAILED MATCHES\n")
        f.write(f"{'='*80}\n\n")
        
        for motif_name, result in motif_results.items():
            if result["count"] > 0:
                f.write(f"\n{motif_name}:\n")
                for match in result["matches"]:
                    f.write(f"  Position: {match['start']:,}-{match['end']:,} bp "
                           f"(Strand: {match['strand']}) → {match['sequence']}\n")
    
    print(f"  ✓ Sonuçlar kaydedildi: {result_file}")
    
    return motif_results

def main():
    """
    Ana fonksiyon
    """
    print("=" * 80)
    print("ADIM 2: Promoter Motif Analizi (Regular Expression)")
    print("Searls (1992) - Formal Language Theory Application")
    print("=" * 80)
    
    genes = {
        "PINK1": os.path.join(SEQUENCE_DIR, "PINK1_mRNA.fasta"),
        "PARK7": os.path.join(SEQUENCE_DIR, "PARK7_mRNA.fasta")
    }
    
    all_results = {}
    
    for gene_name, fasta_file in genes.items():
        if os.path.exists(fasta_file):
            results = analyze_gene(gene_name, fasta_file)
            all_results[gene_name] = results
        else:
            print(f"\n✗ HATA: {fasta_file} bulunamadı!")
    
    # Karşılaştırmalı özet
    print(f"\n\n{'='*80}")
    print("KARŞILAŞTIRMALI ÖZET")
    print(f"{'='*80}\n")
    
    print(f"{'Motif':<20} {'PINK1':<15} {'PARK7':<15}")
    print(f"{'-'*80}")
    
    for motif_name in MOTIFS.keys():
        pink1_count = all_results.get("PINK1", {}).get(motif_name, {}).get("count", 0)
        park7_count = all_results.get("PARK7", {}).get(motif_name, {}).get("count", 0)
        print(f"{motif_name:<20} {pink1_count:<15} {park7_count:<15}")
    
    print(f"\n{'='*80}")
    print("ADIM 2 TAMAMLANDI!")
    print(f"{'='*80}")
    print(f"\nSonuçlar: {OUTPUT_DIR}/")
    print("\nSonraki adım: 03_palindrome_finder.py (CFG analizi)")

if __name__ == "__main__":
    main()
