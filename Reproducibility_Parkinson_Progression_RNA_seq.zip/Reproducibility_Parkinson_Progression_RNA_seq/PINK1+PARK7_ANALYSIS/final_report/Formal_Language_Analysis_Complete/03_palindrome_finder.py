#!/usr/bin/env python3
"""
ADIM 3: Palindrome Finder (Context-Free Grammar Analizi)

Searls (1992) - CFG Yaklaşımı ile Palindrom Arama
PINK1 ve PARK7 genlerinde restriction enzyme sites ve inverted repeats

CFG Kuralı:
S → aSu | uSa | gSc | cSg | ε

Bu kural palindromik DNA dizilerini üretir (örn: GAATTC)

Yazar: Manus AI
Tarih: 2025-11-02
"""

from Bio import SeqIO
from Bio.Seq import Seq
from Bio import Restriction
import os
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# Dizin ayarları
SEQUENCE_DIR = "sequences"
OUTPUT_DIR = "results"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Yaygın restriction enzyme'ler (palindromik recognition sites)
RESTRICTION_ENZYMES = {
    "EcoRI": "GAATTC",
    "BamHI": "GGATCC",
    "HindIII": "AAGCTT",
    "PstI": "CTGCAG",
    "SmaI": "CCCGGG",
    "KpnI": "GGTACC",
    "SacI": "GAGCTC",
    "XbaI": "TCTAGA",
    "NotI": "GCGGCCGC",
    "XhoI": "CTCGAG",
    "EcoRV": "GATATC",
    "SalI": "GTCGAC"
}

def is_palindrome(seq_str):
    """
    DNA palindromu kontrolü (reverse complement)
    
    CFG Mantığı: S → aSu | uSa | gSc | cSg | ε
    """
    seq = Seq(seq_str)
    rev_comp = str(seq.reverse_complement())
    return seq_str == rev_comp

def find_palindromes(sequence, min_length=4, max_length=12):
    """
    Sliding window ile palindrom arama
    
    CFG-inspired approach:
    - Her pozisyonda k uzunluğunda alt dizi al
    - Palindrom kontrolü yap (CFG kurallarına uygunluk)
    """
    palindromes = []
    seq_str = str(sequence)
    
    # Her uzunluk için
    for length in range(min_length, max_length + 1):
        # Her pozisyon için
        for i in range(len(seq_str) - length + 1):
            subseq = seq_str[i:i+length]
            
            # Palindrom kontrolü
            if is_palindrome(subseq):
                palindromes.append({
                    "start": i,
                    "end": i + length,
                    "length": length,
                    "sequence": subseq,
                    "type": "palindrome"
                })
    
    # Duplicate'leri temizle (aynı pozisyonda farklı uzunluklar)
    # En uzun olanı tut
    unique_palindromes = []
    used_positions = set()
    
    # Uzunluğa göre sırala (uzundan kısaya)
    palindromes.sort(key=lambda x: x["length"], reverse=True)
    
    for pal in palindromes:
        pos = pal["start"]
        if pos not in used_positions:
            unique_palindromes.append(pal)
            # Bu pozisyonu ve çevresini işaretle
            for j in range(pal["start"], pal["end"]):
                used_positions.add(j)
    
    # Pozisyona göre sırala
    unique_palindromes.sort(key=lambda x: x["start"])
    
    return unique_palindromes

def find_restriction_sites(sequence):
    """
    Yaygın restriction enzyme recognition sites ara
    """
    sites = []
    seq_str = str(sequence).upper()
    
    for enzyme_name, recognition_seq in RESTRICTION_ENZYMES.items():
        # Forward strand
        start = 0
        while True:
            pos = seq_str.find(recognition_seq, start)
            if pos == -1:
                break
            sites.append({
                "enzyme": enzyme_name,
                "start": pos,
                "end": pos + len(recognition_seq),
                "sequence": recognition_seq,
                "strand": "+",
                "type": "restriction_site"
            })
            start = pos + 1
        
        # Reverse strand
        rev_seq = str(Seq(recognition_seq).reverse_complement())
        start = 0
        while True:
            pos = seq_str.find(rev_seq, start)
            if pos == -1:
                break
            sites.append({
                "enzyme": enzyme_name,
                "start": pos,
                "end": pos + len(rev_seq),
                "sequence": rev_seq,
                "strand": "-",
                "type": "restriction_site"
            })
            start = pos + 1
    
    sites.sort(key=lambda x: x["start"])
    return sites

def visualize_palindromes(gene_name, sequence_length, palindromes, restriction_sites, output_file):
    """
    Palindrom ve restriction site haritası
    """
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 10))
    
    # Panel 1: Palindromlar
    ax1.plot([0, sequence_length], [0, 0], 'k-', linewidth=2)
    
    if palindromes:
        for pal in palindromes:
            x_start = pal["start"]
            x_end = pal["end"]
            length = pal["length"]
            
            # Renk: uzunluğa göre
            if length >= 8:
                color = 'red'
            elif length >= 6:
                color = 'orange'
            else:
                color = 'blue'
            
            # Palindrom kutusu
            rect = mpatches.Rectangle(
                (x_start, -0.2), 
                x_end - x_start, 
                0.4, 
                facecolor=color, 
                edgecolor='black', 
                alpha=0.7
            )
            ax1.add_patch(rect)
            
            # Uzunluk etiketi
            if length >= 6:
                ax1.text(x_start + (x_end - x_start)/2, 0.6, 
                        f"{length}bp", 
                        ha='center', va='bottom', fontsize=8)
    
    ax1.set_xlim(-100, sequence_length + 100)
    ax1.set_ylim(-1, 2)
    ax1.set_xlabel('Position (bp)', fontsize=12)
    ax1.set_title(f'{gene_name} - Palindrome Map (CFG Analysis)\n'
                  f'Total: {len(palindromes)} palindromes', 
                  fontsize=12, fontweight='bold')
    ax1.grid(True, alpha=0.3)
    
    # Legend
    legend_elements = [
        mpatches.Patch(facecolor='red', edgecolor='black', label='≥8 bp'),
        mpatches.Patch(facecolor='orange', edgecolor='black', label='6-7 bp'),
        mpatches.Patch(facecolor='blue', edgecolor='black', label='4-5 bp')
    ]
    ax1.legend(handles=legend_elements, loc='upper right')
    
    # Panel 2: Restriction Sites
    ax2.plot([0, sequence_length], [0, 0], 'k-', linewidth=2)
    
    if restriction_sites:
        y_offset = 0
        enzyme_colors = {}
        color_palette = ['red', 'blue', 'green', 'orange', 'purple', 'brown', 'pink', 'cyan']
        
        for site in restriction_sites:
            enzyme = site["enzyme"]
            if enzyme not in enzyme_colors:
                enzyme_colors[enzyme] = color_palette[len(enzyme_colors) % len(color_palette)]
            
            color = enzyme_colors[enzyme]
            x_start = site["start"]
            x_end = site["end"]
            
            y_pos = 0.5 if site["strand"] == "+" else -0.5
            
            # Site kutusu
            rect = mpatches.Rectangle(
                (x_start, y_pos - 0.1), 
                x_end - x_start, 
                0.2, 
                facecolor=color, 
                edgecolor='black', 
                alpha=0.8
            )
            ax2.add_patch(rect)
            
            # Enzyme adı
            ax2.text(x_start, y_pos, enzyme, 
                    ha='left', va='center', fontsize=7, 
                    rotation=45)
    
    ax2.set_xlim(-100, sequence_length + 100)
    ax2.set_ylim(-2, 2)
    ax2.set_xlabel('Position (bp)', fontsize=12)
    ax2.set_title(f'{gene_name} - Restriction Enzyme Sites\n'
                  f'Total: {len(restriction_sites)} sites', 
                  fontsize=12, fontweight='bold')
    ax2.grid(True, alpha=0.3)
    
    # Strand labels
    ax2.text(sequence_length + 50, 0.5, '+ strand', fontsize=10, va='center')
    ax2.text(sequence_length + 50, -0.5, '- strand', fontsize=10, va='center')
    
    plt.tight_layout()
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"  ✓ Grafik kaydedildi: {output_file}")

def analyze_gene(gene_name, fasta_file):
    """
    Bir genin palindrom analizini yap
    """
    print(f"\n{'='*80}")
    print(f"GEN: {gene_name}")
    print(f"{'='*80}")
    
    # Diziyi oku
    record = SeqIO.read(fasta_file, "fasta")
    sequence = record.seq
    
    print(f"Dizi uzunluğu: {len(sequence):,} bp")
    
    # Palindrom arama
    print(f"\n[1/2] Palindrom aranıyor (CFG approach)...")
    palindromes = find_palindromes(sequence, min_length=4, max_length=12)
    print(f"  ✓ {len(palindromes)} palindrom bulundu")
    
    # Restriction sites
    print(f"\n[2/2] Restriction enzyme sites aranıyor...")
    restriction_sites = find_restriction_sites(sequence)
    print(f"  ✓ {len(restriction_sites)} restriction site bulundu")
    
    # İstatistikler
    print(f"\n{'='*80}")
    print("İSTATİSTİKLER")
    print(f"{'='*80}")
    
    # Palindrom uzunluk dağılımı
    length_dist = {}
    for pal in palindromes:
        length = pal["length"]
        length_dist[length] = length_dist.get(length, 0) + 1
    
    print(f"\nPalindrom Uzunluk Dağılımı:")
    for length in sorted(length_dist.keys()):
        count = length_dist[length]
        print(f"  {length} bp: {count} adet")
    
    # Restriction enzyme dağılımı
    enzyme_dist = {}
    for site in restriction_sites:
        enzyme = site["enzyme"]
        enzyme_dist[enzyme] = enzyme_dist.get(enzyme, 0) + 1
    
    if enzyme_dist:
        print(f"\nRestriction Enzyme Dağılımı:")
        for enzyme in sorted(enzyme_dist.keys(), key=lambda x: enzyme_dist[x], reverse=True):
            count = enzyme_dist[enzyme]
            print(f"  {enzyme}: {count} adet")
    else:
        print(f"\nRestriction Enzyme: Bulunamadı")
    
    # Detaylı palindromlar
    print(f"\n{'='*80}")
    print("DETAYLI PALINDROMLAR (İlk 10)")
    print(f"{'='*80}")
    
    for i, pal in enumerate(palindromes[:10], 1):
        print(f"\n[{i}] Pozisyon: {pal['start']:,}-{pal['end']:,} bp")
        print(f"    Uzunluk: {pal['length']} bp")
        print(f"    Dizi: {pal['sequence']}")
        print(f"    Rev Comp: {str(Seq(pal['sequence']).reverse_complement())}")
    
    if len(palindromes) > 10:
        print(f"\n... ve {len(palindromes) - 10} adet daha")
    
    # Görselleştirme
    print(f"\nGörselleştirme...")
    output_file = os.path.join(OUTPUT_DIR, f"{gene_name}_palindrome_map.png")
    visualize_palindromes(gene_name, len(sequence), palindromes, restriction_sites, output_file)
    
    # Sonuçları kaydet
    result_file = os.path.join(OUTPUT_DIR, f"{gene_name}_palindrome_results.txt")
    with open(result_file, 'w') as f:
        f.write(f"{'='*80}\n")
        f.write(f"{gene_name} - Palindrome Analysis Results\n")
        f.write(f"Searls (1992) - Context-Free Grammar Approach\n")
        f.write(f"{'='*80}\n\n")
        
        f.write(f"CFG Rule: S → aSu | uSa | gSc | cSg | ε\n\n")
        
        f.write(f"Sequence length: {len(sequence):,} bp\n")
        f.write(f"Total palindromes: {len(palindromes)}\n")
        f.write(f"Total restriction sites: {len(restriction_sites)}\n\n")
        
        f.write(f"{'='*80}\n")
        f.write("PALINDROMES\n")
        f.write(f"{'='*80}\n\n")
        
        for pal in palindromes:
            f.write(f"Position: {pal['start']:,}-{pal['end']:,} bp | "
                   f"Length: {pal['length']} bp | "
                   f"Sequence: {pal['sequence']}\n")
        
        f.write(f"\n{'='*80}\n")
        f.write("RESTRICTION ENZYME SITES\n")
        f.write(f"{'='*80}\n\n")
        
        for site in restriction_sites:
            f.write(f"{site['enzyme']}: Position {site['start']:,}-{site['end']:,} bp "
                   f"(Strand: {site['strand']}) → {site['sequence']}\n")
    
    print(f"  ✓ Sonuçlar kaydedildi: {result_file}")
    
    return palindromes, restriction_sites

def main():
    """
    Ana fonksiyon
    """
    print("=" * 80)
    print("ADIM 3: Palindrome Finder (Context-Free Grammar Analizi)")
    print("Searls (1992) - CFG Approach")
    print("=" * 80)
    print("\nCFG Kuralı: S → aSu | uSa | gSc | cSg | ε")
    print("(Bu kural palindromik DNA dizilerini üretir)")
    
    genes = {
        "PINK1": os.path.join(SEQUENCE_DIR, "PINK1_mRNA.fasta"),
        "PARK7": os.path.join(SEQUENCE_DIR, "PARK7_mRNA.fasta")
    }
    
    all_results = {}
    
    for gene_name, fasta_file in genes.items():
        if os.path.exists(fasta_file):
            palindromes, restriction_sites = analyze_gene(gene_name, fasta_file)
            all_results[gene_name] = {
                "palindromes": palindromes,
                "restriction_sites": restriction_sites
            }
        else:
            print(f"\n✗ HATA: {fasta_file} bulunamadı!")
    
    # Karşılaştırmalı özet
    print(f"\n\n{'='*80}")
    print("KARŞILAŞTIRMALI ÖZET")
    print(f"{'='*80}\n")
    
    print(f"{'Metrik':<30} {'PINK1':<15} {'PARK7':<15}")
    print(f"{'-'*80}")
    
    pink1_pal = len(all_results.get("PINK1", {}).get("palindromes", []))
    park7_pal = len(all_results.get("PARK7", {}).get("palindromes", []))
    print(f"{'Toplam Palindrom':<30} {pink1_pal:<15} {park7_pal:<15}")
    
    pink1_res = len(all_results.get("PINK1", {}).get("restriction_sites", []))
    park7_res = len(all_results.get("PARK7", {}).get("restriction_sites", []))
    print(f"{'Toplam Restriction Site':<30} {pink1_res:<15} {park7_res:<15}")
    
    print(f"\n{'='*80}")
    print("ADIM 3 TAMAMLANDI!")
    print(f"{'='*80}")
    print(f"\nSonuçlar: {OUTPUT_DIR}/")
    print("\nSonraki adım: 04_rna_structure.py (RNA secondary structure)")

if __name__ == "__main__":
    main()
