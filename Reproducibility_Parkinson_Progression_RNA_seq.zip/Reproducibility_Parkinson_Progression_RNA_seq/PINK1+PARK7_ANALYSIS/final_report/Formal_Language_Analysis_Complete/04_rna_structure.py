#!/usr/bin/env python3
"""
ADIM 4: RNA Secondary Structure Analizi

Searls (1992) - PCFG (Probabilistic CFG) Yaklaşımı
PINK1 ve PARK7 mRNA'larının secondary structure tahmini

ViennaRNA olmadığı için basit stem-loop detection kullanıyoruz.

Yazar: Manus AI
Tarih: 2025-11-02
"""

from Bio import SeqIO
from Bio.Seq import Seq
import os
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

# Dizin ayarları
SEQUENCE_DIR = "sequences"
OUTPUT_DIR = "results"
os.makedirs(OUTPUT_DIR, exist_ok=True)

def find_stem_loops(sequence, min_stem_length=4, max_loop_size=10, max_stem_distance=50):
    """
    Basit stem-loop yapıları bul
    
    Stem-loop: Palindromik bölgeler arasında loop
    
    CFG/PCFG Mantığı:
    S → Stem Loop Stem'
    Stem → (base-pair) Stem (base-pair)' | ε
    Loop → N{k} (k nükleotid)
    """
    stem_loops = []
    seq_str = str(sequence)
    n = len(seq_str)
    
    # Her pozisyon için
    for i in range(n - min_stem_length * 2 - max_loop_size):
        # Stem uzunluğu dene
        for stem_len in range(min_stem_length, min(20, (n - i) // 2)):
            # Loop boyutu dene
            for loop_size in range(3, max_loop_size + 1):
                # Stem1 pozisyonu
                stem1_start = i
                stem1_end = i + stem_len
                
                # Loop pozisyonu
                loop_start = stem1_end
                loop_end = loop_start + loop_size
                
                # Stem2 pozisyonu (reverse complement olmalı)
                stem2_start = loop_end
                stem2_end = stem2_start + stem_len
                
                if stem2_end > n:
                    continue
                
                # Stem1 ve Stem2'yi al
                stem1 = seq_str[stem1_start:stem1_end]
                stem2 = seq_str[stem2_start:stem2_end]
                loop_seq = seq_str[loop_start:loop_end]
                
                # Reverse complement kontrolü
                stem1_seq = Seq(stem1)
                stem2_rc = str(Seq(stem2).reverse_complement())
                
                # Base pairing kontrolü (en az %75 match)
                matches = sum(1 for a, b in zip(str(stem1_seq), stem2_rc) if a == b)
                match_ratio = matches / stem_len
                
                if match_ratio >= 0.75:  # En az %75 eşleşme
                    # Free energy tahmini (basit)
                    # GC base pairs: -3 kcal/mol
                    # AT base pairs: -2 kcal/mol
                    energy = 0
                    for a, b in zip(str(stem1_seq), stem2_rc):
                        if a == b:
                            if (a == 'G' and b == 'C') or (a == 'C' and b == 'G'):
                                energy -= 3
                            elif (a == 'A' and b == 'T') or (a == 'T' and b == 'A'):
                                energy -= 2
                    
                    # Loop penalty
                    energy += loop_size * 0.5
                    
                    stem_loops.append({
                        "start": stem1_start,
                        "end": stem2_end,
                        "stem1": stem1,
                        "loop": loop_seq,
                        "stem2": stem2,
                        "stem_length": stem_len,
                        "loop_size": loop_size,
                        "match_ratio": match_ratio,
                        "energy": energy,
                        "structure": f"Stem({stem_len}bp)-Loop({loop_size}nt)-Stem({stem_len}bp)"
                    })
    
    # Overlap'leri temizle - en düşük energy'li olanı tut
    stem_loops.sort(key=lambda x: x["energy"])
    
    unique_stem_loops = []
    used_positions = set()
    
    for sl in stem_loops:
        # Bu pozisyon kullanılmış mı?
        overlap = False
        for pos in range(sl["start"], sl["end"]):
            if pos in used_positions:
                overlap = True
                break
        
        if not overlap:
            unique_stem_loops.append(sl)
            for pos in range(sl["start"], sl["end"]):
                used_positions.add(pos)
    
    # Pozisyona göre sırala
    unique_stem_loops.sort(key=lambda x: x["start"])
    
    return unique_stem_loops

def analyze_utr_regions(sequence, gene_name):
    """
    5' UTR ve 3' UTR bölgelerini analiz et
    
    Not: mRNA dizisinde UTR bölgelerini tam olarak bilmiyoruz,
    bu yüzden ilk 200bp'yi 5' UTR, son 200bp'yi 3' UTR olarak kabul ediyoruz.
    """
    seq_str = str(sequence)
    n = len(seq_str)
    
    # 5' UTR (ilk 200 bp veya dizi uzunluğunun %10'u)
    utr5_len = min(200, n // 10)
    utr5 = seq_str[:utr5_len]
    
    # 3' UTR (son 200 bp veya dizi uzunluğunun %10'u)
    utr3_len = min(200, n // 10)
    utr3 = seq_str[-utr3_len:]
    
    # GC içeriği
    def gc_content(seq):
        return (seq.count('G') + seq.count('C')) / len(seq) * 100
    
    results = {
        "5_UTR": {
            "sequence": utr5,
            "length": utr5_len,
            "gc_content": gc_content(utr5)
        },
        "3_UTR": {
            "sequence": utr3,
            "length": utr3_len,
            "gc_content": gc_content(utr3)
        }
    }
    
    return results

def visualize_rna_structure(gene_name, sequence_length, stem_loops, output_file):
    """
    RNA secondary structure haritası
    """
    fig, ax = plt.subplots(figsize=(14, 8))
    
    # mRNA çizgisi
    ax.plot([0, sequence_length], [0, 0], 'k-', linewidth=3, label='mRNA')
    
    # Stem-loop yapıları
    if stem_loops:
        for i, sl in enumerate(stem_loops):
            stem1_start = sl["start"]
            stem1_end = sl["start"] + sl["stem_length"]
            loop_start = stem1_end
            loop_end = loop_start + sl["loop_size"]
            stem2_start = loop_end
            stem2_end = sl["end"]
            
            # Renk: energy'ye göre
            if sl["energy"] < -10:
                color = 'red'  # Çok kararlı
            elif sl["energy"] < -5:
                color = 'orange'  # Kararlı
            else:
                color = 'blue'  # Zayıf
            
            # Stem-loop yüksekliği
            height = 1 + i * 0.3
            
            # Stem1
            ax.plot([stem1_start, stem1_end], [0, height], color=color, linewidth=2)
            
            # Loop (arc)
            loop_center = (loop_start + loop_end) / 2
            loop_width = loop_end - loop_start
            arc = mpatches.Arc((loop_center, height), loop_width, height/2, 
                              angle=0, theta1=0, theta2=180, 
                              color=color, linewidth=2)
            ax.add_patch(arc)
            
            # Stem2
            ax.plot([loop_end, stem2_end], [height, 0], color=color, linewidth=2)
            
            # Label
            label_x = (stem1_start + stem2_end) / 2
            ax.text(label_x, height + 0.3, 
                   f"SL{i+1}\n{sl['stem_length']}:{sl['loop_size']}\n{sl['energy']:.1f}",
                   ha='center', va='bottom', fontsize=8, color=color)
    
    ax.set_xlim(-100, sequence_length + 100)
    ax.set_ylim(-1, len(stem_loops) + 2)
    ax.set_xlabel('Position (bp)', fontsize=12)
    ax.set_ylabel('Structure Height', fontsize=12)
    ax.set_title(f'{gene_name} - RNA Secondary Structure (Stem-Loop Prediction)\n'
                 f'Total: {len(stem_loops)} stem-loops', 
                 fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, axis='x')
    
    # Legend
    legend_elements = [
        mpatches.Patch(facecolor='red', label='Very stable (ΔG < -10)'),
        mpatches.Patch(facecolor='orange', label='Stable (-10 < ΔG < -5)'),
        mpatches.Patch(facecolor='blue', label='Weak (ΔG > -5)')
    ]
    ax.legend(handles=legend_elements, loc='upper right')
    
    plt.tight_layout()
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"  ✓ Grafik kaydedildi: {output_file}")

def analyze_gene(gene_name, fasta_file):
    """
    Bir genin RNA secondary structure analizini yap
    """
    print(f"\n{'='*80}")
    print(f"GEN: {gene_name}")
    print(f"{'='*80}")
    
    # Diziyi oku
    record = SeqIO.read(fasta_file, "fasta")
    sequence = record.seq
    
    print(f"Dizi uzunluğu: {len(sequence):,} bp")
    
    # UTR analizi
    print(f"\n[1/2] UTR bölgeleri analiz ediliyor...")
    utr_results = analyze_utr_regions(sequence, gene_name)
    
    print(f"  5' UTR: {utr_results['5_UTR']['length']} bp, "
          f"GC: {utr_results['5_UTR']['gc_content']:.2f}%")
    print(f"  3' UTR: {utr_results['3_UTR']['length']} bp, "
          f"GC: {utr_results['3_UTR']['gc_content']:.2f}%")
    
    # Stem-loop arama
    print(f"\n[2/2] Stem-loop yapıları aranıyor...")
    stem_loops = find_stem_loops(sequence)
    print(f"  ✓ {len(stem_loops)} stem-loop bulundu")
    
    # İstatistikler
    print(f"\n{'='*80}")
    print("İSTATİSTİKLER")
    print(f"{'='*80}")
    
    if stem_loops:
        energies = [sl["energy"] for sl in stem_loops]
        stem_lengths = [sl["stem_length"] for sl in stem_loops]
        loop_sizes = [sl["loop_size"] for sl in stem_loops]
        
        print(f"\nEnergy (ΔG):")
        print(f"  Min: {min(energies):.2f} kcal/mol (en kararlı)")
        print(f"  Max: {max(energies):.2f} kcal/mol")
        print(f"  Ortalama: {np.mean(energies):.2f} kcal/mol")
        
        print(f"\nStem Uzunluğu:")
        print(f"  Min: {min(stem_lengths)} bp")
        print(f"  Max: {max(stem_lengths)} bp")
        print(f"  Ortalama: {np.mean(stem_lengths):.1f} bp")
        
        print(f"\nLoop Boyutu:")
        print(f"  Min: {min(loop_sizes)} nt")
        print(f"  Max: {max(loop_sizes)} nt")
        print(f"  Ortalama: {np.mean(loop_sizes):.1f} nt")
    
    # Detaylı stem-loops
    print(f"\n{'='*80}")
    print("DETAYLI STEM-LOOPS (İlk 10, en kararlıdan başlayarak)")
    print(f"{'='*80}")
    
    sorted_stem_loops = sorted(stem_loops, key=lambda x: x["energy"])
    
    for i, sl in enumerate(sorted_stem_loops[:10], 1):
        print(f"\n[{i}] Pozisyon: {sl['start']:,}-{sl['end']:,} bp")
        print(f"    Yapı: {sl['structure']}")
        print(f"    Energy: {sl['energy']:.2f} kcal/mol")
        print(f"    Match ratio: {sl['match_ratio']*100:.1f}%")
        print(f"    Stem1: {sl['stem1']}")
        print(f"    Loop:  {sl['loop']}")
        print(f"    Stem2: {sl['stem2']}")
    
    if len(stem_loops) > 10:
        print(f"\n... ve {len(stem_loops) - 10} adet daha")
    
    # Görselleştirme
    print(f"\nGörselleştirme...")
    output_file = os.path.join(OUTPUT_DIR, f"{gene_name}_rna_structure.png")
    visualize_rna_structure(gene_name, len(sequence), stem_loops, output_file)
    
    # Sonuçları kaydet
    result_file = os.path.join(OUTPUT_DIR, f"{gene_name}_rna_structure_results.txt")
    with open(result_file, 'w') as f:
        f.write(f"{'='*80}\n")
        f.write(f"{gene_name} - RNA Secondary Structure Analysis\n")
        f.write(f"Searls (1992) - PCFG Approach (Simplified)\n")
        f.write(f"{'='*80}\n\n")
        
        f.write(f"Sequence length: {len(sequence):,} bp\n")
        f.write(f"Total stem-loops: {len(stem_loops)}\n\n")
        
        f.write(f"{'='*80}\n")
        f.write("UTR REGIONS\n")
        f.write(f"{'='*80}\n\n")
        
        f.write(f"5' UTR: {utr_results['5_UTR']['length']} bp, "
               f"GC: {utr_results['5_UTR']['gc_content']:.2f}%\n")
        f.write(f"3' UTR: {utr_results['3_UTR']['length']} bp, "
               f"GC: {utr_results['3_UTR']['gc_content']:.2f}%\n\n")
        
        f.write(f"{'='*80}\n")
        f.write("STEM-LOOP STRUCTURES\n")
        f.write(f"{'='*80}\n\n")
        
        for sl in sorted_stem_loops:
            f.write(f"Position: {sl['start']:,}-{sl['end']:,} bp\n")
            f.write(f"Structure: {sl['structure']}\n")
            f.write(f"Energy: {sl['energy']:.2f} kcal/mol\n")
            f.write(f"Stem1: {sl['stem1']}\n")
            f.write(f"Loop:  {sl['loop']}\n")
            f.write(f"Stem2: {sl['stem2']}\n")
            f.write(f"\n")
    
    print(f"  ✓ Sonuçlar kaydedildi: {result_file}")
    
    return stem_loops, utr_results

def main():
    """
    Ana fonksiyon
    """
    print("=" * 80)
    print("ADIM 4: RNA Secondary Structure Analizi")
    print("Searls (1992) - PCFG (Probabilistic CFG) Approach")
    print("=" * 80)
    print("\nNot: ViennaRNA olmadığı için basit stem-loop detection kullanıyoruz.")
    
    genes = {
        "PINK1": os.path.join(SEQUENCE_DIR, "PINK1_mRNA.fasta"),
        "PARK7": os.path.join(SEQUENCE_DIR, "PARK7_mRNA.fasta")
    }
    
    all_results = {}
    
    for gene_name, fasta_file in genes.items():
        if os.path.exists(fasta_file):
            stem_loops, utr_results = analyze_gene(gene_name, fasta_file)
            all_results[gene_name] = {
                "stem_loops": stem_loops,
                "utr_results": utr_results
            }
        else:
            print(f"\n✗ HATA: {fasta_file} bulunamadı!")
    
    # Karşılaştırmalı özet
    print(f"\n\n{'='*80}")
    print("KARŞILAŞTIRMALI ÖZET")
    print(f"{'='*80}\n")
    
    print(f"{'Metrik':<30} {'PINK1':<15} {'PARK7':<15}")
    print(f"{'-'*80}")
    
    pink1_sl = len(all_results.get("PINK1", {}).get("stem_loops", []))
    park7_sl = len(all_results.get("PARK7", {}).get("stem_loops", []))
    print(f"{'Toplam Stem-Loop':<30} {pink1_sl:<15} {park7_sl:<15}")
    
    if pink1_sl > 0:
        pink1_min_energy = min(sl["energy"] for sl in all_results["PINK1"]["stem_loops"])
        print(f"{'En Kararlı (ΔG)':<30} {pink1_min_energy:<15.2f}", end="")
    
    if park7_sl > 0:
        park7_min_energy = min(sl["energy"] for sl in all_results["PARK7"]["stem_loops"])
        print(f" {park7_min_energy:<15.2f}")
    else:
        print()
    
    print(f"\n{'='*80}")
    print("ADIM 4 TAMAMLANDI!")
    print(f"{'='*80}")
    print(f"\nSonuçlar: {OUTPUT_DIR}/")
    print("\nTüm adımlar tamamlandı! Final rapor hazırlanıyor...")

if __name__ == "__main__":
    main()
