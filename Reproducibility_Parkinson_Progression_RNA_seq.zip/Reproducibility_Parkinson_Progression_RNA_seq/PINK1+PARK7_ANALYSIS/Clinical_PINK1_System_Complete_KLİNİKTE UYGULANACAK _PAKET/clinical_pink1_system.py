#!/usr/bin/env python3
"""
Generate Figure 11: Clinical PINK1 Analysis Dashboard (English Version)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import os

# PINK1 Ensembl ID
PINK1_COL = 'ENSG00000158828.5'

def classify_risk(pink1_expr, pink1_mean, pink1_std, delta_updrs):
    """Risk classification"""
    z_score = (pink1_expr - pink1_mean) / pink1_std
    
    if z_score < -2 and delta_updrs >= 10:
        return "VERY HIGH", "critical"
    elif z_score < -1 and delta_updrs >= 5:
        return "HIGH", "high"
    elif z_score < -1 or delta_updrs >= 5:
        return "MEDIUM", "medium"
    else:
        return "LOW", "low"

# Load data
print("Loading data...")
clinical = pd.read_csv('../final_dataset.csv', index_col=0)
rnaseq = pd.read_csv('../rnaseq_processed/rnaseq_baseline_filtered.csv', index_col=0)

# Calculate DELTA_UPDRS
clinical['DELTA_UPDRS'] = clinical['UPDRS_V04'] - clinical['UPDRS_BL']
clinical['PINK1_expr'] = rnaseq.loc[clinical.index, PINK1_COL]

# Population statistics
pink1_mean = clinical['PINK1_expr'].mean()
pink1_std = clinical['PINK1_expr'].std()

# Analyze all patients
print(f"Analyzing {len(clinical)} patients...")
results = []
for patient_id in clinical.index:
    patient = clinical.loc[patient_id]
    risk_level, risk_code = classify_risk(
        patient['PINK1_expr'], pink1_mean, pink1_std, patient['DELTA_UPDRS']
    )
    z_score = (patient['PINK1_expr'] - pink1_mean) / pink1_std
    prog_category = "FAST" if patient['DELTA_UPDRS'] >= 5 else "SLOW"
    prog_rate = patient['DELTA_UPDRS'] / 12
    
    results.append({
        'Patient_ID': patient_id,
        'Delta_UPDRS': patient['DELTA_UPDRS'],
        'Progression_Rate_month': prog_rate,
        'Progression_Category': prog_category,
        'PINK1_Expression': patient['PINK1_expr'],
        'PINK1_Z_Score': z_score,
        'Risk_Level': risk_level,
        'Risk_Code': risk_code
    })

results_df = pd.DataFrame(results)

# Generate Dashboard
print("Generating dashboard...")
fig = plt.figure(figsize=(16, 12))
gs = fig.add_gridspec(3, 3, hspace=0.3, wspace=0.3)

# (a) Risk Distribution - Pie Chart
ax1 = fig.add_subplot(gs[0, 0])
risk_counts = results_df['Risk_Level'].value_counts()
colors_pie = {'VERY HIGH': '#d32f2f', 'HIGH': '#ff9800', 'MEDIUM': '#ffc107', 'LOW': '#4caf50'}
ax1.pie(risk_counts.values, labels=risk_counts.index, autopct='%1.1f%%',
       colors=[colors_pie.get(x, 'gray') for x in risk_counts.index],
       startangle=90)
ax1.set_title('(a) Risk Distribution', fontsize=12, fontweight='bold')

# (b) PINK1 Expression Distribution
ax2 = fig.add_subplot(gs[0, 1])
ax2.hist(results_df['PINK1_Expression'], bins=30, alpha=0.7, color='skyblue', edgecolor='black')
ax2.axvline(pink1_mean, color='green', linestyle='--', linewidth=2, label='Mean')
ax2.axvline(pink1_mean - pink1_std, color='orange', linestyle='--', linewidth=1.5, label='-1 SD')
ax2.axvline(pink1_mean - 2*pink1_std, color='red', linestyle='--', linewidth=1.5, label='-2 SD')
ax2.set_xlabel('PINK1 Expression (log2 TPM)', fontsize=10)
ax2.set_ylabel('Number of Patients', fontsize=10)
ax2.set_title('(b) PINK1 Expression Distribution', fontsize=12, fontweight='bold')
ax2.legend(fontsize=8)
ax2.grid(True, alpha=0.3)

# (c) Fast vs Slow
ax3 = fig.add_subplot(gs[0, 2])
fast = results_df[results_df['Progression_Category'] == 'FAST']['PINK1_Expression']
slow = results_df[results_df['Progression_Category'] == 'SLOW']['PINK1_Expression']
bp = ax3.boxplot([fast, slow], labels=['Fast', 'Slow'], patch_artist=True)
bp['boxes'][0].set_facecolor('salmon')
bp['boxes'][1].set_facecolor('lightgreen')
ax3.set_ylabel('PINK1 Expression', fontsize=10)
ax3.set_title('(c) Fast vs Slow Progressors', fontsize=12, fontweight='bold')
ax3.grid(True, alpha=0.3, axis='y')

# (d) PINK1 vs ΔUPDRS - Risk Colors
ax4 = fig.add_subplot(gs[1, :])
risk_colors = {'critical': '#d32f2f', 'high': '#ff9800', 'medium': '#ffc107', 'low': '#4caf50'}
for risk_code, color in risk_colors.items():
    subset = results_df[results_df['Risk_Code'] == risk_code]
    ax4.scatter(subset['Delta_UPDRS'], subset['PINK1_Expression'],
               alpha=0.6, s=50, color=color,
               label=subset['Risk_Level'].iloc[0] if len(subset) > 0 else risk_code)
ax4.axhline(pink1_mean, color='green', linestyle='--', alpha=0.5, label='PINK1 Mean')
ax4.axhline(pink1_mean - pink1_std, color='orange', linestyle='--', alpha=0.5, label='PINK1 -1 SD')
ax4.axvline(5, color='purple', linestyle='--', alpha=0.5, label='Fast/Slow Threshold')
ax4.set_xlabel('ΔUPDRS (12-month progression)', fontsize=11)
ax4.set_ylabel('PINK1 Expression (log2 TPM)', fontsize=11)
ax4.set_title('(d) PINK1 vs Progression - Risk Stratification', fontsize=13, fontweight='bold')
ax4.legend(loc='best', fontsize=9)
ax4.grid(True, alpha=0.3)

# (e) Risk Level Counts
ax5 = fig.add_subplot(gs[2, 0])
risk_order = ['VERY HIGH', 'HIGH', 'MEDIUM', 'LOW']
risk_counts_ordered = [risk_counts.get(r, 0) for r in risk_order]
bars = ax5.bar(risk_order, risk_counts_ordered,
               color=[colors_pie.get(r, 'gray') for r in risk_order])
ax5.set_ylabel('Number of Patients', fontsize=10)
ax5.set_title('(e) Risk Level Distribution', fontsize=12, fontweight='bold')
ax5.tick_params(axis='x', rotation=45)
for i, v in enumerate(risk_counts_ordered):
    ax5.text(i, v + 2, str(v), ha='center', fontsize=10, fontweight='bold')
ax5.grid(True, alpha=0.3, axis='y')

# (f) Progression Rate Distribution
ax6 = fig.add_subplot(gs[2, 1])
ax6.hist(results_df['Progression_Rate_month'], bins=30, alpha=0.7, color='coral', edgecolor='black')
ax6.axvline(0, color='black', linestyle='-', linewidth=1)
ax6.set_xlabel('Progression Rate (points/month)', fontsize=10)
ax6.set_ylabel('Number of Patients', fontsize=10)
ax6.set_title('(f) Progression Rate Distribution', fontsize=12, fontweight='bold')
ax6.grid(True, alpha=0.3)

# (g) Summary Statistics
ax7 = fig.add_subplot(gs[2, 2])
ax7.axis('off')

summary_text = f"""
SUMMARY STATISTICS

Total Patients: {len(results_df)}

PINK1 Expression:
  Mean: {pink1_mean:.2f}
  Std Dev: {pink1_std:.2f}
  Min: {results_df['PINK1_Expression'].min():.2f}
  Max: {results_df['PINK1_Expression'].max():.2f}

Risk Distribution:
  Very High: {len(results_df[results_df['Risk_Level']=='VERY HIGH'])}
  High: {len(results_df[results_df['Risk_Level']=='HIGH'])}
  Medium: {len(results_df[results_df['Risk_Level']=='MEDIUM'])}
  Low: {len(results_df[results_df['Risk_Level']=='LOW'])}

Progression:
  Fast: {len(results_df[results_df['Progression_Category']=='FAST'])}
  Slow: {len(results_df[results_df['Progression_Category']=='SLOW'])}
"""

ax7.text(0.05, 0.95, summary_text, transform=ax7.transAxes,
        fontsize=9, verticalalignment='top', family='monospace',
        bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.3))

# Title removed as per user request
# plt.suptitle('CLINICAL PINK1 ANALYSIS DASHBOARD\n' + 
#             f'Date: {datetime.now().strftime("%d.%m.%Y %H:%M")}',
#             fontsize=16, fontweight='bold', y=0.98)

output_file = 'Figure_11_Clinical_Dashboard_EN.png'
plt.savefig(output_file, dpi=300, bbox_inches='tight')
plt.close()

print(f"✓ Dashboard saved: {output_file}")
print(f"  - Total patients: {len(results_df)}")
print(f"  - PINK1 mean: {pink1_mean:.2f}, SD: {pink1_std:.2f}")
print(f"  - Risk distribution: Very High={len(results_df[results_df['Risk_Level']=='VERY HIGH'])}, High={len(results_df[results_df['Risk_Level']=='HIGH'])}, Medium={len(results_df[results_df['Risk_Level']=='MEDIUM'])}, Low={len(results_df[results_df['Risk_Level']=='LOW'])}")
