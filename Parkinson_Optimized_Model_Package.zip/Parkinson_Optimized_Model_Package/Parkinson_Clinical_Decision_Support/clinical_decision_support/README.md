# Parkinson's Disease Motor Progression Predictor
## Clinical Decision Support System

![Version](https://img.shields.io/badge/version-1.0-blue)
![Python](https://img.shields.io/badge/python-3.8+-green)
![License](https://img.shields.io/badge/license-Academic-orange)

---

## 🎯 Overview

This Clinical Decision Support System predicts **12-month motor progression** (UPDRS Part III) for Parkinson's disease patients using baseline clinical data and explainable machine learning.

### Key Performance Metrics

- **R² = 0.551** (Independent Clinical Test Set)
- **MAE = 6.01** UPDRS points
- **Training Cohort:** PPMI (n=390 patients)

### Model Architecture

- **Stacking Regressor** combining:
  - XGBoost
  - LightGBM  
  - CatBoost
- **Meta-learner:** Huber Regressor
- **Explainability:** SHAP analysis

---

## 📦 Package Contents

```
Parkinson_Clinical_Decision_Support/
├── model/
│   └── lightweight_optimized_model.pkl    # Trained model (582 KB)
├── scripts/
│   └── predict_patient.py                 # Main prediction script
├── examples/
│   └── example_patients.csv               # Example input data
├── docs/
│   ├── USER_GUIDE.md                      # Comprehensive user guide
│   └── TECHNICAL_DETAILS.md               # Technical documentation
├── data/
│   └── (empty - for your input files)
├── results/
│   └── (predictions will be saved here)
├── README.md                               # This file
└── requirements.txt                        # Python dependencies
```

---

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Run Interactive Mode (Single Patient)

```bash
cd scripts
python predict_patient.py --interactive
```

### 3. Run Batch Mode (Multiple Patients)

```bash
python predict_patient.py --input ../examples/example_patients.csv
```

---

## 💻 Usage Examples

### Interactive Mode

Perfect for single patient predictions:

```bash
python predict_patient.py --interactive
```

You'll be prompted to enter:
- Patient ID (optional)
- Baseline UPDRS Part III score
- Age
- Gender (0=Female, 1=Male)

**Example Output:**
```
PREDICTION RESULTS
====================================================================

Patient ID: PATIENT_001
Baseline UPDRS Part III: 20.0

Predicted UPDRS at 12 months: 26.5
   95% Confidence Interval: [20.5, 32.5]

Predicted Change: +6.5 points
Progression Risk: Moderate Progression

Clinical Interpretation:
   Moderate progression expected (6.5 points). 
   Consider treatment adjustment.
====================================================================
```

### Batch Mode

For multiple patients:

```bash
python predict_patient.py --input patients.csv --output predictions.csv
```

**Input CSV Format:**
```csv
PATNO,UPDRS_BL,AGE,GENDER
PATIENT_001,15.0,65.0,1.0
PATIENT_002,25.0,72.0,0.0
PATIENT_003,10.0,58.0,1.0
```

**Output includes:**
- Predicted UPDRS at 12 months
- Predicted change (Δ UPDRS)
- Progression risk category
- Confidence intervals
- Clinical interpretation

---

## 📊 Understanding Results

### Progression Risk Categories

| Category | Predicted Change | Clinical Action |
|----------|-----------------|-----------------|
| **Stable** | 0 to <3 points | Routine monitoring |
| **Mild** | 3 to <5 points | Standard follow-up |
| **Moderate** | 5 to <10 points | Consider treatment adjustment |
| **Rapid** | ≥10 points | Urgent clinical review |

### Confidence Intervals

95% confidence intervals are provided as:
```
[Predicted UPDRS - 6.01, Predicted UPDRS + 6.01]
```

This reflects the model's MAE of 6.01 points on independent validation.

---

## 📖 Documentation

### User Guide

Comprehensive documentation is available in **`docs/USER_GUIDE.md`**, including:

- ✅ Detailed installation instructions
- ✅ Step-by-step usage examples
- ✅ Input data format specifications
- ✅ Clinical interpretation guidelines
- ✅ Troubleshooting guide
- ✅ FAQ section

### Technical Details

For technical information about the model, see **`docs/TECHNICAL_DETAILS.md`**:

- Model architecture and hyperparameters
- Training methodology
- Feature engineering
- SHAP analysis results
- Performance metrics

---

## ⚙️ System Requirements

### Software

- **Python:** 3.8 or higher
- **Operating System:** Windows, macOS, or Linux

### Python Packages

```
pandas >= 1.3.0
numpy >= 1.21.0
scikit-learn >= 1.0.0
joblib >= 1.0.0
xgboost >= 1.5.0
lightgbm >= 3.3.0
catboost >= 1.0.0
```

### Hardware

- **RAM:** 4 GB minimum (8 GB recommended)
- **Disk Space:** 100 MB
- **Processor:** Any modern CPU (no GPU required)

---

## 🔬 Scientific Background

### Model Training

- **Dataset:** Parkinson's Progression Markers Initiative (PPMI)
- **Sample Size:** n=390 patients
- **Training Set:** n=312 (80%)
- **Test Set:** n=78 (20%, independent)
- **Validation:** 7-fold cross-validation

### Key Features (SHAP Analysis)

Top prognostic factors identified:

1. **UPDRS_BL × PINK1** (SHAP=0.283) - Gene-clinical interaction
2. **Baseline UPDRS** (SHAP=0.258) - Motor severity
3. **VPS35** (SHAP=0.010) - Risk gene
4. **Mitochondrial dysfunction** (SHAP=0.008) - Pathway score
5. **GBA** (SHAP=0.005) - Risk gene

### Performance

| Metric | 7-Fold CV | Independent Test |
|--------|-----------|------------------|
| R² | 0.513 ± 0.052 | **0.551** |
| MAE | 6.15 ± 0.25 | **6.01** |
| RMSE | 7.82 ± 0.31 | 7.45 |

---

## ⚠️ Important Disclaimer

**This tool is intended for research and clinical decision support only.**

- ❌ Should NOT replace clinical judgment
- ❌ Should NOT be the sole basis for treatment decisions
- ✅ Should be combined with clinical expertise
- ✅ Should consider individual patient context

Always consult with qualified healthcare professionals before making treatment decisions.

---

## 🆘 Troubleshooting

### Common Issues

**Problem:** "Model file not found"
```bash
# Solution: Ensure you're in the scripts/ directory
cd scripts
python predict_patient.py --interactive
```

**Problem:** "Missing required packages"
```bash
# Solution: Install all dependencies
pip install -r requirements.txt
```

**Problem:** "Missing critical baseline features"
```bash
# Solution: Ensure your CSV has columns: PATNO, UPDRS_BL, AGE, GENDER
```

For more help, see the **Troubleshooting** section in `docs/USER_GUIDE.md`

---

## 📧 Contact and Support

### Research Team

**Principal Investigator:** [Your Name]  
**Institution:** [Your Institution]  
**Email:** [your.email@institution.edu]

### Citation

If you use this tool, please cite:

```
[Your Name] et al. (2025). Integrating Blood-Based Transcriptomics and 
Explainable Machine Learning to Predict Parkinson's Disease Motor Progression. 
[Journal Name], [Volume]([Issue]), [Pages].
```

### Data Source

Model trained on PPMI data:
> PPMI – a public-private partnership – is funded by the Michael J. Fox Foundation 
> for Parkinson's Research. For more information, visit www.ppmi-info.org.

---

## 📄 License

This software is provided for **research and clinical decision support purposes**.

- ✅ Free for academic and clinical use
- ✅ Modification and redistribution allowed with attribution
- ❌ Commercial use requires permission
- ❌ No warranty provided

---

## 🔄 Version History

### Version 1.0 (November 2025)

- Initial release
- Stacking Regressor model (XGBoost + LightGBM + CatBoost)
- R²=0.551, MAE=6.01 on independent test set
- SHAP-based explainability
- Interactive and batch prediction modes

---

## 🙏 Acknowledgments

This work was made possible by:

- **PPMI Consortium** - For providing high-quality longitudinal data
- **Michael J. Fox Foundation** - For funding PPMI
- **Open Source Community** - For machine learning tools (XGBoost, LightGBM, CatBoost, SHAP)

---

## 📚 Additional Resources

- **PPMI Website:** https://www.ppmi-info.org
- **SHAP Documentation:** https://shap.readthedocs.io
- **Parkinson's Foundation:** https://www.parkinson.org

---

**For detailed instructions, please refer to `docs/USER_GUIDE.md`**

Last updated: November 15, 2025
