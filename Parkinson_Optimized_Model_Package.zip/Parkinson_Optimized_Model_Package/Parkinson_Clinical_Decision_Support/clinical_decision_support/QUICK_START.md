# Quick Start Guide
## Parkinson's Disease Motor Progression Predictor

Get started in 3 simple steps! ⚡

---

## Step 1: Install Dependencies (2 minutes)

Open terminal/command prompt and run:

```bash
pip install -r requirements.txt
```

**Verify installation:**
```bash
python --version  # Should show Python 3.8+
```

---

## Step 2: Try Interactive Mode (1 minute)

Navigate to scripts directory and run:

```bash
cd scripts
python predict_patient.py --interactive
```

**Enter sample data when prompted:**
```
Patient ID: TEST_001
Baseline UPDRS Part III score: 20
Age in years: 68
Gender (0=Female, 1=Male): 1
```

You'll get instant predictions! 🎉

---

## Step 3: Try Batch Mode (1 minute)

Predict for multiple patients:

```bash
python predict_patient.py --input ../examples/example_patients.csv
```

Results saved to `results/predictions.csv`

---

## What's Next?

### For Detailed Instructions
📖 Read the **User Guide**: `docs/USER_GUIDE.md`

### For Clinical Use
- Prepare your patient data in CSV format
- Run batch predictions
- Review risk categories and recommendations

### Need Help?
- Check **Troubleshooting** section in User Guide
- Review example files in `examples/` directory
- Contact support (see README.md)

---

## Input Data Format

Your CSV file needs these columns:

```csv
PATNO,UPDRS_BL,AGE,GENDER
PATIENT_001,15.0,65.0,1.0
PATIENT_002,25.0,72.0,0.0
```

- `PATNO`: Patient ID
- `UPDRS_BL`: Baseline UPDRS Part III score
- `AGE`: Age in years
- `GENDER`: 0=Female, 1=Male

---

## Understanding Results

### Progression Risk Categories

- **Stable** (0-3 points): Routine monitoring
- **Mild** (3-5 points): Standard follow-up
- **Moderate** (5-10 points): Consider treatment adjustment
- **Rapid** (≥10 points): Urgent clinical review

### Example Output

```
Patient ID: PATIENT_001
Baseline UPDRS: 20.0
Predicted UPDRS at 12M: 26.5
Predicted Change: +6.5 points
Risk: Moderate Progression

Interpretation: Consider treatment adjustment
```

---

## Common Commands

```bash
# Interactive mode
python predict_patient.py --interactive

# Batch mode with example data
python predict_patient.py --input ../examples/example_patients.csv

# Custom output file
python predict_patient.py --input patients.csv --output my_results.csv

# Get help
python predict_patient.py --help
```

---

## Troubleshooting

**Problem:** Can't find model file
```bash
# Make sure you're in the scripts/ directory
cd scripts
```

**Problem:** Missing packages
```bash
pip install pandas numpy scikit-learn xgboost lightgbm catboost joblib
```

**Problem:** Wrong Python version
```bash
# Use Python 3.8 or higher
python3 --version
```

---

That's it! You're ready to use the Clinical Decision Support System! 🚀

For detailed documentation, see `docs/USER_GUIDE.md`
