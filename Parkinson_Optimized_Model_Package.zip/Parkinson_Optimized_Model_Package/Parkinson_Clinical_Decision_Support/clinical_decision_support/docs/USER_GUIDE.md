# Parkinson's Disease Motor Progression Predictor
## Clinical Decision Support System - User Guide

**Version:** 1.0  
**Date:** November 2025  
**Model Performance:** R² = 0.551, MAE = 6.01 UPDRS points

---

## Table of Contents

1. [Introduction](#introduction)
2. [System Requirements](#system-requirements)
3. [Installation](#installation)
4. [Quick Start](#quick-start)
5. [Usage Modes](#usage-modes)
6. [Input Data Format](#input-data-format)
7. [Understanding the Results](#understanding-the-results)
8. [Clinical Interpretation](#clinical-interpretation)
9. [Troubleshooting](#troubleshooting)
10. [Frequently Asked Questions](#frequently-asked-questions)
11. [Technical Details](#technical-details)
12. [Contact and Support](#contact-and-support)

---

## Introduction

### What is this tool?

This Clinical Decision Support System predicts **12-month motor progression** for Parkinson's disease patients using baseline clinical data. The system employs an explainable machine learning model (Stacking Regressor) trained on the PPMI cohort (n=390 patients).

### Key Features

- ✅ **Accurate Predictions**: R² = 0.551 on independent clinical test set
- ✅ **Explainable AI**: SHAP analysis reveals key prognostic factors
- ✅ **Easy to Use**: Interactive and batch prediction modes
- ✅ **Clinical Interpretation**: Automatic risk categorization and recommendations
- ✅ **Confidence Intervals**: Uncertainty quantification for each prediction

### Clinical Applications

- **Treatment Planning**: Identify patients at risk of rapid progression
- **Clinical Trial Stratification**: Select appropriate patients for trials
- **Resource Allocation**: Prioritize follow-up for high-risk patients
- **Patient Counseling**: Provide evidence-based progression estimates

### Important Disclaimer

⚠️ **This tool is intended for research and clinical decision support only. It should NOT replace clinical judgment or be used as the sole basis for treatment decisions. Always consult with qualified healthcare professionals.**

---

## System Requirements

### Software Requirements

- **Python**: 3.8 or higher
- **Operating System**: Windows, macOS, or Linux
- **Required Python Packages**:
  - pandas >= 1.3.0
  - numpy >= 1.21.0
  - scikit-learn >= 1.0.0
  - joblib >= 1.0.0
  - xgboost >= 1.5.0
  - lightgbm >= 3.3.0
  - catboost >= 1.0.0

### Hardware Requirements

- **RAM**: Minimum 4 GB (8 GB recommended)
- **Disk Space**: 100 MB for package + space for results
- **Processor**: Any modern CPU (no GPU required)

---

## Installation

### Step 1: Extract the Package

Extract the ZIP file to your desired location:

```bash
unzip Parkinson_Clinical_Decision_Support.zip
cd Parkinson_Clinical_Decision_Support
```

### Step 2: Install Python Dependencies

#### Option A: Using pip (Recommended)

```bash
pip install -r requirements.txt
```

#### Option B: Using conda

```bash
conda create -n parkinson_pred python=3.9
conda activate parkinson_pred
pip install -r requirements.txt
```

### Step 3: Verify Installation

```bash
python scripts/predict_patient.py --help
```

If you see the help message, installation was successful! ✅

---

## Quick Start

### Example 1: Interactive Mode (Single Patient)

The easiest way to get started:

```bash
cd scripts
python predict_patient.py --interactive
```

Follow the prompts to enter patient data:

```
Patient ID: PATIENT_001
Baseline UPDRS Part III score: 15.0
Age in years: 65.0
Gender (0=Female, 1=Male): 1
```

You'll receive an immediate prediction with clinical interpretation!

### Example 2: Batch Mode (Multiple Patients)

For multiple patients, prepare a CSV file and run:

```bash
python predict_patient.py --input ../examples/example_patients.csv --output my_predictions.csv
```

Results will be saved to `results/my_predictions.csv`

---

## Usage Modes

### 1. Interactive Mode

**Best for:** Single patient predictions, learning the system

**Command:**
```bash
python predict_patient.py --interactive
```

**Features:**
- Step-by-step data entry
- Immediate results display
- Optional result saving
- User-friendly prompts

**Example Session:**
```
INTERACTIVE PATIENT PREDICTION MODE
====================================================================

Please enter patient baseline data:
(Press Enter to skip optional fields)

Patient ID (optional): PATIENT_123
Baseline UPDRS Part III score (required): 20
Age in years (required): 70
Gender (0=Female, 1=Male, required): 1

🔮 Making prediction...

PREDICTION RESULTS
====================================================================

Patient ID: PATIENT_123
Baseline UPDRS Part III: 20.0

Predicted UPDRS at 12 months: 26.5
   95% Confidence Interval: [20.5, 32.5]

Predicted Change: +6.5 points
Progression Risk: Moderate Progression

Clinical Interpretation:
   Moderate progression expected (6.5 points). Consider treatment adjustment.
====================================================================
```

### 2. Batch Mode

**Best for:** Multiple patients, routine clinical use

**Command:**
```bash
python predict_patient.py --input <input_file.csv> --output <output_file.csv>
```

**Parameters:**
- `--input` or `-in`: Path to CSV file with patient data (required)
- `--output` or `-out`: Output filename (default: predictions.csv)

**Example:**
```bash
# Basic usage
python predict_patient.py --input patients.csv

# Custom output location
python predict_patient.py --input patients.csv --output results_2025.csv

# Using example data
python predict_patient.py --input ../examples/example_patients.csv
```

**Output:**
- Predictions saved to `results/` directory
- Summary statistics displayed in terminal
- First 5 predictions shown for quick review

---

## Input Data Format

### Required Columns

Your CSV file **must** contain these columns:

| Column | Description | Type | Example |
|--------|-------------|------|---------|
| `PATNO` | Patient ID (optional but recommended) | String/Integer | "PATIENT_001" or 3001 |
| `UPDRS_BL` | Baseline UPDRS Part III score | Float | 15.0 |
| `AGE` | Patient age in years | Float | 65.0 |
| `GENDER` | Gender (0=Female, 1=Male) | Integer | 1 |

### Optional Columns

If you have RNA-seq data, you can include gene expression features. However, the model will work with just the baseline clinical data (missing features will be imputed with zeros).

### Example CSV File

```csv
PATNO,UPDRS_BL,AGE,GENDER
PATIENT_001,15.0,65.0,1.0
PATIENT_002,25.0,72.0,0.0
PATIENT_003,10.0,58.0,1.0
PATIENT_004,30.0,78.0,1.0
PATIENT_005,20.0,68.0,0.0
```

### Data Validation

The system will automatically:
- ✅ Check for required columns
- ✅ Impute missing features with zeros
- ✅ Handle NaN values
- ⚠️ Warn you about data quality issues

---

## Understanding the Results

### Output Columns

| Column | Description | Interpretation |
|--------|-------------|----------------|
| `Patient_ID` | Patient identifier | From input or auto-generated |
| `Baseline_UPDRS` | Baseline UPDRS Part III score | Starting motor severity |
| `Predicted_UPDRS_12M` | Predicted UPDRS at 12 months | Expected motor score |
| `Predicted_Change` | Change in UPDRS (Δ UPDRS) | **Key metric**: Positive = worsening |
| `Progression_Risk` | Risk category | See categories below |
| `Confidence_Level` | Model confidence | Based on validation R² |
| `Lower_Bound_12M` | Lower 95% CI | Predicted UPDRS - MAE |
| `Upper_Bound_12M` | Upper 95% CI | Predicted UPDRS + MAE |
| `Clinical_Interpretation` | Automated recommendation | Action suggestion |

### Progression Risk Categories

| Category | Predicted Change (Δ UPDRS) | Interpretation |
|----------|----------------------------|----------------|
| **Improvement** | < 0 points | Unexpected improvement (rare, verify data) |
| **Stable** | 0 to <3 points | Minimal progression expected |
| **Mild Progression** | 3 to <5 points | Slow progression, standard monitoring |
| **Moderate Progression** | 5 to <10 points | Notable progression, consider treatment adjustment |
| **Rapid Progression** | ≥ 10 points | Significant progression, urgent review recommended |

### Confidence Intervals

The 95% confidence interval is calculated as:

```
[Predicted UPDRS - MAE, Predicted UPDRS + MAE]
```

Where MAE = 6.01 points (from independent clinical validation)

**Example:**
- Predicted UPDRS at 12M: 26.5
- 95% CI: [20.5, 32.5]
- Interpretation: True UPDRS at 12 months is likely between 20.5 and 32.5

---

## Clinical Interpretation

### How to Use Predictions in Clinical Practice

#### 1. **Rapid Progression (Δ UPDRS ≥ 10)**

**Action:**
- 🔴 **Urgent clinical review recommended**
- Consider aggressive treatment adjustment
- Increase monitoring frequency
- Discuss prognosis with patient and family
- Evaluate for clinical trial enrollment

**Example:**
```
Patient: PATIENT_004
Baseline UPDRS: 30.0
Predicted 12M UPDRS: 42.5
Change: +12.5 points → Rapid Progression

Interpretation: Significant motor decline expected. 
Recommend urgent neurology consultation and treatment optimization.
```

#### 2. **Moderate Progression (Δ UPDRS 5-10)**

**Action:**
- 🟡 **Consider treatment adjustment**
- Review current medication regimen
- Assess for medication adherence
- Schedule follow-up in 3-6 months
- Discuss physical therapy options

#### 3. **Mild Progression (Δ UPDRS 3-5)**

**Action:**
- 🟢 **Standard monitoring**
- Continue current treatment
- Routine follow-up in 6-12 months
- Encourage exercise and lifestyle interventions

#### 4. **Stable (Δ UPDRS 0-3)**

**Action:**
- ✅ **Maintain current management**
- Annual follow-up sufficient
- Reinforce medication adherence
- Positive prognostic counseling

### Important Considerations

⚠️ **Clinical Context Matters:**
- Consider patient's overall health status
- Account for comorbidities
- Evaluate medication side effects
- Assess quality of life factors

⚠️ **Model Limitations:**
- Predictions are probabilistic, not deterministic
- Individual variability exists (MAE = 6.01 points)
- Based on PPMI cohort (may not generalize to all populations)
- Does not account for treatment changes during follow-up

---

## Troubleshooting

### Common Issues and Solutions

#### Issue 1: "Model file not found"

**Error:**
```
❌ Error: Model file not found at model/lightweight_optimized_model.pkl
```

**Solution:**
- Ensure you're running the script from the `scripts/` directory
- Check that `model/lightweight_optimized_model.pkl` exists
- Verify the package was extracted completely

#### Issue 2: "Missing required packages"

**Error:**
```
ModuleNotFoundError: No module named 'xgboost'
```

**Solution:**
```bash
pip install xgboost lightgbm catboost scikit-learn pandas numpy joblib
```

Or install all requirements:
```bash
pip install -r requirements.txt
```

#### Issue 3: "Missing critical baseline features"

**Error:**
```
❌ Data validation failed:
   - Missing critical baseline features: ['UPDRS_BL', 'AGE']
```

**Solution:**
- Ensure your CSV has columns: `UPDRS_BL`, `AGE`, `GENDER`
- Check column names (case-sensitive!)
- Verify data is not empty

#### Issue 4: "Invalid input"

**Error:**
```
❌ Invalid input: could not convert string to float: 'N/A'
```

**Solution:**
- Replace missing values with actual numbers
- Use 0 for missing gene expression data
- Ensure numeric columns contain only numbers

### Getting Help

If you encounter issues not covered here:

1. Check the [FAQ section](#frequently-asked-questions)
2. Review error messages carefully
3. Verify your input data format
4. Contact support (see [Contact section](#contact-and-support))

---

## Frequently Asked Questions

### General Questions

**Q: What does the model predict?**  
A: The model predicts the UPDRS Part III (motor examination) score at 12 months, given baseline clinical data.

**Q: How accurate is the model?**  
A: On an independent clinical test set (n=78), the model achieved R²=0.551 and MAE=6.01 UPDRS points. This means predictions are typically within ±6 points of the actual value.

**Q: Can I use this for treatment decisions?**  
A: This tool provides decision support but should NOT be the sole basis for treatment decisions. Always combine predictions with clinical judgment and patient preferences.

**Q: What data do I need?**  
A: Minimum required: Patient ID, baseline UPDRS Part III score, age, and gender. RNA-seq data improves predictions but is not required.

### Technical Questions

**Q: What machine learning model is used?**  
A: A Stacking Regressor combining XGBoost, LightGBM, and CatBoost with Huber Regressor as the meta-learner.

**Q: How was the model trained?**  
A: Trained on PPMI cohort (n=312) using 7-fold cross-validation, validated on independent clinical test set (n=78).

**Q: What features are most important?**  
A: SHAP analysis revealed:
1. Baseline UPDRS × PINK1 interaction (SHAP=0.283)
2. Baseline UPDRS score (SHAP=0.258)
3. VPS35 gene expression (SHAP=0.010)
4. Mitochondrial dysfunction pathway (SHAP=0.008)

**Q: Can I retrain the model with my own data?**  
A: The current package provides predictions only. For model retraining, please contact the research team.

### Clinical Questions

**Q: What is a clinically meaningful change in UPDRS?**  
A: A change of ≥5 points is generally considered clinically significant for motor progression.

**Q: How should I interpret negative predictions (improvement)?**  
A: Negative predictions are rare and may indicate data entry errors or exceptional cases. Verify input data and consider clinical context.

**Q: Can this predict non-motor symptoms?**  
A: No, the model specifically predicts UPDRS Part III (motor symptoms only).

**Q: Is this validated for all PD subtypes?**  
A: The model was trained on the PPMI cohort, which includes typical PD patients. Generalizability to atypical parkinsonian syndromes is unknown.

---

## Technical Details

### Model Architecture

**Type:** Stacking Regressor (Ensemble Learning)

**Base Models:**
1. **XGBoost** (Extreme Gradient Boosting)
   - max_depth: 4
   - learning_rate: 0.05
   - n_estimators: 200

2. **LightGBM** (Light Gradient Boosting Machine)
   - num_leaves: 31
   - learning_rate: 0.05
   - n_estimators: 200

3. **CatBoost** (Categorical Boosting)
   - depth: 6
   - learning_rate: 0.05
   - iterations: 200

**Meta-Learner:** Huber Regressor (robust to outliers)

### Feature Engineering

**Total Features:** 116

**Feature Categories:**
1. **Clinical Features (3):**
   - Baseline UPDRS Part III
   - Age
   - Gender

2. **Gene Expression (100):**
   - Top 100 genes correlated with ΔUPDRS

3. **PD Risk Genes (7):**
   - SNCA, LRRK2, GBA, PRKN, PINK1, PARK7, VPS35

4. **Pathway Scores (3):**
   - Mitochondrial dysfunction
   - Neuroinflammation
   - Autophagy

5. **Interaction Features (3):**
   - UPDRS_BL × PINK1
   - PINK1 × PARK7
   - AGE × PINK1

### Data Preprocessing

1. **Outlier Removal:** IQR method (2 patients removed)
2. **Feature Scaling:** StandardScaler (mean=0, std=1)
3. **Target Transformation:** Yeo-Johnson power transformation
4. **Missing Data:** Imputation with zeros (for gene expression)

### Model Validation

**Training Set:** n=312 (80%)
- 7-fold cross-validation
- Stratified by progression status (ΔUPDRS ≥ 5)
- Mean CV R² = 0.513 ± 0.052
- Mean CV MAE = 6.15 ± 0.25

**Independent Test Set:** n=78 (20%)
- Held out from training
- Never seen by model during development
- Test R² = 0.551
- Test MAE = 6.01

### Explainability (SHAP Analysis)

**Top 5 Features by SHAP Value:**

| Feature | SHAP Value | Interpretation |
|---------|------------|----------------|
| UPDRS_BL × PINK1 | 0.283 | Gene-clinical interaction most important |
| UPDRS_BL | 0.258 | Baseline severity strongly predictive |
| VPS35 | 0.010 | Top individual gene |
| Mitochondrial pathway | 0.008 | Pathway-level contribution |
| GBA | 0.005 | Classic PD risk gene |

### Performance Metrics

| Metric | 7-Fold CV | Independent Test |
|--------|-----------|------------------|
| R² | 0.513 ± 0.052 | 0.551 |
| MAE | 6.15 ± 0.25 | 6.01 |
| RMSE | 7.82 ± 0.31 | 7.45 |
| Pearson r | 0.72 ± 0.04 | 0.74 |

### Computational Requirements

- **Training Time:** ~15 minutes (on standard laptop)
- **Prediction Time:** <1 second per patient
- **Model Size:** 582 KB
- **Memory Usage:** <500 MB during prediction

---

## Contact and Support

### Research Team

**Principal Investigator:** [Your Name]  
**Institution:** [Your Institution]  
**Email:** [your.email@institution.edu]

### Citation

If you use this tool in your research or clinical practice, please cite:

```
[Your Name] et al. (2025). Integrating Blood-Based Transcriptomics and 
Explainable Machine Learning to Predict Parkinson's Disease Motor Progression: 
Insights from SHAP Analysis. [Journal Name], [Volume]([Issue]), [Pages].
```

### Data Source

This model was trained on data from the Parkinson's Progression Markers Initiative (PPMI):

> PPMI – a public-private partnership – is funded by the Michael J. Fox Foundation for Parkinson's Research and funding partners, including [list of partners]. For up-to-date information on the study, visit www.ppmi-info.org.

### License

This software is provided for research and clinical decision support purposes. 

**Terms of Use:**
- ✅ Free for academic and clinical use
- ✅ Modification and redistribution allowed with attribution
- ❌ Commercial use requires permission
- ❌ No warranty provided

### Version History

**Version 1.0 (November 2025)**
- Initial release
- Model trained on PPMI cohort (n=390)
- R²=0.551, MAE=6.01 on independent test set

---

## Appendix

### A. Example Workflow

**Scenario:** A neurologist wants to predict progression for 5 new PD patients

**Step 1:** Prepare patient data
```csv
PATNO,UPDRS_BL,AGE,GENDER
P001,12.0,63.0,1.0
P002,28.0,75.0,0.0
P003,18.0,68.0,1.0
P004,35.0,72.0,1.0
P005,15.0,59.0,0.0
```

**Step 2:** Run prediction
```bash
python predict_patient.py --input my_patients.csv --output my_results.csv
```

**Step 3:** Review results
```
PREDICTION SUMMARY
====================================================================
Total patients: 5

Progression Risk Distribution:
   Stable: 1 (20.0%)
   Mild Progression: 2 (40.0%)
   Moderate Progression: 1 (20.0%)
   Rapid Progression: 1 (20.0%)

Mean predicted change: 6.2 ± 4.1 points
Range: 1.5 to 13.8 points
====================================================================
```

**Step 4:** Clinical action
- P001: Stable → Routine follow-up
- P002: Rapid → Urgent review
- P003: Mild → Standard monitoring
- P004: Rapid → Treatment adjustment
- P005: Mild → Standard monitoring

### B. Troubleshooting Checklist

Before contacting support, please check:

- [ ] Python version ≥ 3.8
- [ ] All required packages installed
- [ ] Running from correct directory (`scripts/`)
- [ ] Model file exists in `model/` directory
- [ ] Input CSV has required columns
- [ ] Column names match exactly (case-sensitive)
- [ ] No special characters in patient IDs
- [ ] Numeric columns contain only numbers
- [ ] File paths are correct

### C. Quick Reference Commands

```bash
# Interactive mode
python predict_patient.py --interactive

# Batch mode with example data
python predict_patient.py --input ../examples/example_patients.csv

# Custom output location
python predict_patient.py --input patients.csv --output results_2025.csv

# Get help
python predict_patient.py --help

# Check Python version
python --version

# Install requirements
pip install -r requirements.txt
```

---

**End of User Guide**

For the latest updates and additional resources, visit: [Your Website]

Last updated: November 15, 2025
