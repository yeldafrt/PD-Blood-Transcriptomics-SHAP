# Technical Documentation
## Parkinson's Disease Motor Progression Predictor

**Version:** 1.0  
**Date:** November 2025

---

## Table of Contents

1. [Model Architecture](#model-architecture)
2. [Training Methodology](#training-methodology)
3. [Feature Engineering](#feature-engineering)
4. [Performance Metrics](#performance-metrics)
5. [SHAP Analysis](#shap-analysis)
6. [Implementation Details](#implementation-details)
7. [Validation Strategy](#validation-strategy)

---

## Model Architecture

### Ensemble Method: Stacking Regressor

The model uses a two-level stacking architecture combining three gradient boosting algorithms.

#### Level 0: Base Models

**1. XGBoost (Extreme Gradient Boosting)**
```python
XGBRegressor(
    max_depth=4,
    learning_rate=0.05,
    n_estimators=200,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42
)
```

**2. LightGBM (Light Gradient Boosting Machine)**
```python
LGBMRegressor(
    num_leaves=31,
    learning_rate=0.05,
    n_estimators=200,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42
)
```

**3. CatBoost (Categorical Boosting)**
```python
CatBoostRegressor(
    depth=6,
    learning_rate=0.05,
    iterations=200,
    random_state=42,
    verbose=False
)
```

#### Level 1: Meta-Learner

**Huber Regressor** (robust to outliers)
```python
HuberRegressor(
    epsilon=1.35,
    max_iter=100
)
```

### Why Stacking?

- **Diversity:** Each base model has different strengths
- **Robustness:** Reduces overfitting through ensemble averaging
- **Performance:** Consistently outperforms individual models
- **Stability:** Less sensitive to hyperparameter choices

---

## Training Methodology

### Dataset: PPMI Cohort

**Source:** Parkinson's Progression Markers Initiative  
**Total Patients:** 390 (after outlier removal)  
**Outcome:** UPDRS Part III score at 12 months

### Data Split

```
Total: 390 patients
├── Training + Validation: 312 (80%)
│   └── 7-fold cross-validation
└── Independent Test: 78 (20%)
    └── Never seen during training
```

### Stratification

Patients stratified by progression status:
- **Fast Progressors:** ΔUPDRS ≥ 5 points
- **Slow Progressors:** ΔUPDRS < 5 points

This ensures balanced representation in train/test splits.

### Hyperparameter Optimization

**Method:** Optuna (Bayesian optimization)  
**Trials:** 30 per model  
**Objective:** Minimize MAE on validation set  
**Search Space:**
- Learning rate: [0.01, 0.1]
- Max depth: [3, 7]
- N estimators: [100, 300]
- Subsample: [0.6, 1.0]

---

## Feature Engineering

### Total Features: 116

#### 1. Clinical Features (3)

| Feature | Description | Range |
|---------|-------------|-------|
| UPDRS_BL | Baseline UPDRS Part III | 0-108 |
| AGE | Age in years | 30-90 |
| GENDER | 0=Female, 1=Male | {0, 1} |

#### 2. Gene Expression (100)

**Selection Method:** Correlation with ΔUPDRS
- Top 100 genes with highest absolute correlation
- Pearson correlation coefficient
- Log2-transformed TPM values

#### 3. PD Risk Genes (7)

Established Parkinson's disease risk genes:
- **SNCA** (α-synuclein)
- **LRRK2** (Leucine-rich repeat kinase 2)
- **GBA** (Glucocerebrosidase)
- **PRKN** (Parkin)
- **PINK1** (PTEN-induced kinase 1)
- **PARK7** (DJ-1)
- **VPS35** (Vacuolar protein sorting 35)

#### 4. Pathway Scores (3)

Biological pathway activity scores:
- **Mitochondrial Dysfunction:** Mean expression of mitochondrial genes
- **Neuroinflammation:** Mean expression of inflammatory genes
- **Autophagy:** Mean expression of autophagy-related genes

#### 5. Interaction Features (3)

Gene-clinical interactions:
- **UPDRS_BL × PINK1:** Most important feature (SHAP=0.283)
- **PINK1 × PARK7:** Mitophagy pathway interaction
- **AGE × PINK1:** Age-dependent gene effect

### Preprocessing Pipeline

```python
1. Outlier Removal (IQR method)
   └── Removed 2 patients with extreme UPDRS values

2. Feature Scaling (StandardScaler)
   └── Mean = 0, Std = 1 for all features

3. Target Transformation (Yeo-Johnson)
   └── Normalize UPDRS_V04 distribution

4. Missing Data Imputation
   └── Gene expression: Fill with 0
   └── Clinical: No missing values
```

---

## Performance Metrics

### Cross-Validation Results (n=312)

**7-Fold Cross-Validation:**

| Metric | Mean ± Std | Min | Max |
|--------|------------|-----|-----|
| R² | 0.513 ± 0.052 | 0.441 | 0.587 |
| MAE | 6.15 ± 0.25 | 5.82 | 6.48 |
| RMSE | 7.82 ± 0.31 | 7.35 | 8.24 |
| Pearson r | 0.72 ± 0.04 | 0.66 | 0.77 |

### Independent Test Set (n=78)

**Final Model Performance:**

| Metric | Value | Interpretation |
|--------|-------|----------------|
| **R²** | **0.551** | Model explains 55.1% of variance |
| **MAE** | **6.01** | Average error ±6 UPDRS points |
| **RMSE** | 7.45 | Root mean squared error |
| **Pearson r** | 0.74 | Strong positive correlation |
| **Spearman ρ** | 0.72 | Robust rank correlation |

### Comparison with Baseline Models

| Model | CV R² | Test R² | Test MAE |
|-------|-------|---------|----------|
| Linear Regression | 0.412 | 0.438 | 7.23 |
| Random Forest | 0.468 | 0.492 | 6.85 |
| XGBoost (single) | 0.487 | 0.518 | 6.42 |
| LightGBM (single) | 0.491 | 0.523 | 6.35 |
| CatBoost (single) | 0.485 | 0.515 | 6.45 |
| **Stacking Ensemble** | **0.513** | **0.551** | **6.01** |

**Conclusion:** Stacking outperforms all individual models.

---

## SHAP Analysis

### Top 20 Features by SHAP Value

| Rank | Feature | SHAP Value | Category | Interpretation |
|------|---------|------------|----------|----------------|
| 1 | UPDRS_BL × PINK1 | 0.283 | Interaction | Baseline severity × mitophagy gene |
| 2 | UPDRS_BL | 0.258 | Clinical | Baseline motor severity |
| 3 | ENSG00000243053 | 0.025 | Gene | Top prognostic gene |
| 4 | ENSG00000176422 | 0.022 | Gene | Second top gene |
| 5 | ENSG00000255872 | 0.020 | Gene | Third top gene |
| 6 | ENSG00000132646 | 0.020 | Gene | Fourth top gene |
| 7 | ENSG00000135905 | 0.019 | Gene | Fifth top gene |
| 8 | ENSG00000151475 | 0.017 | Gene | Sixth top gene |
| 9 | ENSG00000146535 | 0.017 | Gene | Seventh top gene |
| 10 | ENSG00000165621 | 0.016 | Gene | Eighth top gene |
| 11 | VPS35 | 0.010 | PD Gene | Endosomal trafficking |
| 12 | Mitochondrial | 0.008 | Pathway | Mitochondrial dysfunction |
| 13 | GBA | 0.005 | PD Gene | Lysosomal function |
| 14 | LRRK2 | 0.005 | PD Gene | Kinase activity |
| 15 | Neuroinflammation | 0.005 | Pathway | Inflammatory response |
| 16 | PRKN | 0.004 | PD Gene | Mitophagy |
| 17 | PARK7 | 0.003 | PD Gene | Oxidative stress |
| 18 | PINK1 × PARK7 | 0.003 | Interaction | Mitophagy pathway |
| 19 | Autophagy | 0.003 | Pathway | Cellular clearance |
| 20 | PINK1 | 0.003 | PD Gene | Mitochondrial quality control |

### Key Insights

1. **Gene-Clinical Interactions Dominate**
   - UPDRS_BL × PINK1 is the most important feature
   - Baseline severity modulates genetic effects

2. **Baseline UPDRS is Highly Predictive**
   - Second most important feature
   - Confirms clinical intuition

3. **VPS35 is Top Individual Gene**
   - SHAP = 0.010
   - Endosomal trafficking and lysosomal function

4. **Mitochondrial Dysfunction is Key Pathway**
   - SHAP = 0.008
   - Supports mitochondrial hypothesis of PD

5. **SNCA has Low Individual Importance**
   - SHAP = 0.002
   - Effect may be through interactions or blood-brain barrier

### SHAP Dependence Plots

**UPDRS_BL × PINK1 Interaction:**
- High UPDRS_BL + High PINK1 → Faster progression
- Low UPDRS_BL + Low PINK1 → Slower progression
- Interaction effect is non-linear

**VPS35 Expression:**
- Higher VPS35 → Slower progression
- Effect is dose-dependent
- Consistent across age groups

---

## Implementation Details

### Software Stack

**Language:** Python 3.9  
**Core Libraries:**
- pandas 1.5.3
- numpy 1.24.2
- scikit-learn 1.2.2
- xgboost 1.7.5
- lightgbm 3.3.5
- catboost 1.2
- joblib 1.2.0

### Model Serialization

**Format:** Pickle (joblib)  
**File Size:** 582 KB  
**Contents:**
```python
{
    'ensemble_model': StackingRegressor,
    'scaler': StandardScaler,
    'target_transformer': PowerTransformer,
    'feature_names': List[str],
    'n_features': int,
    'cv_results': dict,
    'clinical_results': dict,
    'shap_values': np.ndarray,
    'metadata': dict
}
```

### Prediction Pipeline

```python
1. Load patient data (CSV)
2. Validate required features
3. Impute missing features (zeros)
4. Scale features (StandardScaler)
5. Predict in transformed space
6. Inverse transform to UPDRS scale
7. Calculate confidence intervals
8. Categorize progression risk
9. Generate clinical interpretation
10. Save results (CSV)
```

### Computational Performance

**Training Time:** ~15 minutes (MacBook Pro M1)  
**Prediction Time:** <1 second per patient  
**Memory Usage:** <500 MB  
**Model Size:** 582 KB

---

## Validation Strategy

### Internal Validation

**Method:** 7-Fold Cross-Validation  
**Stratification:** By progression status (ΔUPDRS ≥ 5)  
**Repetitions:** 1 (with fixed random seed)

**Results:**
- Mean R² = 0.513 ± 0.052
- No significant overfitting
- Consistent across folds

### External Validation

**Method:** Independent holdout test set  
**Size:** n=78 (20% of total)  
**Selection:** Stratified random sampling  
**Timing:** Never used during model development

**Results:**
- Test R² = 0.551 (better than CV!)
- Test MAE = 6.01
- No overfitting detected

### Calibration Analysis

**Method:** Predicted vs. Actual plot  
**Result:** Well-calibrated across UPDRS range  
**Residual Analysis:** 
- Mean residual = -0.43 (slight underestimation)
- No systematic bias
- Homoscedastic errors

---

## Limitations

### Model Limitations

1. **Generalizability:**
   - Trained on PPMI cohort (research-grade data)
   - May not generalize to all clinical settings
   - Limited to early-stage PD patients

2. **Missing Features:**
   - Does not account for treatment changes
   - No imaging data (MRI, DaTscan)
   - Limited non-motor symptom data

3. **Temporal Scope:**
   - Predicts 12-month outcome only
   - Longer-term predictions untested
   - Assumes linear progression

4. **Uncertainty:**
   - MAE = 6.01 points (substantial)
   - Individual predictions may vary
   - Confidence intervals are approximate

### Data Limitations

1. **Sample Size:** n=390 (moderate)
2. **Cohort Bias:** PPMI participants (research volunteers)
3. **Missing Data:** Some gene expression values imputed
4. **Outliers:** 2 patients removed (may affect extremes)

### Clinical Limitations

1. **Not Diagnostic:** Does not diagnose PD
2. **Not Prescriptive:** Does not recommend specific treatments
3. **Requires Validation:** Should be validated in local cohorts
4. **Complementary Tool:** Should supplement, not replace, clinical judgment

---

## Future Directions

### Model Improvements

- [ ] Incorporate imaging data (MRI, DaTscan)
- [ ] Add non-motor symptom features
- [ ] Extend to longer prediction horizons (24, 36 months)
- [ ] Develop subtype-specific models
- [ ] Implement online learning for continuous improvement

### Validation Studies

- [ ] External validation in independent cohorts
- [ ] Prospective validation in clinical settings
- [ ] Subgroup analyses (age, gender, disease duration)
- [ ] Comparison with clinician predictions

### Clinical Integration

- [ ] Electronic health record (EHR) integration
- [ ] Real-time prediction API
- [ ] Mobile app for point-of-care use
- [ ] Dashboard for clinical trial recruitment

---

## References

### Key Publications

1. **PPMI Consortium.** The Parkinson Progression Marker Initiative (PPMI). *Prog Neurobiol.* 2011;95(4):629-635.

2. **Lundberg & Lee.** A unified approach to interpreting model predictions. *NeurIPS.* 2017.

3. **Nuytemans et al.** Genetic etiology of Parkinson disease associated with mutations in the SNCA, PARK2, PINK1, PARK7, and LRRK2 genes. *Hum Mutat.* 2010;31(7):763-780.

4. **Pickrell & Youle.** The roles of PINK1, parkin, and mitochondrial fidelity in Parkinson's disease. *Neuron.* 2015;85(2):257-273.

### Machine Learning Methods

5. **Chen & Guestrin.** XGBoost: A scalable tree boosting system. *KDD.* 2016.

6. **Ke et al.** LightGBM: A highly efficient gradient boosting decision tree. *NeurIPS.* 2017.

7. **Prokhorenkova et al.** CatBoost: unbiased boosting with categorical features. *NeurIPS.* 2018.

---

**Document Version:** 1.0  
**Last Updated:** November 15, 2025  
**Maintained By:** Clinical ML Research Team
