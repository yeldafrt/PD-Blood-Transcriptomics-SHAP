#!/usr/bin/env python3
"""
PARKINSON'S DISEASE MOTOR PROGRESSION PREDICTOR
================================================
Clinical Decision Support System

This tool predicts 12-month motor progression (UPDRS Part III) for Parkinson's 
disease patients using baseline clinical and blood RNA-seq data.

Model Performance:
- R² = 0.551 (Independent Clinical Test Set)
- MAE = 6.01 UPDRS points
- Based on PPMI cohort (n=390)

Usage:
    python predict_patient.py --input patient_data.csv --output predictions.csv
    
Or interactive mode:
    python predict_patient.py --interactive

Author: Clinical ML Research Team
Date: November 2025
"""

import pandas as pd
import numpy as np
import joblib
import argparse
import sys
import os
from pathlib import Path

# Get package root directory
PACKAGE_ROOT = Path(__file__).parent.parent
MODEL_PATH = PACKAGE_ROOT / "model" / "lightweight_optimized_model.pkl"
RESULTS_DIR = PACKAGE_ROOT / "results"

def load_model():
    """
    Load the trained Stacking Regressor model.
    
    Returns:
        dict: Model components including ensemble, scaler, transformer, and metadata
    """
    try:
        model_data = joblib.load(MODEL_PATH)
        print("✅ Model loaded successfully")
        print(f"   Model type: Stacking Regressor (XGBoost + LightGBM + CatBoost)")
        print(f"   Features: {model_data['n_features']}")
        print(f"   Clinical Test R²: {model_data['clinical_results']['r2']:.3f}")
        print(f"   Clinical Test MAE: {model_data['clinical_results']['mae']:.2f}")
        return model_data
    except FileNotFoundError:
        print(f"❌ Error: Model file not found at {MODEL_PATH}")
        print("   Please ensure the model file is in the 'model/' directory")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error loading model: {e}")
        sys.exit(1)

def validate_input_data(patient_df, feature_names):
    """
    Validate and prepare patient data.
    
    Args:
        patient_df: DataFrame with patient data
        feature_names: List of required feature names
        
    Returns:
        tuple: (prepared_data, warnings)
    """
    warnings = []
    
    # Check for required baseline features
    required_baseline = ['UPDRS_BL', 'AGE', 'GENDER']
    missing_baseline = [f for f in required_baseline if f not in patient_df.columns]
    
    if missing_baseline:
        warnings.append(f"Missing critical baseline features: {missing_baseline}")
        return None, warnings
    
    # Check for missing features
    missing_features = set(feature_names) - set(patient_df.columns)
    if missing_features:
        warnings.append(f"Missing {len(missing_features)} features (will be imputed with zeros)")
        
        # Add missing features with 0
        for feat in missing_features:
            patient_df[feat] = 0.0
    
    # Select and order features
    X = patient_df[feature_names].values
    
    # Handle NaN values
    if np.isnan(X).any():
        warnings.append("Some features contain NaN values (will be imputed with zeros)")
        X = np.nan_to_num(X, nan=0.0)
    
    return X, warnings

def predict_progression(patient_data):
    """
    Predict 12-month UPDRS Part III progression for patients.
    
    Args:
        patient_data: DataFrame with patient baseline data
        
    Returns:
        DataFrame: Predictions with confidence intervals and risk categories
    """
    # Load model
    model_data = load_model()
    
    ensemble_model = model_data['ensemble_model']
    scaler = model_data['scaler']
    target_transformer = model_data['target_transformer']
    feature_names = model_data['feature_names']
    
    # Validate and prepare data
    X, warnings = validate_input_data(patient_data.copy(), feature_names)
    
    if X is None:
        print("\n❌ Data validation failed:")
        for w in warnings:
            print(f"   - {w}")
        sys.exit(1)
    
    if warnings:
        print("\n⚠️  Warnings:")
        for w in warnings:
            print(f"   - {w}")
    
    # Scale features
    X_scaled = scaler.transform(X)
    
    # Predict in transformed space
    y_pred_trans = ensemble_model.predict(X_scaled)
    
    # Inverse transform to original UPDRS scale
    y_pred_updrs = target_transformer.inverse_transform(
        y_pred_trans.reshape(-1, 1)
    ).flatten()
    
    # Get baseline UPDRS
    baseline_updrs = patient_data['UPDRS_BL'].values
    
    # Calculate predicted change
    predicted_delta = y_pred_updrs - baseline_updrs
    
    # Create results DataFrame
    results = pd.DataFrame({
        'Patient_ID': patient_data.get('PATNO', range(1, len(patient_data) + 1)),
        'Baseline_UPDRS': baseline_updrs,
        'Predicted_UPDRS_12M': np.round(y_pred_updrs, 1),
        'Predicted_Change': np.round(predicted_delta, 1),
        'Progression_Risk': categorize_progression(predicted_delta),
        'Confidence_Level': 'High'  # Based on R²=0.551
    })
    
    # Add uncertainty estimates (±MAE)
    mae = model_data['clinical_results']['mae']
    results['Lower_Bound_12M'] = np.round(y_pred_updrs - mae, 1)
    results['Upper_Bound_12M'] = np.round(y_pred_updrs + mae, 1)
    
    # Add clinical interpretation
    results['Clinical_Interpretation'] = results.apply(interpret_prediction, axis=1)
    
    return results

def categorize_progression(delta_updrs):
    """
    Categorize progression risk based on predicted UPDRS change.
    
    Args:
        delta_updrs: Predicted change in UPDRS score
        
    Returns:
        list: Risk categories
    """
    categories = []
    for delta in delta_updrs:
        if delta < 0:
            categories.append('Improvement')
        elif delta < 3:
            categories.append('Stable')
        elif delta < 5:
            categories.append('Mild Progression')
        elif delta < 10:
            categories.append('Moderate Progression')
        else:
            categories.append('Rapid Progression')
    return categories

def interpret_prediction(row):
    """
    Generate clinical interpretation for each prediction.
    
    Args:
        row: DataFrame row with prediction results
        
    Returns:
        str: Clinical interpretation
    """
    risk = row['Progression_Risk']
    change = row['Predicted_Change']
    
    interpretations = {
        'Improvement': f"Patient shows predicted improvement ({change:.1f} points). Monitor for accuracy.",
        'Stable': f"Patient likely to remain stable over 12 months ({change:.1f} points change).",
        'Mild Progression': f"Mild progression expected ({change:.1f} points). Standard monitoring recommended.",
        'Moderate Progression': f"Moderate progression expected ({change:.1f} points). Consider treatment adjustment.",
        'Rapid Progression': f"Rapid progression predicted ({change:.1f} points). Urgent clinical review recommended."
    }
    
    return interpretations.get(risk, "Unknown risk category")

def interactive_mode():
    """
    Interactive mode for single patient prediction.
    """
    print("\n" + "="*70)
    print("INTERACTIVE PATIENT PREDICTION MODE")
    print("="*70)
    print("\nPlease enter patient baseline data:")
    print("(Press Enter to skip optional fields)\n")
    
    try:
        # Collect baseline clinical data
        patno = input("Patient ID (optional): ").strip() or "PATIENT_001"
        updrs_bl = float(input("Baseline UPDRS Part III score (required): "))
        age = float(input("Age in years (required): "))
        gender = float(input("Gender (0=Female, 1=Male, required): "))
        
        # Create patient DataFrame
        patient_data = pd.DataFrame({
            'PATNO': [patno],
            'UPDRS_BL': [updrs_bl],
            'AGE': [age],
            'GENDER': [gender]
        })
        
        print("\n🔮 Making prediction...")
        results = predict_progression(patient_data)
        
        # Display results
        print("\n" + "="*70)
        print("PREDICTION RESULTS")
        print("="*70)
        print(f"\nPatient ID: {results['Patient_ID'].iloc[0]}")
        print(f"Baseline UPDRS Part III: {results['Baseline_UPDRS'].iloc[0]:.1f}")
        print(f"\nPredicted UPDRS at 12 months: {results['Predicted_UPDRS_12M'].iloc[0]:.1f}")
        print(f"   95% Confidence Interval: [{results['Lower_Bound_12M'].iloc[0]:.1f}, {results['Upper_Bound_12M'].iloc[0]:.1f}]")
        print(f"\nPredicted Change: {results['Predicted_Change'].iloc[0]:+.1f} points")
        print(f"Progression Risk: {results['Progression_Risk'].iloc[0]}")
        print(f"\nClinical Interpretation:")
        print(f"   {results['Clinical_Interpretation'].iloc[0]}")
        print("="*70)
        
        # Save option
        save = input("\nSave results to file? (y/n): ").strip().lower()
        if save == 'y':
            output_file = RESULTS_DIR / f"prediction_{patno}.csv"
            results.to_csv(output_file, index=False)
            print(f"✅ Results saved to: {output_file}")
        
    except ValueError as e:
        print(f"\n❌ Invalid input: {e}")
        print("   Please enter numeric values for UPDRS, age, and gender")
    except KeyboardInterrupt:
        print("\n\nOperation cancelled by user")
    except Exception as e:
        print(f"\n❌ Error: {e}")

def batch_mode(input_file, output_file):
    """
    Batch prediction mode for multiple patients.
    
    Args:
        input_file: Path to CSV file with patient data
        output_file: Path to save predictions
    """
    try:
        # Load patient data
        patient_df = pd.read_csv(input_file)
        print(f"✅ Loaded {len(patient_df)} patients from {input_file}")
        
        # Make predictions
        print("\n🔮 Making predictions...")
        results = predict_progression(patient_df)
        
        # Save results
        RESULTS_DIR.mkdir(exist_ok=True)
        output_path = RESULTS_DIR / output_file if not os.path.isabs(output_file) else Path(output_file)
        results.to_csv(output_path, index=False)
        print(f"\n✅ Predictions saved to: {output_path}")
        
        # Display summary
        print("\n" + "="*70)
        print("PREDICTION SUMMARY")
        print("="*70)
        print(f"Total patients: {len(results)}")
        print(f"\nProgression Risk Distribution:")
        for risk, count in results['Progression_Risk'].value_counts().items():
            print(f"   {risk}: {count} ({count/len(results)*100:.1f}%)")
        
        print(f"\nMean predicted change: {results['Predicted_Change'].mean():.2f} ± {results['Predicted_Change'].std():.2f} points")
        print(f"Range: {results['Predicted_Change'].min():.2f} to {results['Predicted_Change'].max():.2f} points")
        print("="*70)
        
        # Display first few predictions
        print("\nFirst 5 predictions:")
        display_cols = ['Patient_ID', 'Baseline_UPDRS', 'Predicted_UPDRS_12M', 
                       'Predicted_Change', 'Progression_Risk']
        print(results[display_cols].head().to_string(index=False))
        
    except FileNotFoundError:
        print(f"❌ Error: Input file not found: {input_file}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)

def main():
    """
    Main entry point for the clinical prediction tool.
    """
    parser = argparse.ArgumentParser(
        description='Parkinson\'s Disease Motor Progression Predictor',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Interactive mode:
    python predict_patient.py --interactive
    
  Batch prediction:
    python predict_patient.py --input patients.csv --output predictions.csv
    
  Using example data:
    python predict_patient.py --input ../examples/example_patients.csv

For more information, see the User Guide in docs/USER_GUIDE.md
        """
    )
    
    parser.add_argument('--interactive', '-i', action='store_true',
                        help='Run in interactive mode for single patient')
    parser.add_argument('--input', '-in', type=str,
                        help='Path to CSV file with patient data')
    parser.add_argument('--output', '-out', type=str, default='predictions.csv',
                        help='Output file name for predictions (default: predictions.csv)')
    
    args = parser.parse_args()
    
    # Ensure results directory exists
    RESULTS_DIR.mkdir(exist_ok=True)
    
    # Run appropriate mode
    if args.interactive:
        interactive_mode()
    elif args.input:
        batch_mode(args.input, args.output)
    else:
        parser.print_help()
        print("\n❌ Error: Please specify either --interactive or --input")
        sys.exit(1)

if __name__ == '__main__':
    main()
