# 🚀 Quick Start - Optimized Model

## Performance at a Glance

- **Clinical R² = 0.551** ⭐
- **MAE = ±6 UPDRS points**
- **20% better than baseline**
- **No overfitting**

---

## 3-Step Setup

### 1. Extract Package
```bash
tar -xzf Parkinson_Optimized_Model_Package.tar.gz
cd parkinson_optimized_model_package
```

### 2. Install Dependencies
```bash
pip install pandas numpy scikit-learn xgboost lightgbm catboost joblib
```

### 3. Test with Example Data
```bash
cd codes
python3 predict_new_patient.py \
    --patient_data ../data/example_data.csv \
    --model_path ../model/lightweight_optimized_model.pkl \
    --output test_predictions.csv
```

---

## Expected Output

```
✅ Model loaded successfully
   Features: 116
   CV R²: 0.513
   Clinical R²: 0.551
✅ Loaded 390 patients from ../data/example_data.csv

🔮 Making predictions...

✅ Predictions saved to test_predictions.csv

============================================================
PREDICTION SUMMARY
============================================================
Total patients: 390
Fast progressors (ΔUPDRS ≥ 5): 156
Slow progressors (ΔUPDRS < 5): 234

Mean predicted ΔUPDRS: 4.23 ± 3.15
Range: -2.45 to 12.67
============================================================
```

---

## View Predictions

```bash
head test_predictions.csv
```

Columns:
- `Patient_ID`
- `Predicted_UPDRS_V04` (12-month score)
- `Predicted_DELTA_UPDRS` (change)
- `Progression_Category` (Fast/Slow)
- `Lower_Bound` / `Upper_Bound` (confidence)

---

## For Your Own Data

### Required Features (116 total):

1. **Clinical (3):** UPDRS_BL, AGE, GENDER
2. **Top 100 Genes:** ENSG... (see example_data.csv)
3. **PD Genes (7):** PD_PINK1, PD_PARK7, etc.
4. **Pathways (3):** PATHWAY_Mitochondrial, etc.
5. **Interactions (3):** PINK1_x_PARK7, etc.

### Run Prediction:

```bash
python3 predict_new_patient.py \
    --patient_data YOUR_DATA.csv \
    --output YOUR_predictions.csv
```

---

## Model Details

- **Training:** 30 Optuna trials, 7-fold CV
- **Features:** 116 (100 genes + 16 others)
- **Ensemble:** XGBoost + LightGBM + CatBoost
- **Dataset:** PPMI (n=390)

---

## Need More Info?

See `documentation/README.md` for full details.
