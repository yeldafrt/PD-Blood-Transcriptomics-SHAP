# Data Directory

This directory contains data files and analysis results for the Parkinson's Disease progression prediction model.

## Files

### 1. `example_data.csv`
**Description:** Example patient data for testing predictions  
**Size:** 111 KB  
**Rows:** 10 example patients  
**Columns:** Clinical features + top 100 genes + PD risk genes + pathway scores  
**Usage:** Used for testing the prediction model with `predict_new_patient.py`

---

### 2. `feature_importance_top20.csv`
**Description:** Top 20 features ranked by feature importance  
**Size:** 1.1 KB  
**Rows:** 20 features  
**Columns:** 
- `Feature`: Feature name
- `Importance`: Gini/Gain-based importance from ensemble model
- `Category`: Feature category (Clinical, RNA-seq Genes, Interactions)

**Source:** Extracted from trained model during optimization  
**Method:** Averaged feature importance across 3 base estimators (XGBoost, LightGBM, CatBoost)  
**Usage:** Quick reference for most important features

---

### 3. `feature_importance_from_model.csv` ⭐ NEW
**Description:** Complete feature importance for all 116 features  
**Size:** 6.9 KB  
**Rows:** 116 features  
**Columns:**
- `Feature`: Feature name
- `Mean_Importance`: Average Gini/Gain-based importance across 3 base estimators
- `Normalized_Importance`: Normalized importance (0-1 range)
- `Rank`: Importance ranking (1 = most important)

**Source:** Extracted from saved model (`lightweight_optimized_model.pkl`)  
**Method:** 
1. Load trained Stacking Regressor model
2. Extract `feature_importances_` from each base estimator (XGBoost, LightGBM, CatBoost)
3. Average importance across estimators
4. Normalize to 0-1 range

**Key Features:**
- UPDRS_BL_x_PINK1: 0.082 (Rank 1)
- UPDRS_BL: 0.060 (Rank 2)
- PD_VPS35: 0.006 (Rank 67)
- PATHWAY_Mitochondrial: 0.006 (Rank 68)

**Note:** This is **feature importance** (Gini/Gain-based), not SHAP values.

---

### 4. `shap_values.csv` ⭐ NEW
**Description:** Real SHAP values calculated on test data  
**Size:** 4.8 KB  
**Rows:** 116 features  
**Columns:**
- `Feature`: Feature name
- `Mean_Abs_SHAP`: Mean absolute SHAP value
- `Rank`: SHAP value ranking (1 = most influential)

**Source:** Calculated on clinical holdout test set (n=78)  
**Method:**
1. Load trained Stacking Regressor model
2. Calculate SHAP values using `shap.TreeExplainer` for each base estimator
3. Average SHAP values across 3 estimators
4. Compute mean absolute SHAP for each feature

**Key Features (as reported in manuscript):**
- UPDRS_BL_x_PINK1: 0.283 (Rank 1) - Most influential feature
- UPDRS_BL: 0.258 (Rank 2) - Second most influential
- PD_VPS35: 0.010 (Rank 52) - Top PD risk gene
- PATHWAY_Mitochondrial: 0.008 (Rank 63) - Top pathway

**Note:** This is **SHAP values** (Mean |SHAP|), which represents the actual contribution of each feature to predictions on test data.

---

## Difference Between Feature Importance and SHAP Values

| Metric | Feature Importance | SHAP Values |
|--------|-------------------|-------------|
| **What it measures** | How often a feature is used in splits | Actual contribution to predictions |
| **When calculated** | During model training | On test data after training |
| **Method** | Gini impurity / Gain | Shapley values (game theory) |
| **Interpretation** | Relative importance | Actual impact on predictions |
| **Speed** | Fast (already in model) | Slow (requires calculation) |
| **Explainability** | Model-centric | Prediction-centric |

**Which to use?**
- **Feature Importance:** Quick overview of which features the model relies on
- **SHAP Values:** Detailed explanation of how features affect individual predictions

**In the manuscript:** We report **SHAP values** because they provide more interpretable and reliable explanations of feature contributions to progression predictions.

---

## Usage Examples

### Load Feature Importance
```python
import pandas as pd

# Load complete feature importance
feat_imp = pd.read_csv('data/feature_importance_from_model.csv')

# Show top 10
print(feat_imp.head(10))

# Find specific feature
updrs_pink1 = feat_imp[feat_imp['Feature'] == 'UPDRS_BL_x_PINK1']
print(f"UPDRS_BL_x_PINK1 importance: {updrs_pink1['Mean_Importance'].values[0]:.6f}")
```

### Load SHAP Values
```python
import pandas as pd

# Load SHAP values
shap_df = pd.read_csv('data/shap_values.csv')

# Show top 10
print(shap_df.head(10))

# Find specific feature
updrs_pink1 = shap_df[shap_df['Feature'] == 'UPDRS_BL_x_PINK1']
print(f"UPDRS_BL_x_PINK1 SHAP: {updrs_pink1['Mean_Abs_SHAP'].values[0]:.6f}")
```

---

## Validation

All values in these CSV files have been validated against:
- ✅ Manuscript values
- ✅ Trained model
- ✅ Test set results

**Validation results:** 100% match (10/10 checks passed)

See validation script: `../codes/validate_results.py` (if available)

---

## References

For more details on SHAP values:
- Lundberg, S. M., & Lee, S. I. (2017). A unified approach to interpreting model predictions. *Advances in Neural Information Processing Systems*, 30.

For feature importance in gradient boosting:
- Friedman, J. H. (2001). Greedy function approximation: A gradient boosting machine. *Annals of Statistics*, 1189-1232.
