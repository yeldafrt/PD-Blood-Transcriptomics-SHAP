#!/usr/bin/env python3
"""
Generate 7-Fold CV Predictions Using Saved Model
This script recreates the exact CV predictions from the saved model
by replicating the training process for each fold.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, KFold
from sklearn.preprocessing import StandardScaler, PowerTransformer
from sklearn.linear_model import HuberRegressor
from sklearn.ensemble import StackingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
import joblib
import warnings
warnings.filterwarnings('ignore')

print("=" * 80)
print("GENERATING 7-FOLD CV PREDICTIONS")
print("=" * 80)

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# ============================================================================
# STEP 1: LOAD DATA
# ============================================================================
print("\n[1/5] Loading data...")

final_df = pd.read_csv('/home/ubuntu/upload/.recovery/final_dataset.csv')
rnaseq = pd.read_csv('/home/ubuntu/upload/.recovery/rnaseq_baseline_filtered.csv')

final_df['PATNO'] = final_df['PATNO'].astype(str)
rnaseq['PATNO'] = rnaseq['PATNO'].astype(str)

gene_cols = [col for col in rnaseq.columns if col.startswith('ENSG')]
rnaseq_genes = rnaseq[['PATNO'] + gene_cols]

merged = pd.merge(final_df, rnaseq_genes, on='PATNO', how='inner')

# Outlier removal
merged['UPDRS_V04'].fillna(merged['UPDRS_V04'].median(), inplace=True)
Q1 = merged['UPDRS_V04'].quantile(0.25)
Q3 = merged['UPDRS_V04'].quantile(0.75)
IQR = Q3 - Q1
outliers = (merged['UPDRS_V04'] < Q1 - 1.5*IQR) | (merged['UPDRS_V04'] > Q3 + 1.5*IQR)
merged_clean = merged[~outliers].copy()

print(f"  {len(merged_clean)} patients loaded")

# ============================================================================
# STEP 2: SELECT TOP 100 GENES
# ============================================================================
print("\n[2/5] Selecting top 100 genes...")

gene_correlations = []
for gene in gene_cols:
    if gene in merged_clean.columns:
        corr = merged_clean[[gene, 'DELTA_UPDRS']].corr().iloc[0, 1]
        if not np.isnan(corr):
            gene_correlations.append((gene, abs(corr), corr))

gene_correlations.sort(key=lambda x: x[1], reverse=True)
top_100_genes = [g[0] for g in gene_correlations[:100]]

# ============================================================================
# STEP 3: FEATURE ENGINEERING
# ============================================================================
print("\n[3/5] Feature engineering...")

clinical_features = ['UPDRS_BL', 'AGE', 'GENDER']
pd_genes = ['PD_SNCA', 'PD_LRRK2', 'PD_GBA', 'PD_PRKN', 'PD_PINK1', 'PD_PARK7', 'PD_VPS35']
pathway_features = ['PATHWAY_Inflammation', 'PATHWAY_Mitochondrial', 'PATHWAY_Autophagy']

# Interactions
merged_clean['PINK1_x_PARK7'] = merged_clean['PD_PINK1'] * merged_clean['PD_PARK7']
merged_clean['AGE_x_PINK1'] = merged_clean['AGE'] * merged_clean['PD_PINK1']
merged_clean['UPDRS_BL_x_PINK1'] = merged_clean['UPDRS_BL'] * merged_clean['PD_PINK1']
interaction_features = ['PINK1_x_PARK7', 'AGE_x_PINK1', 'UPDRS_BL_x_PINK1']

# Combine
all_features = clinical_features + top_100_genes + pd_genes + pathway_features + interaction_features
final_features = [f for f in all_features if f in merged_clean.columns]

# Fill missing
for col in final_features:
    if merged_clean[col].isnull().sum() > 0:
        merged_clean[col].fillna(merged_clean[col].median(), inplace=True)

X = merged_clean[final_features].values
y_v04 = merged_clean['UPDRS_V04'].values
y_clf = (merged_clean['DELTA_UPDRS'] >= 5).astype(int).values

print(f"  {len(final_features)} features ready")

# ============================================================================
# STEP 4: DATA SPLITTING & LOAD SAVED MODEL
# ============================================================================
print("\n[4/5] Loading saved model and parameters...")

# Split: 80% train+val, 20% clinical holdout (same as training)
X_trainval, X_clinical, y_trainval, y_clinical, y_clf_trainval, y_clf_clinical = train_test_split(
    X, y_v04, y_clf, test_size=0.2, random_state=RANDOM_SEED, stratify=y_clf
)

print(f"  Train+Val: n={X_trainval.shape[0]}, Clinical Holdout: n={X_clinical.shape[0]}")

# Load saved model
model_path = '/home/ubuntu/manuscript_update/parkinson_optimized_model_package/model/lightweight_optimized_model.pkl'
saved_data = joblib.load(model_path)

best_params = saved_data['best_params']
target_transformer = saved_data['target_transformer']

print(f"  ✓ Model and parameters loaded")

# ============================================================================
# STEP 5: GENERATE 7-FOLD CV PREDICTIONS
# ============================================================================
print("\n[5/5] Generating 7-fold CV predictions...")

cv = KFold(n_splits=7, shuffle=True, random_state=RANDOM_SEED)

cv_predictions = {
    'fold': [],
    'patient_index': [],
    'y_true': [],
    'y_pred': [],
    'r2': [],
    'mae': [],
    'rmse': []
}

for fold_idx, (train_idx, val_idx) in enumerate(cv.split(X_trainval), 1):
    print(f"  Processing Fold {fold_idx}/7...")
    
    X_train_fold = X_trainval[train_idx]
    y_train_fold = y_trainval[train_idx]
    X_val_fold = X_trainval[val_idx]
    y_val_fold = y_trainval[val_idx]
    
    # Transform target
    y_train_fold_trans = target_transformer.transform(y_train_fold.reshape(-1, 1)).flatten()
    
    # Scale features
    scaler_fold = StandardScaler()
    X_train_scaled = scaler_fold.fit_transform(X_train_fold)
    X_val_scaled = scaler_fold.transform(X_val_fold)
    
    # Build ensemble with best parameters
    xgb_model = XGBRegressor(
        objective='reg:pseudohubererror',
        n_estimators=best_params['xgb_n_estimators'],
        max_depth=best_params['xgb_max_depth'],
        learning_rate=best_params['xgb_learning_rate'],
        subsample=best_params['xgb_subsample'],
        colsample_bytree=best_params['xgb_colsample_bytree'],
        min_child_weight=best_params['xgb_min_child_weight'],
        reg_alpha=best_params['xgb_reg_alpha'],
        reg_lambda=best_params['xgb_reg_lambda'],
        random_state=RANDOM_SEED,
        n_jobs=-1,
        verbosity=0
    )
    
    lgbm_model = LGBMRegressor(
        objective='huber',
        n_estimators=best_params['lgbm_n_estimators'],
        max_depth=best_params['lgbm_max_depth'],
        learning_rate=best_params['lgbm_learning_rate'],
        subsample=best_params['lgbm_subsample'],
        colsample_bytree=best_params['lgbm_colsample_bytree'],
        min_data_in_leaf=best_params['lgbm_min_data_in_leaf'],
        reg_alpha=best_params['lgbm_reg_alpha'],
        reg_lambda=best_params['lgbm_reg_lambda'],
        random_state=RANDOM_SEED,
        n_jobs=-1,
        verbose=-1
    )
    
    catboost_model = CatBoostRegressor(
        loss_function='RMSE',
        iterations=best_params['cat_iterations'],
        depth=best_params['cat_depth'],
        learning_rate=best_params['cat_learning_rate'],
        subsample=best_params['cat_subsample'],
        reg_lambda=best_params['cat_reg_lambda'],
        random_state=RANDOM_SEED,
        thread_count=-1,
        verbose=False
    )
    
    meta_learner = HuberRegressor(
        epsilon=best_params['meta_epsilon'],
        alpha=best_params['meta_alpha'],
        max_iter=300
    )
    
    ensemble_model = StackingRegressor(
        estimators=[
            ('xgb', xgb_model),
            ('lgbm', lgbm_model),
            ('catboost', catboost_model)
        ],
        final_estimator=meta_learner,
        cv=5,
        n_jobs=-1
    )
    
    # Train
    ensemble_model.fit(X_train_scaled, y_train_fold_trans)
    
    # Predict
    y_val_pred_trans = ensemble_model.predict(X_val_scaled)
    y_val_pred = target_transformer.inverse_transform(y_val_pred_trans.reshape(-1, 1)).flatten()
    
    # Metrics
    fold_r2 = r2_score(y_val_fold, y_val_pred)
    fold_mae = mean_absolute_error(y_val_fold, y_val_pred)
    fold_rmse = np.sqrt(mean_squared_error(y_val_fold, y_val_pred))
    
    # Store predictions
    for i, idx in enumerate(val_idx):
        cv_predictions['fold'].append(fold_idx)
        cv_predictions['patient_index'].append(idx)
        cv_predictions['y_true'].append(y_val_fold[i])
        cv_predictions['y_pred'].append(y_val_pred[i])
        cv_predictions['r2'].append(fold_r2)
        cv_predictions['mae'].append(fold_mae)
        cv_predictions['rmse'].append(fold_rmse)
    
    print(f"    Fold {fold_idx}: R² = {fold_r2:.3f}, MAE = {fold_mae:.2f}, RMSE = {fold_rmse:.2f}")

# Convert to DataFrame
cv_predictions_df = pd.DataFrame(cv_predictions)

# Calculate overall metrics
overall_r2 = r2_score(cv_predictions_df['y_true'], cv_predictions_df['y_pred'])
overall_mae = mean_absolute_error(cv_predictions_df['y_true'], cv_predictions_df['y_pred'])
overall_rmse = np.sqrt(mean_squared_error(cv_predictions_df['y_true'], cv_predictions_df['y_pred']))

print(f"\n  Overall 7-Fold CV:")
print(f"    R² = {overall_r2:.3f}")
print(f"    MAE = {overall_mae:.2f}")
print(f"    RMSE = {overall_rmse:.2f}")
print(f"    n = {len(cv_predictions_df)}")

# ============================================================================
# SAVE PREDICTIONS
# ============================================================================
print("\n[SAVE] Saving CV predictions...")

# Save as CSV
csv_path = '/home/ubuntu/manuscript_update/cv_predictions_7fold.csv'
cv_predictions_df.to_csv(csv_path, index=False)
print(f"  ✓ Saved to: {csv_path}")

# Save as pickle (for faster loading)
pickle_path = '/home/ubuntu/manuscript_update/cv_predictions_7fold.pkl'
joblib.dump(cv_predictions_df, pickle_path)
print(f"  ✓ Saved to: {pickle_path}")

# Also save summary
summary = {
    'overall_r2': overall_r2,
    'overall_mae': overall_mae,
    'overall_rmse': overall_rmse,
    'n_samples': len(cv_predictions_df),
    'n_folds': 7
}

summary_path = '/home/ubuntu/manuscript_update/cv_predictions_summary.pkl'
joblib.dump(summary, summary_path)
print(f"  ✓ Summary saved to: {summary_path}")

print("\n" + "=" * 80)
print("CV PREDICTIONS GENERATED AND SAVED!")
print("=" * 80)
print(f"\nFiles created:")
print(f"  1. {csv_path}")
print(f"  2. {pickle_path}")
print(f"  3. {summary_path}")
print(f"\nYou can now use these predictions for plotting!")
print("=" * 80)
