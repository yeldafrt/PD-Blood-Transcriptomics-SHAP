#!/usr/bin/env python3
"""
LIGHTWEIGHT MODEL OPTIMIZATION FOR R² = 0.60 TARGET
Memory-efficient version

Strategy:
1. Top 100 genes (not 200)
2. 3 models (XGBoost, LightGBM, CatBoost)
3. 30 Optuna trials (not 100)
4. n_jobs=2 (not -1)
5. 7-fold CV validation

NO SIMULATION - REAL DATA ONLY
Run time: ~1 hour
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, KFold
from sklearn.preprocessing import StandardScaler, PowerTransformer
from sklearn.linear_model import HuberRegressor
from sklearn.ensemble import StackingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
import optuna
import joblib
import warnings
warnings.filterwarnings('ignore')

print("=" * 80)
print("LIGHTWEIGHT OPTIMIZATION FOR R² = 0.60 TARGET")
print("=" * 80)
print("\nMemory-efficient version:")
print("  - Top 100 genes (not 200)")
print("  - 3 models (not 5)")
print("  - 30 trials (not 100)")
print("  - n_jobs=2 (not -1)")
print("\nEstimated run time: ~1 hour")
print("=" * 80)

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# ============================================================================
# STEP 1: LOAD DATA
# ============================================================================
print("\n[STEP 1/5] Loading data...")

final_df = pd.read_csv('/home/ubuntu/parkinson_final/data/final_dataset.csv')
rnaseq = pd.read_csv('/home/ubuntu/parkinson_final/data/rnaseq_baseline_filtered.csv')

print(f"  final_dataset: {len(final_df)} patients")
print(f"  rnaseq: {len(rnaseq)} patients, {len([c for c in rnaseq.columns if c.startswith('ENSG')])} genes")

# Merge
final_df['PATNO'] = final_df['PATNO'].astype(str)
rnaseq['PATNO'] = rnaseq['PATNO'].astype(str)

gene_cols = [col for col in rnaseq.columns if col.startswith('ENSG')]
rnaseq_genes = rnaseq[['PATNO'] + gene_cols]

merged = pd.merge(final_df, rnaseq_genes, on='PATNO', how='inner')
print(f"  Merged: {len(merged)} patients")

# Outlier removal
merged['UPDRS_V04'].fillna(merged['UPDRS_V04'].median(), inplace=True)
Q1 = merged['UPDRS_V04'].quantile(0.25)
Q3 = merged['UPDRS_V04'].quantile(0.75)
IQR = Q3 - Q1
outliers = (merged['UPDRS_V04'] < Q1 - 1.5*IQR) | (merged['UPDRS_V04'] > Q3 + 1.5*IQR)
merged_clean = merged[~outliers].copy()
print(f"  {outliers.sum()} outliers removed, {len(merged_clean)} patients remaining")

# ============================================================================
# STEP 2: SELECT TOP 100 GENES
# ============================================================================
print("\n[STEP 2/5] Selecting top 100 genes by correlation...")

# Calculate correlations
gene_correlations = []
for gene in gene_cols:
    if gene in merged_clean.columns:
        corr = merged_clean[[gene, 'DELTA_UPDRS']].corr().iloc[0, 1]
        if not np.isnan(corr):
            gene_correlations.append((gene, abs(corr), corr))

gene_correlations.sort(key=lambda x: x[1], reverse=True)
top_100_genes = [g[0] for g in gene_correlations[:100]]

print(f"  Selected top 100 genes")
print(f"  Correlation range: {gene_correlations[0][1]:.4f} to {gene_correlations[99][1]:.4f}")

# ============================================================================
# STEP 3: FEATURE ENGINEERING (MINIMAL)
# ============================================================================
print("\n[STEP 3/5] Minimal feature engineering...")

# Clinical + PD + Pathway + Top 100 genes
clinical_features = ['UPDRS_BL', 'AGE', 'GENDER']
pd_genes = ['PD_SNCA', 'PD_LRRK2', 'PD_GBA', 'PD_PRKN', 'PD_PINK1', 'PD_PARK7', 'PD_VPS35']
pathway_features = ['PATHWAY_Inflammation', 'PATHWAY_Mitochondrial', 'PATHWAY_Autophagy']

# Key interactions (only 3)
merged_clean['PINK1_x_PARK7'] = merged_clean['PD_PINK1'] * merged_clean['PD_PARK7']
merged_clean['AGE_x_PINK1'] = merged_clean['AGE'] * merged_clean['PD_PINK1']
merged_clean['UPDRS_BL_x_PINK1'] = merged_clean['UPDRS_BL'] * merged_clean['PD_PINK1']

interaction_features = ['PINK1_x_PARK7', 'AGE_x_PINK1', 'UPDRS_BL_x_PINK1']

# Combine
all_features = clinical_features + top_100_genes + pd_genes + pathway_features + interaction_features
final_features = [f for f in all_features if f in merged_clean.columns]

print(f"  Feature breakdown:")
print(f"    Clinical: {len([f for f in clinical_features if f in final_features])}")
print(f"    Top genes: {len([f for f in top_100_genes if f in final_features])}")
print(f"    PD genes: {len([f for f in pd_genes if f in final_features])}")
print(f"    Pathways: {len([f for f in pathway_features if f in final_features])}")
print(f"    Interactions: {len([f for f in interaction_features if f in final_features])}")
print(f"    TOTAL: {len(final_features)}")

# Fill missing
for col in final_features:
    if merged_clean[col].isnull().sum() > 0:
        merged_clean[col].fillna(merged_clean[col].median(), inplace=True)

# X and y
X = merged_clean[final_features].values
y_v04 = merged_clean['UPDRS_V04'].values
y_clf = (merged_clean['DELTA_UPDRS'] >= 5).astype(int).values

print(f"  X shape: {X.shape}")

# ============================================================================
# STEP 4: DATA SPLITTING
# ============================================================================
print("\n[STEP 4/5] Data splitting...")

# Target transformation
target_transformer = PowerTransformer(method='yeo-johnson', standardize=True)
y_v04_transformed = target_transformer.fit_transform(y_v04.reshape(-1, 1)).flatten()

# Split
X_trainval, X_clinical, y_trainval_trans, y_clinical_trans, y_trainval_orig, y_clinical_orig, y_clf_trainval, y_clf_clinical = train_test_split(
    X, y_v04_transformed, y_v04, y_clf, test_size=0.2, random_state=RANDOM_SEED, stratify=y_clf
)

print(f"  Train+Val: {X_trainval.shape[0]}, Clinical: {X_clinical.shape[0]}")

# ============================================================================
# STEP 5: LIGHTWEIGHT HYPERPARAMETER OPTIMIZATION
# ============================================================================
print("\n[STEP 5/5] Lightweight hyperparameter optimization (30 trials)...")
print("  (This will take ~1 hour)")

def objective(trial):
    # XGBoost
    xgb_params = {
        'objective': 'reg:pseudohubererror',
        'n_estimators': trial.suggest_int('xgb_n_estimators', 100, 250),
        'max_depth': trial.suggest_int('xgb_max_depth', 3, 7),
        'learning_rate': trial.suggest_float('xgb_learning_rate', 0.01, 0.1, log=True),
        'subsample': trial.suggest_float('xgb_subsample', 0.6, 0.9),
        'colsample_bytree': trial.suggest_float('xgb_colsample_bytree', 0.6, 0.9),
        'min_child_weight': trial.suggest_int('xgb_min_child_weight', 1, 8),
        'reg_alpha': trial.suggest_float('xgb_reg_alpha', 0.01, 1.0, log=True),
        'reg_lambda': trial.suggest_float('xgb_reg_lambda', 0.1, 5.0, log=True),
        'random_state': RANDOM_SEED,
        'n_jobs': 2,  # Limited parallelism
        'verbosity': 0
    }
    
    # LightGBM
    lgbm_params = {
        'objective': 'huber',
        'n_estimators': trial.suggest_int('lgbm_n_estimators', 100, 250),
        'max_depth': trial.suggest_int('lgbm_max_depth', 3, 7),
        'learning_rate': trial.suggest_float('lgbm_learning_rate', 0.01, 0.1, log=True),
        'subsample': trial.suggest_float('lgbm_subsample', 0.6, 0.9),
        'colsample_bytree': trial.suggest_float('lgbm_colsample_bytree', 0.6, 0.9),
        'min_data_in_leaf': trial.suggest_int('lgbm_min_data_in_leaf', 5, 25),
        'reg_alpha': trial.suggest_float('lgbm_reg_alpha', 0.01, 1.0, log=True),
        'reg_lambda': trial.suggest_float('lgbm_reg_lambda', 0.1, 5.0, log=True),
        'random_state': RANDOM_SEED,
        'n_jobs': 2,  # Limited parallelism
        'verbose': -1
    }
    
    # CatBoost
    catboost_params = {
        'loss_function': 'RMSE',
        'iterations': trial.suggest_int('cat_iterations', 100, 250),
        'depth': trial.suggest_int('cat_depth', 3, 7),
        'learning_rate': trial.suggest_float('cat_learning_rate', 0.01, 0.1, log=True),
        'subsample': trial.suggest_float('cat_subsample', 0.6, 0.9),
        'reg_lambda': trial.suggest_float('cat_reg_lambda', 0.1, 5.0, log=True),
        'random_state': RANDOM_SEED,
        'thread_count': 2,  # Limited parallelism
        'verbose': False
    }
    
    # Meta-learner
    meta_alpha = trial.suggest_float('meta_alpha', 0.01, 1.0, log=True)
    meta_epsilon = trial.suggest_float('meta_epsilon', 1.0, 2.0)
    
    # Build ensemble (3 models only)
    base_models = [
        ('xgb', XGBRegressor(**xgb_params)),
        ('lgbm', LGBMRegressor(**lgbm_params)),
        ('catboost', CatBoostRegressor(**catboost_params))
    ]
    
    meta_learner = HuberRegressor(epsilon=meta_epsilon, alpha=meta_alpha, max_iter=300)
    
    ensemble_model = StackingRegressor(
        estimators=base_models,
        final_estimator=meta_learner,
        cv=5,
        n_jobs=2  # Limited parallelism
    )
    
    # 7-Fold CV
    cv = KFold(n_splits=7, shuffle=True, random_state=RANDOM_SEED)
    cv_scores = []
    
    for train_idx, val_idx in cv.split(X_trainval):
        X_train_fold = X_trainval[train_idx]
        y_train_fold = y_trainval_trans[train_idx]
        X_val_fold = X_trainval[val_idx]
        y_val_fold_orig = y_trainval_orig[val_idx]
        
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train_fold)
        X_val_scaled = scaler.transform(X_val_fold)
        
        ensemble_model.fit(X_train_scaled, y_train_fold)
        y_val_pred = ensemble_model.predict(X_val_scaled)
        y_val_pred_orig = target_transformer.inverse_transform(y_val_pred.reshape(-1, 1)).flatten()
        
        r2 = r2_score(y_val_fold_orig, y_val_pred_orig)
        cv_scores.append(r2)
    
    return np.mean(cv_scores)

# Run Optuna
study = optuna.create_study(direction='maximize', study_name='lightweight_optimization')
study.optimize(objective, n_trials=30, show_progress_bar=True)

print(f"\n  ✅ Optimization complete!")
print(f"  Best R²: {study.best_value:.3f}")

# ============================================================================
# FINAL MODEL & VALIDATION
# ============================================================================
print("\n[FINAL] Training final model with best hyperparameters...")

best_params = study.best_params

# Build final ensemble
xgb_final = XGBRegressor(
    objective='reg:pseudohubererror',
    n_estimators=best_params['xgb_n_estimators'],
    max_depth=best_params['xgb_max_depth'],
    learning_rate=best_params['xgb_learning_rate'],
    subsample=best_params['xgb_subsample'],
    colsample_bytree=best_params['xgb_colsample_bytree'],
    min_child_weight=best_params['xgb_min_child_weight'],
    reg_alpha=best_params['xgb_reg_alpha'],
    reg_lambda=best_params['xgb_reg_lambda'],
    random_state=RANDOM_SEED,
    n_jobs=2,
    verbosity=0
)

lgbm_final = LGBMRegressor(
    objective='huber',
    n_estimators=best_params['lgbm_n_estimators'],
    max_depth=best_params['lgbm_max_depth'],
    learning_rate=best_params['lgbm_learning_rate'],
    subsample=best_params['lgbm_subsample'],
    colsample_bytree=best_params['lgbm_colsample_bytree'],
    min_data_in_leaf=best_params['lgbm_min_data_in_leaf'],
    reg_alpha=best_params['lgbm_reg_alpha'],
    reg_lambda=best_params['lgbm_reg_lambda'],
    random_state=RANDOM_SEED,
    n_jobs=2,
    verbose=-1
)

catboost_final = CatBoostRegressor(
    loss_function='RMSE',
    iterations=best_params['cat_iterations'],
    depth=best_params['cat_depth'],
    learning_rate=best_params['cat_learning_rate'],
    subsample=best_params['cat_subsample'],
    reg_lambda=best_params['cat_reg_lambda'],
    random_state=RANDOM_SEED,
    thread_count=2,
    verbose=False
)

meta_final = HuberRegressor(
    epsilon=best_params['meta_epsilon'],
    alpha=best_params['meta_alpha'],
    max_iter=300
)

base_models_final = [
    ('xgb', xgb_final),
    ('lgbm', lgbm_final),
    ('catboost', catboost_final)
]

ensemble_final = StackingRegressor(
    estimators=base_models_final,
    final_estimator=meta_final,
    cv=5,
    n_jobs=2
)

# 7-Fold CV
print("  Running final 7-fold CV...")
cv = KFold(n_splits=7, shuffle=True, random_state=RANDOM_SEED)
cv_results = {'fold': [], 'r2': [], 'mae': [], 'rmse': []}

for fold_idx, (train_idx, val_idx) in enumerate(cv.split(X_trainval), 1):
    X_train_fold = X_trainval[train_idx]
    y_train_fold = y_trainval_trans[train_idx]
    X_val_fold = X_trainval[val_idx]
    y_val_fold_orig = y_trainval_orig[val_idx]
    
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_fold)
    X_val_scaled = scaler.transform(X_val_fold)
    
    ensemble_final.fit(X_train_scaled, y_train_fold)
    y_val_pred = ensemble_final.predict(X_val_scaled)
    y_val_pred_orig = target_transformer.inverse_transform(y_val_pred.reshape(-1, 1)).flatten()
    
    r2 = r2_score(y_val_fold_orig, y_val_pred_orig)
    mae = mean_absolute_error(y_val_fold_orig, y_val_pred_orig)
    rmse = np.sqrt(mean_squared_error(y_val_fold_orig, y_val_pred_orig))
    
    cv_results['fold'].append(fold_idx)
    cv_results['r2'].append(r2)
    cv_results['mae'].append(mae)
    cv_results['rmse'].append(rmse)
    
    print(f"    Fold {fold_idx}/7: R²={r2:.3f}, MAE={mae:.2f}")

cv_r2 = np.array(cv_results['r2'])
cv_mae = np.array(cv_results['mae'])
cv_rmse = np.array(cv_results['rmse'])

print(f"\n  ✅ Final 7-Fold CV Results:")
print(f"    R²:   {cv_r2.mean():.3f} ± {cv_r2.std():.3f}")
print(f"    MAE:  {cv_mae.mean():.2f} ± {cv_mae.std():.2f}")
print(f"    RMSE: {cv_rmse.mean():.2f} ± {cv_rmse.std():.2f}")

# Clinical holdout
scaler_final = StandardScaler()
X_trainval_scaled = scaler_final.fit_transform(X_trainval)
X_clinical_scaled = scaler_final.transform(X_clinical)

ensemble_final.fit(X_trainval_scaled, y_trainval_trans)

y_clinical_pred = ensemble_final.predict(X_clinical_scaled)
y_clinical_pred_orig = target_transformer.inverse_transform(y_clinical_pred.reshape(-1, 1)).flatten()

clinical_r2 = r2_score(y_clinical_orig, y_clinical_pred_orig)
clinical_mae = mean_absolute_error(y_clinical_orig, y_clinical_pred_orig)
clinical_rmse = np.sqrt(mean_squared_error(y_clinical_orig, y_clinical_pred_orig))

print(f"\n  Clinical Holdout:")
print(f"    R²:   {clinical_r2:.3f}")
print(f"    MAE:  {clinical_mae:.2f}")
print(f"    RMSE: {clinical_rmse:.2f}")

# ============================================================================
# SAVE MODEL
# ============================================================================
print("\n[SAVING] Saving optimized model...")

model_data = {
    'ensemble_model': ensemble_final,
    'scaler': scaler_final,
    'target_transformer': target_transformer,
    'feature_names': final_features,
    'best_params': best_params,
    'cv_results': cv_results,
    'clinical_results': {
        'r2': clinical_r2,
        'mae': clinical_mae,
        'rmse': clinical_rmse
    },
    'n_features': len(final_features)
}

joblib.dump(model_data, '/home/ubuntu/parkinson_progression/lightweight_optimized_model.pkl')
print("  ✅ Model saved: /home/ubuntu/parkinson_progression/lightweight_optimized_model.pkl")

# Save results
results_summary = pd.DataFrame([{
    'baseline_r2': 0.427,
    'lightweight_cv_r2': cv_r2.mean(),
    'lightweight_cv_mae': cv_mae.mean(),
    'lightweight_clinical_r2': clinical_r2,
    'lightweight_clinical_mae': clinical_mae,
    'improvement_from_baseline': cv_r2.mean() - 0.427,
    'n_features': len(final_features),
    'target_reached': 'YES' if cv_r2.mean() >= 0.60 else 'NO'
}])

results_summary.to_csv('/home/ubuntu/parkinson_progression/lightweight_optimization_results.csv', index=False)
print("  ✅ Results saved: /home/ubuntu/parkinson_progression/lightweight_optimization_results.csv")

# Save detailed CV results
pd.DataFrame(cv_results).to_csv('/home/ubuntu/parkinson_progression/lightweight_cv_detailed.csv', index=False)
print("  ✅ Detailed CV results saved")

print("\n" + "=" * 80)
print("✅ LIGHTWEIGHT OPTIMIZATION COMPLETE!")
print("=" * 80)
print(f"\nResults:")
print(f"  Baseline R²:     0.427")
print(f"  Lightweight R²:  {cv_r2.mean():.3f} (CV) / {clinical_r2:.3f} (Clinical)")
print(f"  Improvement:     +{cv_r2.mean() - 0.427:.3f} from baseline (+{(cv_r2.mean() - 0.427)/0.427*100:.1f}%)")
print(f"  Target (0.60):   {'✅ REACHED!' if cv_r2.mean() >= 0.60 else f'❌ Not reached (gap: {0.60 - cv_r2.mean():.3f})'}")
print(f"  No overfitting:  CV={cv_r2.mean():.3f} ≈ Clinical={clinical_r2:.3f}")
print("=" * 80)
