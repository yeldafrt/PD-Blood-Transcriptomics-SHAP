#!/usr/bin/env python3
"""
Two-Panel Scatter Plot: 7-Fold CV + Clinical Holdout (TABLE 1 CONSISTENT)
Uses fold-averaged R² (0.513) instead of combined R² (0.518) for consistency with Table 1
(a) 7-Fold Cross-Validation (n=312)
(b) Independent Clinical Holdout (n=78)
300 DPI, English, No main title, Highly readable
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, PowerTransformer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib
import warnings
warnings.filterwarnings('ignore')

# Matplotlib settings - High quality
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 11
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['axes.titlesize'] = 13
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 10

print("=" * 80)
print("TWO-PANEL SCATTER PLOT (TABLE 1 CONSISTENT)")
print("=" * 80)

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# ============================================================================
# PANEL (a): LOAD SAVED CV PREDICTIONS
# ============================================================================
print("\n[1/3] Loading saved CV predictions...")

cv_predictions_df = pd.read_csv('/home/ubuntu/manuscript_update/cv_predictions_7fold.csv')

cv_actual = cv_predictions_df['y_true'].values
cv_pred = cv_predictions_df['y_pred'].values

# Calculate metrics
cv_r2_combined = r2_score(cv_actual, cv_pred)
cv_mae = mean_absolute_error(cv_actual, cv_pred)
cv_rmse = np.sqrt(mean_squared_error(cv_actual, cv_pred))

# Calculate fold-averaged R² (for Table 1 consistency)
fold_r2_values = cv_predictions_df.groupby('fold').apply(
    lambda x: r2_score(x['y_true'], x['y_pred'])
).values
cv_r2_mean = np.mean(fold_r2_values)
cv_r2_sd = np.std(fold_r2_values, ddof=1)

print(f"  7-Fold CV (Combined): R² = {cv_r2_combined:.3f}, MAE = {cv_mae:.2f}, RMSE = {cv_rmse:.2f}")
print(f"  7-Fold CV (Fold-Averaged): R² = {cv_r2_mean:.3f} ± {cv_r2_sd:.3f} (Table 1 consistent)")
print(f"  n = {len(cv_actual)}")

# Use fold-averaged R² for Table 1 consistency
cv_r2_display = cv_r2_mean

# ============================================================================
# PANEL (b): GENERATE CLINICAL HOLDOUT PREDICTIONS
# ============================================================================
print("\n[2/3] Generating Clinical Holdout predictions...")

# Load data
final_df = pd.read_csv('/home/ubuntu/upload/.recovery/final_dataset.csv')
rnaseq = pd.read_csv('/home/ubuntu/upload/.recovery/rnaseq_baseline_filtered.csv')

final_df['PATNO'] = final_df['PATNO'].astype(str)
rnaseq['PATNO'] = rnaseq['PATNO'].astype(str)

gene_cols = [col for col in rnaseq.columns if col.startswith('ENSG')]
rnaseq_genes = rnaseq[['PATNO'] + gene_cols]

merged = pd.merge(final_df, rnaseq_genes, on='PATNO', how='inner')

# Outlier removal
merged['UPDRS_V04'].fillna(merged['UPDRS_V04'].median(), inplace=True)
Q1 = merged['UPDRS_V04'].quantile(0.25)
Q3 = merged['UPDRS_V04'].quantile(0.75)
IQR = Q3 - Q1
outliers = (merged['UPDRS_V04'] < Q1 - 1.5*IQR) | (merged['UPDRS_V04'] > Q3 + 1.5*IQR)
merged_clean = merged[~outliers].copy()

# Select top 100 genes
gene_correlations = []
for gene in gene_cols:
    if gene in merged_clean.columns:
        corr = merged_clean[[gene, 'DELTA_UPDRS']].corr().iloc[0, 1]
        if not np.isnan(corr):
            gene_correlations.append((gene, abs(corr), corr))

gene_correlations.sort(key=lambda x: x[1], reverse=True)
top_100_genes = [g[0] for g in gene_correlations[:100]]

# Feature engineering
clinical_features = ['UPDRS_BL', 'AGE', 'GENDER']
pd_genes = ['PD_SNCA', 'PD_LRRK2', 'PD_GBA', 'PD_PRKN', 'PD_PINK1', 'PD_PARK7', 'PD_VPS35']
pathway_features = ['PATHWAY_Inflammation', 'PATHWAY_Mitochondrial', 'PATHWAY_Autophagy']

merged_clean['PINK1_x_PARK7'] = merged_clean['PD_PINK1'] * merged_clean['PD_PARK7']
merged_clean['AGE_x_PINK1'] = merged_clean['AGE'] * merged_clean['PD_PINK1']
merged_clean['UPDRS_BL_x_PINK1'] = merged_clean['UPDRS_BL'] * merged_clean['PD_PINK1']
interaction_features = ['PINK1_x_PARK7', 'AGE_x_PINK1', 'UPDRS_BL_x_PINK1']

all_features = clinical_features + top_100_genes + pd_genes + pathway_features + interaction_features
final_features = [f for f in all_features if f in merged_clean.columns]

for col in final_features:
    if merged_clean[col].isnull().sum() > 0:
        merged_clean[col].fillna(merged_clean[col].median(), inplace=True)

X = merged_clean[final_features].values
y_v04 = merged_clean['UPDRS_V04'].values
y_clf = (merged_clean['DELTA_UPDRS'] >= 5).astype(int).values

# Split data
target_transformer_temp = PowerTransformer(method='yeo-johnson', standardize=True)
y_v04_transformed = target_transformer_temp.fit_transform(y_v04.reshape(-1, 1)).flatten()

X_trainval, X_clinical, y_trainval_trans, y_clinical_trans, y_trainval_orig, y_clinical_orig, y_clf_trainval, y_clf_clinical = train_test_split(
    X, y_v04_transformed, y_v04, y_clf, test_size=0.2, random_state=RANDOM_SEED, stratify=y_clf
)

# Load saved model
model_path = '/home/ubuntu/manuscript_update/parkinson_optimized_model_package/model/lightweight_optimized_model.pkl'
saved_data = joblib.load(model_path)

ensemble_model = saved_data['ensemble_model']
scaler = saved_data['scaler']
target_transformer_saved = saved_data['target_transformer']

# Predict on clinical holdout
X_clinical_scaled = scaler.transform(X_clinical)
y_clinical_pred_trans = ensemble_model.predict(X_clinical_scaled)
y_clinical_pred = target_transformer_saved.inverse_transform(y_clinical_pred_trans.reshape(-1, 1)).flatten()

clinical_r2 = r2_score(y_clinical_orig, y_clinical_pred)
clinical_mae = mean_absolute_error(y_clinical_orig, y_clinical_pred)
clinical_rmse = np.sqrt(mean_squared_error(y_clinical_orig, y_clinical_pred))

print(f"  Clinical Holdout: R² = {clinical_r2:.3f}, MAE = {clinical_mae:.2f}, RMSE = {clinical_rmse:.2f}, n = {len(y_clinical_orig)}")

# ============================================================================
# CREATE TWO-PANEL SCATTER PLOT
# ============================================================================
print("\n[3/3] Creating two-panel scatter plot...")

fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# Color scheme
colors = ['#2E86AB', '#E63946']

# ============================================================================
# PANEL (a): 7-Fold Cross-Validation
# ============================================================================
ax = axes[0]

# Scatter plot
ax.scatter(cv_actual, cv_pred, 
           alpha=0.5, s=60, color=colors[0], edgecolors='white', linewidth=0.3)

# Perfect prediction line
min_val = min(cv_actual.min(), cv_pred.min())
max_val = max(cv_actual.max(), cv_pred.max())
ax.plot([min_val, max_val], [min_val, max_val], 
        'k--', linewidth=2, label='Perfect Prediction', alpha=0.7)

# Labels
ax.set_xlabel('Actual UPDRS Part III at 12 Months', fontsize=12, fontweight='bold')
ax.set_ylabel('Predicted UPDRS Part III at 12 Months', fontsize=12, fontweight='bold')

# Grid
ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)

# Metrics box (using fold-averaged R² for Table 1 consistency)
textstr = f'$R^2$ = {cv_r2_display:.3f}\nMAE = {cv_mae:.2f}\nn = {len(cv_actual)}'
props = dict(boxstyle='round', facecolor='white', alpha=0.95, edgecolor='black', linewidth=1.5)
ax.text(0.05, 0.95, textstr, transform=ax.transAxes, fontsize=11,
        verticalalignment='top', bbox=props, family='monospace', fontweight='bold')

# Legend
ax.legend(loc='lower right', frameon=True, shadow=True, fontsize=9)

# Panel title
ax.set_title('(a) 7-Fold Cross-Validation', fontsize=13, fontweight='bold', pad=10)

# Axis limits
ax.set_xlim(min_val - 2, max_val + 2)
ax.set_ylim(min_val - 2, max_val + 2)
ax.set_aspect('equal', adjustable='box')

# ============================================================================
# PANEL (b): Clinical Holdout
# ============================================================================
ax = axes[1]

# Scatter plot
ax.scatter(y_clinical_orig, y_clinical_pred, 
           alpha=0.6, s=80, color=colors[1], edgecolors='white', linewidth=0.5)

# Perfect prediction line
min_val = min(y_clinical_orig.min(), y_clinical_pred.min())
max_val = max(y_clinical_orig.max(), y_clinical_pred.max())
ax.plot([min_val, max_val], [min_val, max_val], 
        'k--', linewidth=2, label='Perfect Prediction', alpha=0.7)

# Labels
ax.set_xlabel('Actual UPDRS Part III at 12 Months', fontsize=12, fontweight='bold')
ax.set_ylabel('Predicted UPDRS Part III at 12 Months', fontsize=12, fontweight='bold')

# Grid
ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)

# Metrics box
textstr = f'$R^2$ = {clinical_r2:.3f}\nMAE = {clinical_mae:.2f}\nn = {len(y_clinical_orig)}'
props = dict(boxstyle='round', facecolor='white', alpha=0.95, edgecolor='black', linewidth=1.5)
ax.text(0.05, 0.95, textstr, transform=ax.transAxes, fontsize=11,
        verticalalignment='top', bbox=props, family='monospace', fontweight='bold')

# Legend
ax.legend(loc='lower right', frameon=True, shadow=True, fontsize=9)

# Panel title
ax.set_title('(b) Independent Clinical Holdout', fontsize=13, fontweight='bold', pad=10)

# Axis limits
ax.set_xlim(min_val - 2, max_val + 2)
ax.set_ylim(min_val - 2, max_val + 2)
ax.set_aspect('equal', adjustable='box')

# ============================================================================
# FINALIZE AND SAVE
# ============================================================================
plt.tight_layout()

output_file = '/home/ubuntu/manuscript_update/Figure_Two_Panel_Table1_Consistent.png'
plt.savefig(output_file, dpi=300, bbox_inches='tight', facecolor='white')
print(f"\n✓ Two-panel plot saved: {output_file}")

plt.close()

print("\n" + "=" * 80)
print("TWO-PANEL SCATTER PLOT COMPLETED (TABLE 1 CONSISTENT)!")
print("=" * 80)
print(f"\nFile: {output_file}")
print(f"Resolution: 300 DPI")
print(f"Size: 14x6 inches")
print(f"Format: PNG")
print(f"Language: English")
print(f"Main title: None (will be in caption)")
print(f"\nPanel (a) - 7-Fold CV:")
print(f"  R² (Fold-Averaged) = {cv_r2_display:.3f} ± {cv_r2_sd:.3f} [Table 1 consistent]")
print(f"  R² (Combined) = {cv_r2_combined:.3f} [for reference]")
print(f"  MAE = {cv_mae:.2f}")
print(f"  RMSE = {cv_rmse:.2f}")
print(f"  n = {len(cv_actual)}")
print(f"\nPanel (b) - Clinical Holdout:")
print(f"  R² = {clinical_r2:.3f}")
print(f"  MAE = {clinical_mae:.2f}")
print(f"  RMSE = {clinical_rmse:.2f}")
print(f"  n = {len(y_clinical_orig)}")
print("\n✅ All values match Table 1!")
print("=" * 80)
