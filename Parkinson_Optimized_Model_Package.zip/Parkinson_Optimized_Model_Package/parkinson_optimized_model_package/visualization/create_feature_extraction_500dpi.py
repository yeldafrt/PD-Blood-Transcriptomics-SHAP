#!/usr/bin/env python3
"""
Figure 2: Feature Importance (Top 20)
500 DPI TIFF format for journal submission
With panel label (a)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import joblib
import warnings
warnings.filterwarnings('ignore')

# Matplotlib settings - High quality for journal
plt.rcParams['figure.dpi'] = 500
plt.rcParams['savefig.dpi'] = 500
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 12
plt.rcParams['axes.labelsize'] = 14
plt.rcParams['axes.titlesize'] = 16
plt.rcParams['xtick.labelsize'] = 12
plt.rcParams['ytick.labelsize'] = 12
plt.rcParams['legend.fontsize'] = 12

print("=" * 80)
print("FIGURE 2: FEATURE IMPORTANCE (500 DPI TIFF)")
print("=" * 80)

# ============================================================================
# STEP 1: LOAD MODEL AND EXTRACT FEATURE IMPORTANCE
# ============================================================================
print("\n[1/3] Loading model and extracting feature importance...")

model_path = '/home/ubuntu/manuscript_update/parkinson_optimized_model_package/model/lightweight_optimized_model.pkl'
saved_data = joblib.load(model_path)

ensemble_model = saved_data['ensemble_model']
feature_names = saved_data['feature_names']

# Extract feature importance from base estimators
base_importances = []
for estimator in ensemble_model.estimators_:
    if hasattr(estimator, 'feature_importances_'):
        base_importances.append(estimator.feature_importances_)
    elif hasattr(estimator, 'coef_'):
        base_importances.append(np.abs(estimator.coef_))

if len(base_importances) > 0:
    importances = np.mean(base_importances, axis=0)
else:
    raise ValueError("No feature importances found in base estimators")

# Normalize to sum to 1
importances = importances / np.sum(importances)

print(f"  ✓ {len(feature_names)} features loaded")

# ============================================================================
# STEP 2: CATEGORIZE FEATURES
# ============================================================================
print("\n[2/3] Categorizing features...")

def categorize_feature(feature_name):
    """Categorize feature by name"""
    if feature_name in ['UPDRS_BL', 'AGE', 'GENDER']:
        return 'Clinical'
    elif feature_name.startswith('PD_'):
        return 'PD Genes'
    elif feature_name.startswith('PATHWAY_'):
        return 'Pathways'
    elif '_x_' in feature_name:
        return 'Interactions'
    elif feature_name.startswith('ENSG'):
        return 'RNA-seq Genes'
    else:
        return 'Other'

# Create DataFrame
importance_df = pd.DataFrame({
    'Feature': feature_names,
    'Importance': importances
})

importance_df['Category'] = importance_df['Feature'].apply(categorize_feature)
importance_df = importance_df.sort_values('Importance', ascending=False)

# Select top 20
top_20 = importance_df.head(20).copy()
top_20 = top_20.sort_values('Importance', ascending=True)  # For horizontal bar plot

print(f"  ✓ Top 20 features selected")

# ============================================================================
# STEP 3: CREATE FIGURE 2
# ============================================================================
print("\n[3/3] Creating Figure 2...")

# Sharp colors by category
category_colors = {
    'Clinical': '#2E86AB',          # Blue
    'PD Genes': '#A23B72',          # Purple
    'RNA-seq Genes': '#06A77D',     # Green
    'Pathways': '#F77F00',          # Orange
    'Interactions': '#E63946',      # Red
    'Other': '#6C757D'              # Gray
}

# Assign colors
colors = [category_colors[cat] for cat in top_20['Category']]

# Create figure
fig, ax = plt.subplots(figsize=(10, 10))

# Horizontal bar plot
bars = ax.barh(range(len(top_20)), top_20['Importance'], 
               color=colors, edgecolor='black', linewidth=1.5, alpha=0.85)

# Feature names
feature_labels = []
for feat in top_20['Feature']:
    if feat.startswith('ENSG'):
        # Shorten gene names
        label = feat[:15] + '...' if len(feat) > 15 else feat
    elif feat.startswith('PATHWAY_'):
        # Remove PATHWAY_ prefix
        label = feat.replace('PATHWAY_', '')
    elif feat.startswith('PD_'):
        # Keep PD_ prefix
        label = feat
    elif '_x_' in feat:
        # Shorten interaction names
        parts = feat.split('_x_')
        label = f"{parts[0][:8]}×{parts[1][:8]}"
    else:
        label = feat
    feature_labels.append(label)

ax.set_yticks(range(len(top_20)))
ax.set_yticklabels(feature_labels, fontsize=12, fontweight='bold')

# Labels
ax.set_xlabel('Feature Importance', fontsize=14, fontweight='bold')
ax.set_ylabel('Features', fontsize=14, fontweight='bold')

# Grid
ax.grid(True, alpha=0.3, linestyle='--', axis='x')
ax.set_axisbelow(True)

# Add importance values on bars
for i, (bar, imp) in enumerate(zip(bars, top_20['Importance'])):
    width = bar.get_width()
    ax.text(width + 0.001, bar.get_y() + bar.get_height()/2,
            f'{imp:.3f}',
            ha='left', va='center', fontsize=10, fontweight='bold')

# Legend
from matplotlib.patches import Patch
legend_elements = [Patch(facecolor=category_colors[cat], edgecolor='black', 
                         linewidth=1.5, label=cat, alpha=0.85)
                   for cat in sorted(top_20['Category'].unique())]
ax.legend(handles=legend_elements, loc='lower right', 
          frameon=True, shadow=True, fontsize=11, title='Category',
          title_fontsize=12)

# ============================================================================
# NO PANEL LABEL (user preference)
# ============================================================================
# Panel label removed as per user request

# Tight layout
plt.tight_layout()

# ============================================================================
# SAVE AS 500 DPI TIFF
# ============================================================================
output_tiff = '/home/ubuntu/Figure2.tif'
output_png = '/home/ubuntu/Figure2.png'

# Save TIFF (for submission)
plt.savefig(output_tiff, dpi=500, format='tiff', bbox_inches='tight', 
            facecolor='white', pil_kwargs={'compression': 'tiff_lzw'})
print(f"\n✓ TIFF saved: {output_tiff} (500 DPI, lossless compression)")

# Save PNG (for preview)
plt.savefig(output_png, dpi=500, format='png', bbox_inches='tight', facecolor='white')
print(f"✓ PNG saved: {output_png} (500 DPI, preview)")

plt.close()

# ============================================================================
# SUMMARY
# ============================================================================
print("\n" + "=" * 80)
print("FIGURE 2 COMPLETED!")
print("=" * 80)
print(f"\nSubmission file: {output_tiff}")
print(f"Preview file: {output_png}")
print(f"Resolution: 500 DPI")
print(f"Format: TIFF (lossless compression)")
print(f"Size: 10x10 inches")
print(f"Panel label: (a)")
print(f"\nTop 5 Features:")
print("-" * 80)
for i, row in importance_df.head(5).iterrows():
    print(f"  {row['Feature']:40s} {row['Importance']:.4f}  [{row['Category']}]")
print("=" * 80)
