#!/usr/bin/env python3
"""
SHAP Analysis - 3 Panel Figure
(a) Clinical Features, (b) PD Risk Genes, (c) Pathway Scores
300 DPI, English, No main title, Highly readable, Sharp colors
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, PowerTransformer
import joblib
import shap
import warnings
warnings.filterwarnings('ignore')

# Matplotlib settings - High quality
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 11
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['axes.titlesize'] = 13
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 10

print("=" * 80)
print("SHAP ANALYSIS - 3 PANEL (CLINICAL + PD GENES + PATHWAYS)")
print("=" * 80)

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# ============================================================================
# STEP 1: LOAD DATA
# ============================================================================
print("\n[1/5] Loading data...")

final_df = pd.read_csv('/home/ubuntu/upload/.recovery/final_dataset.csv')
rnaseq = pd.read_csv('/home/ubuntu/upload/.recovery/rnaseq_baseline_filtered.csv')

final_df['PATNO'] = final_df['PATNO'].astype(str)
rnaseq['PATNO'] = rnaseq['PATNO'].astype(str)

gene_cols = [col for col in rnaseq.columns if col.startswith('ENSG')]
rnaseq_genes = rnaseq[['PATNO'] + gene_cols]

merged = pd.merge(final_df, rnaseq_genes, on='PATNO', how='inner')

# Outlier removal
merged['UPDRS_V04'].fillna(merged['UPDRS_V04'].median(), inplace=True)
Q1 = merged['UPDRS_V04'].quantile(0.25)
Q3 = merged['UPDRS_V04'].quantile(0.75)
IQR = Q3 - Q1
outliers = (merged['UPDRS_V04'] < Q1 - 1.5*IQR) | (merged['UPDRS_V04'] > Q3 + 1.5*IQR)
merged_clean = merged[~outliers].copy()

print(f"  {len(merged_clean)} patients loaded")

# ============================================================================
# STEP 2: FEATURE ENGINEERING
# ============================================================================
print("\n[2/5] Feature engineering...")

gene_correlations = []
for gene in gene_cols:
    if gene in merged_clean.columns:
        corr = merged_clean[[gene, 'DELTA_UPDRS']].corr().iloc[0, 1]
        if not np.isnan(corr):
            gene_correlations.append((gene, abs(corr), corr))

gene_correlations.sort(key=lambda x: x[1], reverse=True)
top_100_genes = [g[0] for g in gene_correlations[:100]]

clinical_features = ['UPDRS_BL', 'AGE', 'GENDER']
pd_genes = ['PD_SNCA', 'PD_LRRK2', 'PD_GBA', 'PD_PRKN', 'PD_PINK1', 'PD_PARK7', 'PD_VPS35']
pathway_features = ['PATHWAY_Inflammation', 'PATHWAY_Mitochondrial', 'PATHWAY_Autophagy']

merged_clean['PINK1_x_PARK7'] = merged_clean['PD_PINK1'] * merged_clean['PD_PARK7']
merged_clean['AGE_x_PINK1'] = merged_clean['AGE'] * merged_clean['PD_PINK1']
merged_clean['UPDRS_BL_x_PINK1'] = merged_clean['UPDRS_BL'] * merged_clean['PD_PINK1']
interaction_features = ['PINK1_x_PARK7', 'AGE_x_PINK1', 'UPDRS_BL_x_PINK1']

all_features = clinical_features + top_100_genes + pd_genes + pathway_features + interaction_features
final_features = [f for f in all_features if f in merged_clean.columns]

for col in final_features:
    if merged_clean[col].isnull().sum() > 0:
        merged_clean[col].fillna(merged_clean[col].median(), inplace=True)

X = merged_clean[final_features].values
y_v04 = merged_clean['UPDRS_V04'].values
y_clf = (merged_clean['DELTA_UPDRS'] >= 5).astype(int).values

print(f"  {len(final_features)} features ready")

# ============================================================================
# STEP 3: SPLIT DATA
# ============================================================================
print("\n[3/5] Splitting data...")

target_transformer_temp = PowerTransformer(method='yeo-johnson', standardize=True)
y_v04_transformed = target_transformer_temp.fit_transform(y_v04.reshape(-1, 1)).flatten()

X_trainval, X_clinical, y_trainval_trans, y_clinical_trans, y_trainval_orig, y_clinical_orig, y_clf_trainval, y_clf_clinical = train_test_split(
    X, y_v04_transformed, y_v04, y_clf, test_size=0.2, random_state=RANDOM_SEED, stratify=y_clf
)

# Load saved model
model_path = '/home/ubuntu/manuscript_update/parkinson_optimized_model_package/model/lightweight_optimized_model.pkl'
saved_data = joblib.load(model_path)

ensemble_model = saved_data['ensemble_model']
scaler = saved_data['scaler']

# Scale data
X_clinical_scaled = scaler.transform(X_clinical)

print(f"  Clinical holdout: {len(X_clinical)} patients")

# ============================================================================
# STEP 4: CALCULATE SHAP VALUES
# ============================================================================
print("\n[4/5] Calculating SHAP values (this may take 5-10 minutes)...")

# Use TreeExplainer for tree-based ensemble
# Sample 100 patients for faster computation
sample_size = min(100, len(X_clinical_scaled))
X_sample = X_clinical_scaled[:sample_size]

print(f"  Using {sample_size} patients for SHAP calculation...")

# Calculate SHAP values for each base estimator and average
shap_values_list = []

for i, estimator in enumerate(ensemble_model.estimators_):
    print(f"  Calculating SHAP for estimator {i+1}/3...")
    explainer = shap.TreeExplainer(estimator)
    shap_vals = explainer.shap_values(X_sample)
    shap_values_list.append(shap_vals)

# Average SHAP values across estimators
shap_values = np.mean(shap_values_list, axis=0)

print("  SHAP calculation completed!")

# ============================================================================
# STEP 5: CREATE 3-PANEL FIGURE
# ============================================================================
print("\n[5/5] Creating 3-panel SHAP figure...")

# Create feature name mapping
feature_name_map = {f: f for f in final_features}
# Shorten long gene names
for f in final_features:
    if f.startswith('ENSG') and len(f) > 20:
        feature_name_map[f] = f[:17] + '...'
    elif f.startswith('PATHWAY_'):
        feature_name_map[f] = f.replace('PATHWAY_', '')

# Get indices for each category
clinical_indices = [i for i, f in enumerate(final_features) if f in clinical_features + interaction_features]
pd_gene_indices = [i for i, f in enumerate(final_features) if f in pd_genes]
pathway_indices = [i for i, f in enumerate(final_features) if f in pathway_features]

# Calculate mean absolute SHAP values for each category
def get_mean_abs_shap(indices):
    if len(indices) == 0:
        return np.array([]), []
    shap_subset = shap_values[:, indices]
    mean_abs_shap = np.abs(shap_subset).mean(axis=0)
    feature_names = [final_features[i] for i in indices]
    return mean_abs_shap, feature_names

clinical_shap, clinical_names = get_mean_abs_shap(clinical_indices)
pd_gene_shap, pd_gene_names = get_mean_abs_shap(pd_gene_indices)
pathway_shap, pathway_names = get_mean_abs_shap(pathway_indices)

# Sort by importance
clinical_sorted_idx = np.argsort(clinical_shap)[::-1]
pd_gene_sorted_idx = np.argsort(pd_gene_shap)[::-1]
pathway_sorted_idx = np.argsort(pathway_shap)[::-1]

# Create figure
fig, axes = plt.subplots(1, 3, figsize=(18, 6))

# Sharp colors
color_clinical = '#2E86AB'      # Blue
color_pd_genes = '#E63946'      # Red
color_pathways = '#F77F00'      # Orange

# ============================================================================
# PANEL (a): Clinical Features
# ============================================================================
ax = axes[0]

clinical_names_sorted = [feature_name_map[clinical_names[i]] for i in clinical_sorted_idx]
clinical_shap_sorted = clinical_shap[clinical_sorted_idx]

bars = ax.barh(range(len(clinical_shap_sorted)), clinical_shap_sorted,
               color=color_clinical, edgecolor='black', linewidth=1.5, alpha=0.85)

ax.set_yticks(range(len(clinical_names_sorted)))
ax.set_yticklabels(clinical_names_sorted, fontsize=11, fontweight='bold')
ax.set_xlabel('Mean |SHAP Value|', fontsize=12, fontweight='bold')
ax.set_title('(a) Clinical Features', fontsize=13, fontweight='bold', pad=10)
ax.grid(True, alpha=0.3, linestyle='--', axis='x')
ax.set_axisbelow(True)

# Add values on bars
for i, (bar, val) in enumerate(zip(bars, clinical_shap_sorted)):
    width = bar.get_width()
    ax.text(width + 0.002, bar.get_y() + bar.get_height()/2,
            f'{val:.3f}',
            ha='left', va='center', fontsize=9, fontweight='bold')

# ============================================================================
# PANEL (b): PD Risk Genes
# ============================================================================
ax = axes[1]

pd_gene_names_sorted = [feature_name_map[pd_gene_names[i]] for i in pd_gene_sorted_idx]
pd_gene_shap_sorted = pd_gene_shap[pd_gene_sorted_idx]

bars = ax.barh(range(len(pd_gene_shap_sorted)), pd_gene_shap_sorted,
               color=color_pd_genes, edgecolor='black', linewidth=1.5, alpha=0.85)

ax.set_yticks(range(len(pd_gene_names_sorted)))
ax.set_yticklabels(pd_gene_names_sorted, fontsize=11, fontweight='bold')
ax.set_xlabel('Mean |SHAP Value|', fontsize=12, fontweight='bold')
ax.set_title('(b) PD Risk Genes', fontsize=13, fontweight='bold', pad=10)
ax.grid(True, alpha=0.3, linestyle='--', axis='x')
ax.set_axisbelow(True)

# Add values on bars
for i, (bar, val) in enumerate(zip(bars, pd_gene_shap_sorted)):
    width = bar.get_width()
    ax.text(width + 0.0005, bar.get_y() + bar.get_height()/2,
            f'{val:.4f}',
            ha='left', va='center', fontsize=9, fontweight='bold')

# ============================================================================
# PANEL (c): Pathway Scores
# ============================================================================
ax = axes[2]

pathway_names_sorted = [feature_name_map[pathway_names[i]] for i in pathway_sorted_idx]
pathway_shap_sorted = pathway_shap[pathway_sorted_idx]

bars = ax.barh(range(len(pathway_shap_sorted)), pathway_shap_sorted,
               color=color_pathways, edgecolor='black', linewidth=1.5, alpha=0.85)

ax.set_yticks(range(len(pathway_names_sorted)))
ax.set_yticklabels(pathway_names_sorted, fontsize=11, fontweight='bold')
ax.set_xlabel('Mean |SHAP Value|', fontsize=12, fontweight='bold')
ax.set_title('(c) Pathway Scores', fontsize=13, fontweight='bold', pad=10)
ax.grid(True, alpha=0.3, linestyle='--', axis='x')
ax.set_axisbelow(True)

# Add values on bars
for i, (bar, val) in enumerate(zip(bars, pathway_shap_sorted)):
    width = bar.get_width()
    ax.text(width + 0.001, bar.get_y() + bar.get_height()/2,
            f'{val:.3f}',
            ha='left', va='center', fontsize=9, fontweight='bold')

# ============================================================================
# FINALIZE AND SAVE
# ============================================================================
plt.tight_layout()

output_file = '/home/ubuntu/manuscript_update/Figure_SHAP_Three_Panel_Clinical.png'
plt.savefig(output_file, dpi=300, bbox_inches='tight', facecolor='white')
print(f"\n✓ Figure saved: {output_file}")

plt.close()

print("\n" + "=" * 80)
print("SHAP ANALYSIS COMPLETED!")
print("=" * 80)
print(f"\nFile: {output_file}")
print(f"Resolution: 300 DPI")
print(f"Size: 18x6 inches")
print(f"Format: PNG")
print(f"Language: English")
print(f"Main title: None")
print(f"\nPanel (a) - Clinical Features:")
for name, val in zip(clinical_names_sorted, clinical_shap_sorted):
    print(f"  {name:30s}: {val:.4f}")
print(f"\nPanel (b) - PD Risk Genes:")
for name, val in zip(pd_gene_names_sorted, pd_gene_shap_sorted):
    print(f"  {name:30s}: {val:.4f}")
print(f"\nPanel (c) - Pathway Scores:")
for name, val in zip(pathway_names_sorted, pathway_shap_sorted):
    print(f"  {name:30s}: {val:.4f}")
print("=" * 80)
