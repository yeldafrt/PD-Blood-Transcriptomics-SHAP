#!/usr/bin/env python3
"""
Figure 1: Model Architecture and Comprehensive Performance Evaluation (6 panels)
Panel A: Model Architecture
Panel B: Predicted vs Actual (Independent Test, n=78)
Panel C: Residuals
Panel D: Violin Plot (Distribution Comparison)
Panel E: 7-Fold CV (n=312)
Panel F: Independent Holdout (n=78)

500 DPI TIFF format for journal submission
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PowerTransformer
from sklearn.metrics import mean_absolute_error, r2_score
import joblib
import warnings
warnings.filterwarnings('ignore')

# High-quality settings for journal (500 DPI for combination figures)
plt.rcParams['figure.dpi'] = 500
plt.rcParams['savefig.dpi'] = 500
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 9
plt.rcParams['axes.labelsize'] = 10
plt.rcParams['axes.titlesize'] = 11
plt.rcParams['xtick.labelsize'] = 8
plt.rcParams['ytick.labelsize'] = 8
plt.rcParams['legend.fontsize'] = 8

print("=" * 80)
print("CREATING FIGURE 1: 6-PANEL COMPREHENSIVE PERFORMANCE EVALUATION")
print("=" * 80)

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# ============================================================================
# LOAD DATA AND MODEL
# ============================================================================
print("\n[1/7] Loading data and model...")

final_df = pd.read_csv('/home/ubuntu/upload/.recovery/final_dataset.csv')
rnaseq = pd.read_csv('/home/ubuntu/upload/.recovery/rnaseq_baseline_filtered.csv')

final_df['PATNO'] = final_df['PATNO'].astype(str)
rnaseq['PATNO'] = rnaseq['PATNO'].astype(str)

gene_cols = [col for col in rnaseq.columns if col.startswith('ENSG')]
rnaseq_genes = rnaseq[['PATNO'] + gene_cols]

merged = pd.merge(final_df, rnaseq_genes, on='PATNO', how='inner')

# Outlier removal
merged['UPDRS_V04'].fillna(merged['UPDRS_V04'].median(), inplace=True)
Q1 = merged['UPDRS_V04'].quantile(0.25)
Q3 = merged['UPDRS_V04'].quantile(0.75)
IQR = Q3 - Q1
outliers = (merged['UPDRS_V04'] < Q1 - 1.5*IQR) | (merged['UPDRS_V04'] > Q3 + 1.5*IQR)
merged_clean = merged[~outliers].copy()

print(f"  {len(merged_clean)} patients loaded")

# Select top 100 genes
gene_correlations = []
for gene in gene_cols:
    if gene in merged_clean.columns:
        corr = merged_clean[[gene, 'DELTA_UPDRS']].corr().iloc[0, 1]
        if not np.isnan(corr):
            gene_correlations.append((gene, abs(corr), corr))

gene_correlations.sort(key=lambda x: x[1], reverse=True)
top_100_genes = [g[0] for g in gene_correlations[:100]]

# Feature engineering
clinical_features = ['UPDRS_BL', 'AGE', 'GENDER']
pd_genes = ['PD_SNCA', 'PD_LRRK2', 'PD_GBA', 'PD_PRKN', 'PD_PINK1', 'PD_PARK7', 'PD_VPS35']
pathway_features = ['PATHWAY_Inflammation', 'PATHWAY_Mitochondrial', 'PATHWAY_Autophagy']

merged_clean['PINK1_x_PARK7'] = merged_clean['PD_PINK1'] * merged_clean['PD_PARK7']
merged_clean['AGE_x_PINK1'] = merged_clean['AGE'] * merged_clean['PD_PINK1']
merged_clean['UPDRS_BL_x_PINK1'] = merged_clean['UPDRS_BL'] * merged_clean['PD_PINK1']
interaction_features = ['PINK1_x_PARK7', 'AGE_x_PINK1', 'UPDRS_BL_x_PINK1']

all_features = clinical_features + top_100_genes + pd_genes + pathway_features + interaction_features
final_features = [f for f in all_features if f in merged_clean.columns]

for col in final_features:
    if merged_clean[col].isnull().sum() > 0:
        merged_clean[col].fillna(merged_clean[col].median(), inplace=True)

X = merged_clean[final_features].values
y_v04 = merged_clean['UPDRS_V04'].values
y_clf = (merged_clean['DELTA_UPDRS'] >= 5).astype(int).values

# Transform target
target_transformer_temp = PowerTransformer(method='yeo-johnson', standardize=True)
y_v04_transformed = target_transformer_temp.fit_transform(y_v04.reshape(-1, 1)).flatten()

# Split data
X_trainval, X_clinical, y_trainval_trans, y_clinical_trans, y_trainval_orig, y_clinical_orig, y_clf_trainval, y_clf_clinical = train_test_split(
    X, y_v04_transformed, y_v04, y_clf, test_size=0.2, random_state=RANDOM_SEED, stratify=y_clf
)

# Load saved model
model_path = '/home/ubuntu/manuscript_update/parkinson_optimized_model_package/model/lightweight_optimized_model.pkl'
saved_data = joblib.load(model_path)
ensemble_model = saved_data['ensemble_model']
scaler = saved_data['scaler']
target_transformer_saved = saved_data['target_transformer']

# Predict on clinical holdout
X_clinical_scaled = scaler.transform(X_clinical)
y_clinical_pred_trans = ensemble_model.predict(X_clinical_scaled)
y_clinical_pred = target_transformer_saved.inverse_transform(y_clinical_pred_trans.reshape(-1, 1)).flatten()

# Calculate metrics
clinical_r2 = r2_score(y_clinical_orig, y_clinical_pred)
clinical_mae = mean_absolute_error(y_clinical_orig, y_clinical_pred)
residuals = y_clinical_orig - y_clinical_pred

print(f"  Clinical Holdout: R²={clinical_r2:.3f}, MAE={clinical_mae:.2f}, n={len(y_clinical_orig)}")

# Load CV predictions
cv_predictions_df = pd.read_csv('/home/ubuntu/manuscript_update/cv_predictions_7fold.csv')
cv_actual = cv_predictions_df['y_true'].values
cv_pred = cv_predictions_df['y_pred'].values

fold_r2_values = cv_predictions_df.groupby('fold').apply(
    lambda x: r2_score(x['y_true'], x['y_pred'])
).values
cv_r2_mean = np.mean(fold_r2_values)
cv_mae = mean_absolute_error(cv_actual, cv_pred)

print(f"  7-Fold CV: R²={cv_r2_mean:.3f}, MAE={cv_mae:.2f}, n={len(cv_actual)}")

# ============================================================================
# CREATE 6-PANEL FIGURE
# ============================================================================
print("\n[2/7] Creating 6-panel figure...")

# Create figure with 2x3 grid
fig = plt.figure(figsize=(18, 12))
gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.35, wspace=0.3)

# Define colors
color_input = '#D6EAF8'
color_base = '#FADBD8'
color_meta = '#FDEDEC'
color_output = '#D5F5E3'
color_arrow = '#34495E'

# ============================================================================
# PANEL A: MODEL ARCHITECTURE
# ============================================================================
print("\n[3/7] Panel A: Model Architecture...")

ax_a = fig.add_subplot(gs[0, 0])
ax_a.set_xlim(0, 10)
ax_a.set_ylim(0, 10)
ax_a.axis('off')

def draw_box(ax, x, y, width, height, text, color, fontsize=9, fontweight='normal'):
    box = FancyBboxPatch((x, y), width, height, 
                         boxstyle="round,pad=0.08", 
                         edgecolor='black', 
                         facecolor=color, 
                         linewidth=1.5,
                         zorder=2)
    ax.add_patch(box)
    ax.text(x + width/2, y + height/2, text, 
            ha='center', va='center', 
            fontsize=fontsize, fontweight=fontweight,
            zorder=3)

def draw_arrow(ax, x1, y1, x2, y2, color=color_arrow):
    arrow = FancyArrowPatch((x1, y1), (x2, y2),
                           arrowstyle='->',
                           color=color,
                           linewidth=1.5,
                           mutation_scale=15,
                           zorder=1)
    ax.add_patch(arrow)

# Input layer
draw_box(ax_a, 3.5, 8.5, 3, 0.7, 'Input Features\n(n=390, 116 features)', 
         color_input, fontsize=9, fontweight='bold')
ax_a.text(-0.3, 8.85, 'INPUT\nLAYER', fontsize=8, fontweight='bold', ha='center', va='center')

# Base models
draw_box(ax_a, 0.8, 6.0, 2.2, 0.6, 'XGBoost\nRegressor', color_base, fontsize=9, fontweight='bold')
draw_box(ax_a, 3.4, 6.0, 2.2, 0.6, 'LightGBM\nRegressor', color_base, fontsize=9, fontweight='bold')
draw_box(ax_a, 6.0, 6.0, 2.2, 0.6, 'CatBoost\nRegressor', color_base, fontsize=9, fontweight='bold')
ax_a.text(-0.3, 6.3, 'LEVEL 0\nBase Models', fontsize=8, fontweight='bold', ha='center', va='center')

# Arrows input to base
draw_arrow(ax_a, 5, 8.5, 1.9, 6.6)
draw_arrow(ax_a, 5, 8.5, 4.5, 6.6)
draw_arrow(ax_a, 5, 8.5, 7.1, 6.6)

# Predictions
for i, px in enumerate([1.0, 3.6, 6.2]):
    box = FancyBboxPatch((px, 4.3), 1.8, 0.5, 
                         boxstyle="round,pad=0.06", 
                         edgecolor='black', 
                         facecolor='#E8DAEF', 
                         linewidth=1.2,
                         linestyle='--',
                         zorder=2)
    ax_a.add_patch(box)
    ax_a.text(px + 0.9, 4.55, f'Prediction {i+1}', 
            ha='center', va='center', fontsize=8, style='italic', zorder=3)

# Arrows base to predictions
draw_arrow(ax_a, 1.9, 6.0, 1.9, 4.8)
draw_arrow(ax_a, 4.5, 6.0, 4.5, 4.8)
draw_arrow(ax_a, 7.1, 6.0, 7.1, 4.8)

# Meta-model
draw_box(ax_a, 3.5, 2.2, 3, 0.7, 'Huber Regressor\n(Meta-Model)', 
         color_meta, fontsize=9, fontweight='bold')
ax_a.text(-0.3, 2.55, 'LEVEL 1\nMeta-Model', fontsize=8, fontweight='bold', ha='center', va='center')

# Arrows predictions to meta
draw_arrow(ax_a, 1.9, 4.3, 4.2, 2.9)
draw_arrow(ax_a, 4.5, 4.3, 5.0, 2.9)
draw_arrow(ax_a, 7.1, 4.3, 5.8, 2.9)

# Output
draw_box(ax_a, 3.5, 0.5, 3, 0.7, 'Predicted UPDRS_V04', 
         color_output, fontsize=9, fontweight='bold')
ax_a.text(-0.3, 0.85, 'OUTPUT', fontsize=8, fontweight='bold', ha='center', va='center')

# Arrow meta to output
draw_arrow(ax_a, 5, 2.2, 5, 1.2)

# Panel label
ax_a.text(-0.05, 1.05, '(a)', transform=ax_a.transAxes, 
         fontsize=14, fontweight='bold', va='top')
ax_a.set_title('Model Architecture', fontsize=11, pad=8, fontweight='bold')

# ============================================================================
# PANEL B: PREDICTED VS ACTUAL (HOLDOUT)
# ============================================================================
print("\n[4/7] Panel B: Predicted vs Actual...")

ax_b = fig.add_subplot(gs[0, 1])

ax_b.scatter(y_clinical_orig, y_clinical_pred, 
           alpha=0.7, s=60, color='#E63946', edgecolors='white', linewidth=0.5)

min_val = min(y_clinical_orig.min(), y_clinical_pred.min())
max_val = max(y_clinical_orig.max(), y_clinical_pred.max())
ax_b.plot([min_val, max_val], [min_val, max_val], 
        'k--', linewidth=2, label='Perfect Prediction', alpha=0.7)

ax_b.set_xlabel('Actual UPDRS Part III at 12 Months', fontsize=10, fontweight='bold')
ax_b.set_ylabel('Predicted UPDRS Part III at 12 Months', fontsize=10, fontweight='bold')
ax_b.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)

textstr = f'$R^2$ = {clinical_r2:.3f}\nMAE = {clinical_mae:.2f}\nn = {len(y_clinical_orig)}'
props = dict(boxstyle='round', facecolor='white', alpha=0.9, edgecolor='gray', linewidth=1.2)
ax_b.text(0.05, 0.95, textstr, transform=ax_b.transAxes, fontsize=9,
        verticalalignment='top', bbox=props, family='monospace', fontweight='bold')

legend_b = ax_b.legend(loc='lower right', frameon=True, fontsize=8)
for text in legend_b.get_texts():
    text.set_fontweight('bold')
ax_b.set_xlim(min_val - 2, max_val + 2)
ax_b.set_ylim(min_val - 2, max_val + 2)
ax_b.set_aspect('equal', adjustable='box')

ax_b.text(-0.05, 1.05, '(b)', transform=ax_b.transAxes, 
         fontsize=14, fontweight='bold', va='top')
ax_b.set_title('Predicted vs Actual (n=78)', fontsize=11, pad=8, fontweight='bold')

# ============================================================================
# PANEL C: RESIDUALS
# ============================================================================
print("\n[5/7] Panel C: Residuals...")

ax_c = fig.add_subplot(gs[0, 2])

ax_c.scatter(y_clinical_pred, residuals, 
           alpha=0.7, s=60, color='#E63946', edgecolors='white', linewidth=0.5)

ax_c.axhline(y=0, color='black', linestyle='--', linewidth=2, alpha=0.7, label='Zero Error')
mean_residual = np.mean(residuals)
ax_c.axhline(y=mean_residual, color='red', linestyle=':', linewidth=1.5, 
            alpha=0.7, label=f'Mean = {mean_residual:.2f}')

ax_c.set_xlabel('Predicted UPDRS Part III at 12 Months', fontsize=10, fontweight='bold')
ax_c.set_ylabel('Residuals (Actual - Predicted)', fontsize=10, fontweight='bold')
ax_c.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)

textstr = f'Mean = {mean_residual:.2f}\nSD = {np.std(residuals):.2f}\nn = {len(residuals)}'
props = dict(boxstyle='round', facecolor='white', alpha=0.9, edgecolor='gray', linewidth=1.2)
ax_c.text(0.95, 0.95, textstr, transform=ax_c.transAxes, fontsize=9,
        verticalalignment='top', horizontalalignment='right', bbox=props, family='monospace', fontweight='bold')

legend_c = ax_c.legend(loc='lower right', frameon=True, fontsize=8)
for text in legend_c.get_texts():
    text.set_fontweight('bold')

ax_c.text(-0.05, 1.05, '(c)', transform=ax_c.transAxes, 
         fontsize=14, fontweight='bold', va='top')
ax_c.set_title('Residuals', fontsize=11, pad=8, fontweight='bold')

# ============================================================================
# PANEL D: VIOLIN PLOT
# ============================================================================
print("\n[6/7] Panel D: Violin Plot...")

ax_d = fig.add_subplot(gs[1, 0])

data_for_violin = [y_clinical_orig, y_clinical_pred]
positions = [1, 2]
colors = ['#2E86AB', '#E63946']

parts = ax_d.violinplot(data_for_violin, positions=positions, showmeans=True, showmedians=True)

for i, pc in enumerate(parts['bodies']):
    pc.set_facecolor(colors[i])
    pc.set_alpha(0.6)
    pc.set_edgecolor('black')
    pc.set_linewidth(1.5)

for partname in ('cbars', 'cmins', 'cmaxes', 'cmedians', 'cmeans'):
    vp = parts[partname]
    vp.set_edgecolor('black')
    vp.set_linewidth(1.5)

ax_d.set_xticks([1, 2])
ax_d.set_xticklabels(['Actual', 'Predicted'], fontsize=10, fontweight='bold')
ax_d.set_ylabel('UPDRS Part III at 12 Months', fontsize=10, fontweight='bold')
ax_d.grid(True, axis='y', alpha=0.3, linestyle='--', linewidth=0.5)

textstr = f'Actual:\nMean = {np.mean(y_clinical_orig):.1f}\nSD = {np.std(y_clinical_orig):.1f}\n\nPredicted:\nMean = {np.mean(y_clinical_pred):.1f}\nSD = {np.std(y_clinical_pred):.1f}'
props = dict(boxstyle='round', facecolor='white', alpha=0.9, edgecolor='gray', linewidth=1.2)
ax_d.text(0.95, 0.95, textstr, transform=ax_d.transAxes, fontsize=8,
        verticalalignment='top', horizontalalignment='right', bbox=props, family='monospace', fontweight='bold')

ax_d.text(-0.05, 1.05, '(d)', transform=ax_d.transAxes, 
         fontsize=14, fontweight='bold', va='top')
ax_d.set_title('Distribution Comparison', fontsize=11, pad=8, fontweight='bold')

# ============================================================================
# PANEL E: 7-FOLD CV
# ============================================================================
print("\n[7/7] Panel E: 7-Fold CV...")

ax_e = fig.add_subplot(gs[1, 1])

ax_e.scatter(cv_actual, cv_pred, 
           alpha=0.6, s=40, color='#2E86AB', edgecolors='white', linewidth=0.3)

min_val_cv = min(cv_actual.min(), cv_pred.min())
max_val_cv = max(cv_actual.max(), cv_pred.max())
ax_e.plot([min_val_cv, max_val_cv], [min_val_cv, max_val_cv], 
        'k--', linewidth=2, label='Perfect Prediction', alpha=0.7)

ax_e.set_xlabel('Actual UPDRS Part III at 12 Months', fontsize=10, fontweight='bold')
ax_e.set_ylabel('Predicted UPDRS Part III at 12 Months', fontsize=10, fontweight='bold')
ax_e.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)

textstr = f'$R^2$ = {cv_r2_mean:.3f}\nMAE = {cv_mae:.2f}\nn = {len(cv_actual)}'
props = dict(boxstyle='round', facecolor='white', alpha=0.9, edgecolor='gray', linewidth=1.2)
ax_e.text(0.05, 0.95, textstr, transform=ax_e.transAxes, fontsize=9,
        verticalalignment='top', bbox=props, family='monospace', fontweight='bold')

legend_e = ax_e.legend(loc='lower right', frameon=True, fontsize=8)
for text in legend_e.get_texts():
    text.set_fontweight('bold')
ax_e.set_xlim(min_val_cv - 2, max_val_cv + 2)
ax_e.set_ylim(min_val_cv - 2, max_val_cv + 2)
ax_e.set_aspect('equal', adjustable='box')

ax_e.text(-0.05, 1.05, '(e)', transform=ax_e.transAxes, 
         fontsize=14, fontweight='bold', va='top')
ax_e.set_title('7-Fold CV (n=312)', fontsize=11, pad=8, fontweight='bold')

# ============================================================================
# PANEL F: INDEPENDENT HOLDOUT (SAME AS PANEL B)
# ============================================================================
print("\n[8/7] Panel F: Independent Holdout...")

ax_f = fig.add_subplot(gs[1, 2])

ax_f.scatter(y_clinical_orig, y_clinical_pred, 
           alpha=0.7, s=60, color='#E63946', edgecolors='white', linewidth=0.5)

ax_f.plot([min_val, max_val], [min_val, max_val], 
        'k--', linewidth=2, label='Perfect Prediction', alpha=0.7)

ax_f.set_xlabel('Actual UPDRS Part III at 12 Months', fontsize=10, fontweight='bold')
ax_f.set_ylabel('Predicted UPDRS Part III at 12 Months', fontsize=10, fontweight='bold')
ax_f.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)

textstr = f'$R^2$ = {clinical_r2:.3f}\nMAE = {clinical_mae:.2f}\nn = {len(y_clinical_orig)}'
props = dict(boxstyle='round', facecolor='white', alpha=0.9, edgecolor='gray', linewidth=1.2)
ax_f.text(0.05, 0.95, textstr, transform=ax_f.transAxes, fontsize=9,
        verticalalignment='top', bbox=props, family='monospace', fontweight='bold')

legend_f = ax_f.legend(loc='lower right', frameon=True, fontsize=8)
for text in legend_f.get_texts():
    text.set_fontweight('bold')
ax_f.set_xlim(min_val - 2, max_val + 2)
ax_f.set_ylim(min_val - 2, max_val + 2)
ax_f.set_aspect('equal', adjustable='box')

ax_f.text(-0.05, 1.05, '(f)', transform=ax_f.transAxes, 
         fontsize=14, fontweight='bold', va='top')
ax_f.set_title('Independent Holdout (n=78)', fontsize=11, pad=8, fontweight='bold')

# ============================================================================
# SAVE FIGURE
# ============================================================================
print("\n[9/7] Saving figure...")

plt.tight_layout()

# Save as TIFF (500 DPI - journal requirement for combination figures)
output_tiff = '/home/ubuntu/Figure1_6panels.tif'
plt.savefig(output_tiff, dpi=500, format='tiff', bbox_inches='tight', 
            facecolor='white', pil_kwargs={'compression': 'tiff_lzw'})
print(f"  ✓ TIFF saved: {output_tiff}")

# Save as PNG (preview)
output_png = '/home/ubuntu/Figure1_6panels.png'
plt.savefig(output_png, dpi=500, format='png', bbox_inches='tight', facecolor='white')
print(f"  ✓ PNG saved: {output_png}")

plt.close()

print("\n" + "=" * 80)
print("FIGURE 1 COMPLETED!")
print("=" * 80)
print(f"\nFiles:")
print(f"  TIFF (submission): {output_tiff}")
print(f"  PNG (preview): {output_png}")
print(f"\nSpecifications:")
print(f"  Resolution: 500 DPI (journal requirement for combination figures)")
print(f"  Size: 18 x 12 inches")
print(f"  Panels: 6 (2x3 grid)")
print(f"  Format: TIFF (lossless compression)")
print(f"  Panel labels: (a) through (f)")
print("=" * 80)
