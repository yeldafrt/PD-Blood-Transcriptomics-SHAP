#!/usr/bin/env python3
"""
Figure 1: Model Architecture and Comprehensive Performance Evaluation (5 panels)
Panel A: Model Architecture
Panel B: Predicted vs Actual (Independent Test, n=78)
Panel C: Residuals
Panel D: Violin Plot (Distribution Comparison)
Panel E: 7-Fold CV Performance (Bar Chart)

600 DPI TIFF format for journal submission
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PowerTransformer
from sklearn.metrics import mean_absolute_error, r2_score, mean_squared_error
import joblib
import warnings
import os
warnings.filterwarnings('ignore')

# High-quality settings for journal (600 DPI)
plt.rcParams['figure.dpi'] = 600
plt.rcParams['savefig.dpi'] = 600
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 11  # Larger for readability
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['axes.titlesize'] = 13
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 10

print("=" * 80)
print("CREATING FIGURE 1: 5-PANEL EVALUATION (600 DPI, READABLE)")
print("=" * 80)

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# ============================================================================
# LOAD DATA AND MODEL
# ============================================================================
print("\n[1/6] Loading data and model...")

data_paths = [
    '/home/ubuntu/dataset/dataset/final_dataset.csv',
    '/home/ubuntu/upload/.recovery/final_dataset.csv',
]

rnaseq_paths = [
    '/home/ubuntu/dataset/dataset/rnaseq_baseline_filtered.csv',
    '/home/ubuntu/upload/.recovery/rnaseq_baseline_filtered.csv',
]

final_df_path = next((p for p in data_paths if os.path.exists(p)), None)
rnaseq_path = next((p for p in rnaseq_paths if os.path.exists(p)), None)

if not final_df_path or not rnaseq_path:
    print("ERROR: Data files not found!")
    exit(1)

print(f"  Loading: {final_df_path}")
print(f"  Loading: {rnaseq_path}")

final_df = pd.read_csv(final_df_path)
rnaseq = pd.read_csv(rnaseq_path)

final_df['PATNO'] = final_df['PATNO'].astype(str)
rnaseq['PATNO'] = rnaseq['PATNO'].astype(str)

gene_cols = [col for col in rnaseq.columns if col.startswith('ENSG')]
rnaseq_genes = rnaseq[['PATNO'] + gene_cols]

merged = pd.merge(final_df, rnaseq_genes, on='PATNO', how='inner')

# Outlier removal
merged['UPDRS_V04'].fillna(merged['UPDRS_V04'].median(), inplace=True)
Q1 = merged['UPDRS_V04'].quantile(0.25)
Q3 = merged['UPDRS_V04'].quantile(0.75)
IQR = Q3 - Q1
outliers = (merged['UPDRS_V04'] < Q1 - 1.5*IQR) | (merged['UPDRS_V04'] > Q3 + 1.5*IQR)
merged_clean = merged[~outliers].copy()

print(f"  {len(merged_clean)} patients loaded")

# Select top 100 genes
gene_correlations = []
for gene in gene_cols:
    if gene in merged_clean.columns:
        corr = merged_clean[[gene, 'DELTA_UPDRS']].corr().iloc[0, 1]
        if not np.isnan(corr):
            gene_correlations.append((gene, abs(corr), corr))

gene_correlations.sort(key=lambda x: x[1], reverse=True)
top_100_genes = [g[0] for g in gene_correlations[:100]]

# Feature engineering
clinical_features = ['UPDRS_BL', 'AGE', 'GENDER']
pd_genes = ['PD_SNCA', 'PD_LRRK2', 'PD_GBA', 'PD_PRKN', 'PD_PINK1', 'PD_PARK7', 'PD_VPS35']
pathway_features = ['PATHWAY_Inflammation', 'PATHWAY_Mitochondrial', 'PATHWAY_Autophagy']

merged_clean['PINK1_x_PARK7'] = merged_clean['PD_PINK1'] * merged_clean['PD_PARK7']
merged_clean['AGE_x_PINK1'] = merged_clean['AGE'] * merged_clean['PD_PINK1']
merged_clean['UPDRS_BL_x_PINK1'] = merged_clean['UPDRS_BL'] * merged_clean['PD_PINK1']
interaction_features = ['PINK1_x_PARK7', 'AGE_x_PINK1', 'UPDRS_BL_x_PINK1']

all_features = clinical_features + top_100_genes + pd_genes + pathway_features + interaction_features
final_features = [f for f in all_features if f in merged_clean.columns]

for col in final_features:
    if merged_clean[col].isnull().sum() > 0:
        merged_clean[col].fillna(merged_clean[col].median(), inplace=True)

X = merged_clean[final_features].values
y_v04 = merged_clean['UPDRS_V04'].values
y_clf = (merged_clean['DELTA_UPDRS'] >= 5).astype(int).values

# Transform target
target_transformer_temp = PowerTransformer(method='yeo-johnson', standardize=True)
y_v04_transformed = target_transformer_temp.fit_transform(y_v04.reshape(-1, 1)).flatten()

# Split data
X_trainval, X_clinical, y_trainval_trans, y_clinical_trans, y_trainval_orig, y_clinical_orig, y_clf_trainval, y_clf_clinical = train_test_split(
    X, y_v04_transformed, y_v04, y_clf, test_size=0.2, random_state=RANDOM_SEED, stratify=y_clf
)

print(f"  Training set: n={len(X_trainval)}")
print(f"  Test set: n={len(X_clinical)}")

# Load saved model
model_paths = [
    '/home/ubuntu/package_fix/Parkinson_Optimized_Model_Package/parkinson_optimized_model_package/model/lightweight_optimized_model.pkl',
    '/tmp/Parkinson_Optimized_Model_Package/parkinson_optimized_model_package/model/lightweight_optimized_model.pkl',
]

model_path = next((p for p in model_paths if os.path.exists(p)), None)

if not model_path:
    print("ERROR: Model file not found!")
    exit(1)

print(f"  Loading model: {model_path}")

saved_data = joblib.load(model_path)
ensemble_model = saved_data['ensemble_model']
scaler = saved_data['scaler']
target_transformer_saved = saved_data['target_transformer']

# ============================================================================
# PREDICT ON TEST SET
# ============================================================================
print("\n[2/6] Predicting on test set...")

X_clinical_scaled = scaler.transform(X_clinical)
y_clinical_pred_trans = ensemble_model.predict(X_clinical_scaled)
y_clinical_pred = target_transformer_saved.inverse_transform(y_clinical_pred_trans.reshape(-1, 1)).flatten()

clinical_r2 = r2_score(y_clinical_orig, y_clinical_pred)
clinical_mae = mean_absolute_error(y_clinical_orig, y_clinical_pred)
clinical_rmse = np.sqrt(mean_squared_error(y_clinical_orig, y_clinical_pred))
residuals = y_clinical_orig - y_clinical_pred

print(f"  Test Set: R²={clinical_r2:.3f}, MAE={clinical_mae:.2f}, RMSE={clinical_rmse:.2f}, n={len(y_clinical_orig)}")

# ============================================================================
# LOAD CV DATA
# ============================================================================
print("\n[3/6] Loading CV data...")

# CV summary data from package
cv_data = {
    'fold': [1, 2, 3, 4, 5, 6, 7],
    'r2': [0.5739, 0.4804, 0.4978, 0.5705, 0.5061, 0.4282, 0.5369],
    'mae': [6.037, 6.559, 5.906, 6.206, 6.299, 6.219, 5.811],
    'rmse': [7.399, 8.450, 7.540, 7.378, 8.554, 8.384, 7.304]
}

cv_df = pd.DataFrame(cv_data)
cv_mean_r2 = cv_df['r2'].mean()
cv_std_r2 = cv_df['r2'].std()
cv_mean_mae = cv_df['mae'].mean()

print(f"  7-Fold CV: R²={cv_mean_r2:.3f}±{cv_std_r2:.3f}, MAE={cv_mean_mae:.2f}, n=312")

# ============================================================================
# CREATE 5-PANEL FIGURE
# ============================================================================
print("\n[4/6] Creating 5-panel figure...")

# Create figure with 2x3 grid
fig = plt.figure(figsize=(20, 13))
gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.35, wspace=0.3)

# Define colors
color_input = '#D6EAF8'
color_base = '#FADBD8'
color_meta = '#FDEDEC'
color_output = '#D5F5E3'
color_arrow = '#34495E'

# ============================================================================
# PANEL A: MODEL ARCHITECTURE
# ============================================================================
print("\n[5/6] Panel A: Model Architecture...")

ax_a = fig.add_subplot(gs[0, 0])
ax_a.set_xlim(0, 10)
ax_a.set_ylim(0, 10)
ax_a.axis('off')

def draw_box(ax, x, y, width, height, text, color, fontsize=10, fontweight='normal'):
    box = FancyBboxPatch((x, y), width, height, 
                         boxstyle="round,pad=0.08", 
                         edgecolor='black', 
                         facecolor=color, 
                         linewidth=1.8,
                         zorder=2)
    ax.add_patch(box)
    ax.text(x + width/2, y + height/2, text, 
            ha='center', va='center', 
            fontsize=fontsize, fontweight=fontweight,
            zorder=3)

def draw_arrow(ax, x1, y1, x2, y2, color=color_arrow):
    arrow = FancyArrowPatch((x1, y1), (x2, y2),
                           arrowstyle='->',
                           color=color,
                           linewidth=1.8,
                           mutation_scale=18,
                           zorder=1)
    ax.add_patch(arrow)

# Input layer
draw_box(ax_a, 3.5, 8.5, 3, 0.7, 'Input Features\n(n=390, 116 features)', 
         color_input, fontsize=10, fontweight='bold')
ax_a.text(-0.3, 8.85, 'INPUT\nLAYER', fontsize=9, fontweight='bold', ha='center', va='center')

# Base models
draw_box(ax_a, 0.8, 6.0, 2.2, 0.6, 'XGBoost\nRegressor', color_base, fontsize=10, fontweight='bold')
draw_box(ax_a, 3.4, 6.0, 2.2, 0.6, 'LightGBM\nRegressor', color_base, fontsize=10, fontweight='bold')
draw_box(ax_a, 6.0, 6.0, 2.2, 0.6, 'CatBoost\nRegressor', color_base, fontsize=10, fontweight='bold')
ax_a.text(-0.3, 6.3, 'LEVEL 0\nBase Models', fontsize=9, fontweight='bold', ha='center', va='center')

# Arrows input to base
draw_arrow(ax_a, 5, 8.5, 1.9, 6.6)
draw_arrow(ax_a, 5, 8.5, 4.5, 6.6)
draw_arrow(ax_a, 5, 8.5, 7.1, 6.6)

# Predictions
for i, px in enumerate([1.0, 3.6, 6.2]):
    box = FancyBboxPatch((px, 4.3), 1.8, 0.5, 
                         boxstyle="round,pad=0.06", 
                         edgecolor='black', 
                         facecolor='#E8DAEF', 
                         linewidth=1.4,
                         linestyle='--',
                         zorder=2)
    ax_a.add_patch(box)
    ax_a.text(px + 0.9, 4.55, f'Prediction {i+1}', 
            ha='center', va='center', fontsize=9, style='italic', zorder=3)

# Arrows base to predictions
draw_arrow(ax_a, 1.9, 6.0, 1.9, 4.8)
draw_arrow(ax_a, 4.5, 6.0, 4.5, 4.8)
draw_arrow(ax_a, 7.1, 6.0, 7.1, 4.8)

# Meta-model
draw_box(ax_a, 3.5, 2.2, 3, 0.7, 'Huber Regressor\n(Meta-Model)', 
         color_meta, fontsize=10, fontweight='bold')
ax_a.text(-0.3, 2.55, 'LEVEL 1\nMeta-Model', fontsize=9, fontweight='bold', ha='center', va='center')

# Arrows predictions to meta
draw_arrow(ax_a, 1.9, 4.3, 4.2, 2.9)
draw_arrow(ax_a, 4.5, 4.3, 5.0, 2.9)
draw_arrow(ax_a, 7.1, 4.3, 5.8, 2.9)

# Output
draw_box(ax_a, 3.5, 0.5, 3, 0.7, 'Predicted UPDRS_V04', 
         color_output, fontsize=10, fontweight='bold')
ax_a.text(-0.3, 0.85, 'OUTPUT', fontsize=9, fontweight='bold', ha='center', va='center')

# Arrow meta to output
draw_arrow(ax_a, 5, 2.2, 5, 1.2)

# Panel label
ax_a.text(-0.05, 1.05, '(a)', transform=ax_a.transAxes, 
         fontsize=16, fontweight='bold', va='top')
ax_a.set_title('Model Architecture', fontsize=13, pad=10, fontweight='bold')

# ============================================================================
# PANEL B: PREDICTED VS ACTUAL
# ============================================================================
print("\n[6/6] Panel B: Predicted vs Actual...")

ax_b = fig.add_subplot(gs[0, 1])

ax_b.scatter(y_clinical_orig, y_clinical_pred, 
           alpha=0.7, s=80, color='#E63946', edgecolors='white', linewidth=0.6)

min_val = min(y_clinical_orig.min(), y_clinical_pred.min())
max_val = max(y_clinical_orig.max(), y_clinical_pred.max())
ax_b.plot([min_val, max_val], [min_val, max_val], 
        'k--', linewidth=2.5, label='Perfect Prediction', alpha=0.7)

ax_b.set_xlabel('Actual UPDRS Part III at 12 Months', fontsize=12, fontweight='bold')
ax_b.set_ylabel('Predicted UPDRS Part III at 12 Months', fontsize=12, fontweight='bold')
ax_b.grid(True, alpha=0.3, linestyle='--', linewidth=0.6)

textstr = f'$R^2$ = {clinical_r2:.3f}\nMAE = {clinical_mae:.2f}\nn = {len(y_clinical_orig)}'
props = dict(boxstyle='round', facecolor='white', alpha=0.95, edgecolor='gray', linewidth=1.5)
ax_b.text(0.05, 0.95, textstr, transform=ax_b.transAxes, fontsize=11,
        verticalalignment='top', bbox=props, family='monospace', fontweight='bold')

legend_b = ax_b.legend(loc='lower right', frameon=True, fontsize=10)
for text in legend_b.get_texts():
    text.set_fontweight('bold')
ax_b.set_xlim(min_val - 2, max_val + 2)
ax_b.set_ylim(min_val - 2, max_val + 2)
ax_b.set_aspect('equal', adjustable='box')

ax_b.text(-0.05, 1.05, '(b)', transform=ax_b.transAxes, 
         fontsize=16, fontweight='bold', va='top')
ax_b.set_title('Predicted vs Actual (n=78)', fontsize=13, pad=10, fontweight='bold')

# ============================================================================
# PANEL C: RESIDUALS
# ============================================================================
print("\n[7/6] Panel C: Residuals...")

ax_c = fig.add_subplot(gs[0, 2])

ax_c.scatter(y_clinical_pred, residuals, 
           alpha=0.7, s=80, color='#E63946', edgecolors='white', linewidth=0.6)

ax_c.axhline(y=0, color='black', linestyle='--', linewidth=2.5, label='Zero Error', alpha=0.7)

mean_residual = np.mean(residuals)
ax_c.axhline(y=mean_residual, color='red', linestyle=':', linewidth=2.5, 
           label=f'Mean = {mean_residual:.2f}', alpha=0.7)

ax_c.set_xlabel('Predicted UPDRS Part III at 12 Months', fontsize=12, fontweight='bold')
ax_c.set_ylabel('Residuals (Actual - Predicted)', fontsize=12, fontweight='bold')
ax_c.grid(True, alpha=0.3, linestyle='--', linewidth=0.6)

textstr = f'Mean = {mean_residual:.2f}\nSD = {np.std(residuals):.2f}\nn = {len(residuals)}'
props = dict(boxstyle='round', facecolor='white', alpha=0.95, edgecolor='gray', linewidth=1.5)
ax_c.text(0.95, 0.95, textstr, transform=ax_c.transAxes, fontsize=11,
        verticalalignment='top', horizontalalignment='right', bbox=props, family='monospace', fontweight='bold')

legend_c = ax_c.legend(loc='lower right', frameon=True, fontsize=10)
for text in legend_c.get_texts():
    text.set_fontweight('bold')

ax_c.text(-0.05, 1.05, '(c)', transform=ax_c.transAxes, 
         fontsize=16, fontweight='bold', va='top')
ax_c.set_title('Residuals', fontsize=13, pad=10, fontweight='bold')

# ============================================================================
# PANEL D: VIOLIN PLOT
# ============================================================================
print("\n[8/6] Panel D: Violin Plot...")

ax_d = fig.add_subplot(gs[1, 0])

data_for_violin = [y_clinical_orig, y_clinical_pred]
positions = [1, 2]
colors = ['#2E86AB', '#E63946']

parts = ax_d.violinplot(data_for_violin, positions=positions, showmeans=True, showmedians=True)

for i, pc in enumerate(parts['bodies']):
    pc.set_facecolor(colors[i])
    pc.set_alpha(0.6)
    pc.set_edgecolor('black')
    pc.set_linewidth(1.8)

for partname in ('cbars', 'cmins', 'cmaxes', 'cmedians', 'cmeans'):
    vp = parts[partname]
    vp.set_edgecolor('black')
    vp.set_linewidth(1.8)

ax_d.set_xticks([1, 2])
ax_d.set_xticklabels(['Actual', 'Predicted'], fontsize=11, fontweight='bold')
ax_d.set_ylabel('UPDRS Part III at 12 Months', fontsize=12, fontweight='bold')
ax_d.grid(True, axis='y', alpha=0.3, linestyle='--', linewidth=0.6)

textstr = f'Actual:\nMean = {np.mean(y_clinical_orig):.1f}\nSD = {np.std(y_clinical_orig):.1f}\n\nPredicted:\nMean = {np.mean(y_clinical_pred):.1f}\nSD = {np.std(y_clinical_pred):.1f}'
props = dict(boxstyle='round', facecolor='white', alpha=0.95, edgecolor='gray', linewidth=1.5)
ax_d.text(0.95, 0.95, textstr, transform=ax_d.transAxes, fontsize=10,
        verticalalignment='top', horizontalalignment='right', bbox=props, family='monospace', fontweight='bold')

ax_d.text(-0.05, 1.05, '(d)', transform=ax_d.transAxes, 
         fontsize=16, fontweight='bold', va='top')
ax_d.set_title('Distribution Comparison', fontsize=13, pad=10, fontweight='bold')

# ============================================================================
# PANEL E: 7-FOLD CV BAR CHART
# ============================================================================
print("\n[9/6] Panel E: 7-Fold CV Bar Chart...")

ax_e = fig.add_subplot(gs[1, 1])

# Bar chart for fold-by-fold R²
bars = ax_e.bar(cv_df['fold'], cv_df['r2'], 
               color='#2E86AB', alpha=0.7, edgecolor='black', linewidth=1.5)

# Mean line
ax_e.axhline(y=cv_mean_r2, color='red', linestyle='--', linewidth=2.5, 
            label=f'Mean R² = {cv_mean_r2:.3f}', alpha=0.8)

ax_e.set_xlabel('Fold Number', fontsize=12, fontweight='bold')
ax_e.set_ylabel('R² Score', fontsize=12, fontweight='bold')
ax_e.set_xticks(cv_df['fold'])
ax_e.set_ylim(0, max(cv_df['r2']) * 1.15)
ax_e.grid(True, axis='y', alpha=0.3, linestyle='--', linewidth=0.6)

textstr = f'Mean R² = {cv_mean_r2:.3f}\nSD = {cv_std_r2:.3f}\nMAE = {cv_mean_mae:.2f}\nn = 312'
props = dict(boxstyle='round', facecolor='white', alpha=0.95, edgecolor='gray', linewidth=1.5)
ax_e.text(0.95, 0.95, textstr, transform=ax_e.transAxes, fontsize=11,
        verticalalignment='top', horizontalalignment='right', bbox=props, family='monospace', fontweight='bold')

legend_e = ax_e.legend(loc='upper left', frameon=True, fontsize=10)
for text in legend_e.get_texts():
    text.set_fontweight('bold')

ax_e.text(-0.05, 1.05, '(e)', transform=ax_e.transAxes, 
         fontsize=16, fontweight='bold', va='top')
ax_e.set_title('7-Fold Cross-Validation (n=312)', fontsize=13, pad=10, fontweight='bold')

# ============================================================================
# SAVE FIGURE
# ============================================================================
print("\n[10/6] Saving figure...")

plt.tight_layout()

# Save as TIFF (600 DPI)
output_tiff = '/home/ubuntu/Figure1_5panels_600dpi_FINAL.tif'
plt.savefig(output_tiff, dpi=600, format='tiff', bbox_inches='tight', 
            facecolor='white', pil_kwargs={'compression': 'tiff_lzw'})
print(f"  ✓ TIFF saved: {output_tiff}")

# Save as PNG (preview)
output_png = '/home/ubuntu/Figure1_5panels_600dpi_FINAL.png'
plt.savefig(output_png, dpi=600, format='png', bbox_inches='tight', facecolor='white')
print(f"  ✓ PNG saved: {output_png}")

plt.close()

print("\n" + "=" * 80)
print("FIGURE 1 FINAL VERSION (5 PANELS, 600 DPI) COMPLETED!")
print("=" * 80)
print(f"\nFiles:")
print(f"  TIFF (submission): {output_tiff}")
print(f"  PNG (preview): {output_png}")
print(f"\nLayout:")
print(f"  Row 1: (a) Architecture | (b) Predicted vs Actual | (c) Residuals")
print(f"  Row 2: (d) Violin Plot  | (e) 7-Fold CV Bar Chart | (empty)")
print(f"\nPerformance:")
print(f"  Test Set:   R²={clinical_r2:.3f}, MAE={clinical_mae:.2f}, n={len(y_clinical_orig)}")
print(f"  7-Fold CV:  R²={cv_mean_r2:.3f}±{cv_std_r2:.3f}, MAE={cv_mean_mae:.2f}, n=312")
