# Optimized Parkinson Progression Prediction Model

## 🎯 Model Overview

This package contains the **optimized** machine learning model for predicting 12-month motor symptom progression (ΔUPDRS) in Parkinson's disease patients using baseline blood RNA-seq data.

### Performance Summary

| Metric | 7-Fold CV | Clinical Holdout | Improvement from Baseline |
|--------|-----------|------------------|---------------------------|
| **R²** | 0.513 ± 0.048 | **0.551** ⭐ | **+20.2%** (0.427 → 0.513) |
| **MAE** | 6.15 ± 0.23 | **6.01** | **-9.1%** (6.77 → 6.15) |
| **RMSE** | 7.86 ± 0.53 | **7.21** | **-9.3%** (8.67 → 7.86) |

**Key Achievement:**
- ✅ **Clinical R² = 0.551** (exceeds CV mean!)
- ✅ **No overfitting** (Clinical ≈ CV)
- ✅ **20% improvement** over baseline model

---

## 📁 Package Contents

```
parkinson_optimized_model_package/
├── model/
│   └── lightweight_optimized_model.pkl        # Trained ensemble model
│
├── codes/
│   ├── lightweight_optimization.py            # Training code (Optuna + 30 trials)
│   └── predict_new_patient.py                 # Clinical prediction script
│
├── data/
│   └── example_data.csv                       # Example dataset (390 patients)
│
├── results/
│   ├── lightweight_optimization_results.csv   # Summary results
│   ├── lightweight_cv_detailed.csv            # Detailed 7-fold CV results
│   └── lightweight_optimization.log           # Full training log
│
└── documentation/
    ├── README.md                              # This file
    └── MODEL_DETAILS.md                       # Technical specifications
```

---

## 🚀 Quick Start

### 1. Installation

```bash
pip install pandas numpy scikit-learn xgboost lightgbm catboost joblib
```

### 2. Make Predictions

```bash
cd codes/
python3 predict_new_patient.py --patient_data ../data/example_data.csv --output predictions.csv
```

### 3. View Results

```bash
head predictions.csv
```

Output columns:
- `Patient_ID`
- `Predicted_UPDRS_V04` (12-month UPDRS score)
- `Predicted_DELTA_UPDRS` (change from baseline)
- `Progression_Category` (Fast ≥5 or Slow <5)
- `Lower_Bound` / `Upper_Bound` (±6 UPDRS confidence interval)

---

## 📊 Model Architecture

### Ensemble Structure

**Stacking Regressor:**
1. **Base Models (3):**
   - XGBoost (Gradient Boosting)
   - LightGBM (Gradient Boosting)
   - CatBoost (Gradient Boosting)

2. **Meta-Learner:**
   - Huber Regressor (robust to outliers)

### Features (116 total)

| Category | Count | Examples |
|----------|-------|----------|
| **Top Genes** | 100 | ENSG00000026025, ENSG00000116062, ... |
| **Clinical** | 3 | UPDRS_BL, AGE, GENDER |
| **PD Risk Genes** | 7 | PD_PINK1, PD_PARK7, PD_SNCA, ... |
| **Pathways** | 3 | PATHWAY_Mitochondrial, PATHWAY_Inflammation, ... |
| **Interactions** | 3 | PINK1×PARK7, AGE×PINK1, UPDRS_BL×PINK1 |

### Optimization

- **Method:** Optuna (Bayesian optimization)
- **Trials:** 30
- **Best Trial:** #15 (R²=0.513)
- **CV Strategy:** 7-fold cross-validation
- **Objective:** Maximize R²

---

## 📈 Validation Results

### 7-Fold Cross-Validation

| Fold | n | R² | MAE | RMSE |
|------|---|-----|-----|------|
| 1 | ~44 | 0.574 | 6.04 | 8.53 |
| 2 | ~44 | 0.480 | 6.56 | 7.72 |
| 3 | ~44 | 0.498 | 5.91 | 7.72 |
| 4 | ~44 | 0.571 | 6.21 | 7.75 |
| 5 | ~44 | 0.506 | 6.30 | 7.92 |
| 6 | ~44 | 0.428 | 6.22 | 7.84 |
| 7 | ~44 | 0.537 | 5.81 | 7.52 |
| **Mean** | **312** | **0.513 ± 0.048** | **6.15 ± 0.23** | **7.86 ± 0.53** |

### Clinical Holdout (n=78)

- **R² = 0.551** ⭐ (better than CV!)
- **MAE = 6.01** (±6 UPDRS points)
- **RMSE = 7.21**

**Conclusion:** No overfitting. Model generalizes excellently to unseen data.

---

## 🔬 Technical Specifications

### Data Preprocessing

1. **Outlier Removal:** IQR method (2 patients removed, n=392→390)
2. **Feature Scaling:** StandardScaler (z-score normalization)
3. **Target Transformation:** PowerTransformer (Yeo-Johnson method)
4. **Missing Values:** Median imputation

### Data Splitting

```
Total: 390 patients
├─ Clinical Holdout: 78 (20%) - Independent validation
└─ Train+Val: 312 (80%)
   └─ 7-Fold CV for hyperparameter optimization
```

### Hyperparameters (Best Trial #15)

**XGBoost:**
- n_estimators: 193
- max_depth: 4
- learning_rate: 0.0218
- subsample: 0.7648
- colsample_bytree: 0.7389
- reg_alpha: 0.0236
- reg_lambda: 1.2125

**LightGBM:**
- n_estimators: 241
- max_depth: 6
- learning_rate: 0.0596
- subsample: 0.6511
- colsample_bytree: 0.7851
- reg_alpha: 0.3138
- reg_lambda: 1.4060

**CatBoost:**
- iterations: 241
- depth: 6
- learning_rate: 0.0596
- subsample: 0.6511
- reg_lambda: 1.4060

**Meta-Learner (Huber):**
- epsilon: 1.0983
- alpha: 0.3138

---

## 💻 Programmatic Use

```python
import joblib
import pandas as pd
import numpy as np

# Load model
model_data = joblib.load('../model/lightweight_optimized_model.pkl')

ensemble = model_data['ensemble_model']
scaler = model_data['scaler']
transformer = model_data['target_transformer']
features = model_data['feature_names']

# Prepare patient data
patient_df = pd.read_csv('new_patients.csv')
X = patient_df[features].values

# Scale and predict
X_scaled = scaler.transform(X)
y_pred_trans = ensemble.predict(X_scaled)
y_pred_updrs = transformer.inverse_transform(y_pred_trans.reshape(-1, 1)).flatten()

print(f"Predicted UPDRS at 12 months: {y_pred_updrs}")
```

---

## ⚠️ Important Notes

### Limitations

1. **Training Data:** PPMI cohort (n=390, early PD patients)
   - Generalization to other populations should be validated

2. **Prediction Window:** 12 months only
   - Not validated for other time periods

3. **Feature Requirements:** All 116 features needed
   - Missing features will be imputed (may reduce accuracy)

4. **Clinical Context:** Research tool, not diagnostic
   - Use as decision support, not sole basis for treatment

### Best Practices

1. ✅ **Data Quality:**
   - Ensure RNA-seq from same platform (Illumina)
   - Check for batch effects
   - Validate data preprocessing

2. ✅ **Interpretation:**
   - Consider confidence intervals (±6 UPDRS)
   - Use progression categories for clinical decisions
   - Combine with clinical judgment

3. ✅ **Validation:**
   - Monitor performance in your cohort
   - Recalibrate if systematic bias detected
   - Report discrepancies

---

## 📚 Citation

If you use this model in your research, please cite:

```
[Your manuscript citation]

Model: Optimized Parkinson Progression Prediction
Version: 1.0 (2025-11-11)
Performance: R² = 0.551 (Clinical Holdout)
```

---

## 🔧 Troubleshooting

### Common Issues

**1. Import errors**
```bash
pip install pandas numpy scikit-learn xgboost lightgbm catboost joblib
```

**2. "Model file not found"**
```bash
# Check path
ls -lh ../model/lightweight_optimized_model.pkl
```

**3. Predictions unrealistic**
- Verify input data format (TPM for RNA-seq)
- Check for missing/corrupted values
- Ensure feature names match exactly

**4. Memory errors**
- Model requires ~650 MB RAM
- Close other applications
- Use smaller batch sizes

---

## 📞 Support

For questions:
1. Check documentation
2. Review example code
3. Inspect training log (`results/lightweight_optimization.log`)

---

## 📄 License

[Your license]

---

## 🎯 Version History

**v1.0 (2025-11-11)**
- Initial optimized model release
- R² = 0.513 (CV) / 0.551 (Clinical)
- 20.2% improvement over baseline
- 116 features, 3-model ensemble
- Optimized with Optuna (30 trials)
- No overfitting detected
